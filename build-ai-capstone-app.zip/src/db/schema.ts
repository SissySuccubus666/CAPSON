import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

/** Chat threads. */
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("New conversation"),
  persona: varchar("persona", { length: 40 }).notNull().default("generalist"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Individual chat turns. */
export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    role: varchar("role", { length: 16 }).notNull(),
    content: text("content").notNull(),
    engine: varchar("engine", { length: 40 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("messages_conversation_idx").on(table.conversationId)],
);

/** Brand knowledge the engine grounds its answers in. */
export const knowledgeItems = pgTable("knowledge_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: varchar("category", { length: 48 }).notNull().default("General"),
  content: text("content").notNull(),
  tags: text("tags").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Structured output produced by the studio tools. */
export const generations = pgTable(
  "generations",
  {
    id: serial("id").primaryKey(),
    tool: varchar("tool", { length: 48 }).notNull(),
    title: text("title").notNull(),
    prompt: text("prompt").notNull(),
    tone: varchar("tone", { length: 32 }).notNull().default("professional"),
    audience: varchar("audience", { length: 64 }).notNull().default("general"),
    output: text("output").notNull(),
    engine: varchar("engine", { length: 40 }).notNull().default("capson-engine"),
    favorite: boolean("favorite").notNull().default(false),
    meta: jsonb("meta").$type<Record<string, string | number>>().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("generations_tool_idx").on(table.tool)],
);

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type KnowledgeItem = typeof knowledgeItems.$inferSelect;
export type Generation = typeof generations.$inferSelect;
