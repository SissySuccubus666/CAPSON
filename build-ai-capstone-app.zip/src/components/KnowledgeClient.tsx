"use client";

import { useEffect, useState } from "react";

type KnowledgeItem = {
  id: number;
  title: string;
  category: string;
  content: string;
  tags: string;
};

const CATEGORIES = ["Product", "Market", "Positioning", "Voice", "Commercial", "Operations", "General"];

export function KnowledgeClient() {
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Product");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<number | null>(null);

  useEffect(() => {
    void load();
  }, []);

  async function load() {
    const response = await fetch("/api/knowledge", { cache: "no-store" });
    const data = (await response.json()) as { knowledge?: KnowledgeItem[] };
    setItems(data.knowledge ?? []);
  }

  async function submit() {
    if (!title.trim() || !content.trim() || busy) return;
    setBusy(true);
    const editingId = editing;
    const response = await fetch(editingId ? `/api/knowledge/${editingId}` : "/api/knowledge", {
      method: editingId ? "PATCH" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title, category, content, tags }),
    });
    if (response.ok) {
      setTitle("");
      setContent("");
      setTags("");
      setEditing(null);
      await load();
    }
    setBusy(false);
  }

  async function remove(id: number) {
    await fetch(`/api/knowledge/${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((item) => item.id !== id));
  }

  function startEdit(item: KnowledgeItem) {
    setEditing(item.id);
    setTitle(item.title);
    setCategory(item.category);
    setContent(item.content);
    setTags(item.tags);
  }

  const filtered = items.filter((item) => {
    if (!query.trim()) return true;
    const needle = query.toLowerCase();
    return `${item.title} ${item.category} ${item.tags} ${item.content}`.toLowerCase().includes(needle);
  });

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <header className="space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight text-white">Knowledge base</h1>
        <p className="max-w-2xl text-sm leading-relaxed text-slate-400">
          These are the facts Capson retrieves before answering or drafting. Anything you add here immediately shapes
          every generation across the assistant and the studio.
        </p>
      </header>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,400px)_1fr]">
        <div className="glass h-fit space-y-4 rounded-2xl p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">{editing ? "Edit entry" : "New entry"}</h2>
            {editing && (
              <button
                type="button"
                onClick={() => {
                  setEditing(null);
                  setTitle("");
                  setContent("");
                  setTags("");
                }}
                className="text-[11px] text-slate-500 hover:text-slate-300"
              >
                Cancel
              </button>
            )}
          </div>

          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Title — e.g. Our refund policy"
            className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
          />

          <select
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none focus:border-cyan-300/40"
          >
            {CATEGORIES.map((option) => (
              <option key={option} value={option} className="bg-slate-900">
                {option}
              </option>
            ))}
          </select>

          <textarea
            value={content}
            onChange={(event) => setContent(event.target.value)}
            rows={5}
            placeholder="The fact itself, written in plain language…"
            className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-3 text-[15px] text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
          />

          <input
            value={tags}
            onChange={(event) => setTags(event.target.value)}
            placeholder="Tags — pricing, policy, voice (comma separated)"
            className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
          />

          <button
            type="button"
            onClick={() => void submit()}
            disabled={busy || !title.trim() || !content.trim()}
            className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-3 text-sm font-semibold text-slate-950 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {busy ? "Saving…" : editing ? "Save changes" : "Add to knowledge base"}
          </button>
        </div>

        <div className="space-y-3">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search entries…"
            className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
          />

          <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">
            {filtered.length} of {items.length} entries
          </p>

          <div className="space-y-3">
            {filtered.map((item) => (
              <article key={item.id} className="glass rounded-2xl p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-white">{item.title}</p>
                    <p className="text-[11px] uppercase tracking-wide text-cyan-300/80">{item.category}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => startEdit(item)}
                      className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-300 transition hover:bg-white/10 hover:text-white"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => void remove(item.id)}
                      className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-400 transition hover:border-rose-400/40 hover:text-rose-300"
                    >
                      Delete
                    </button>
                  </div>
                </div>
                <p className="mt-2.5 text-[13px] leading-relaxed text-slate-400">{item.content}</p>
                {item.tags && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {item.tags
                      .split(",")
                      .map((tag) => tag.trim())
                      .filter(Boolean)
                      .map((tag) => (
                        <span
                          key={tag}
                          className="rounded-md bg-white/5 px-2 py-0.5 text-[10px] uppercase tracking-wide text-slate-500"
                        >
                          {tag}
                        </span>
                      ))}
                  </div>
                )}
              </article>
            ))}
            {filtered.length === 0 && (
              <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-sm text-slate-500">
                Nothing matches “{query}”.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
