"use client";

import { useEffect, useMemo, useState } from "react";
import { CopyButton } from "@/components/CopyButton";
import { Markdown } from "@/components/Markdown";
import { TOOL_MAP } from "@/lib/ai/tools";

type Generation = {
  id: number;
  tool: string;
  title: string;
  prompt: string;
  tone: string;
  audience: string;
  output: string;
  engine: string;
  favorite: boolean;
  createdAt: string;
};

export function LibraryClient() {
  const [items, setItems] = useState<Generation[]>([]);
  const [loading, setLoading] = useState(true);
  const [toolFilter, setToolFilter] = useState("all");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => {
    void load();
  }, []);

  async function load() {
    setLoading(true);
    const response = await fetch("/api/generations", { cache: "no-store" });
    const data = (await response.json()) as { generations?: Generation[] };
    setItems(data.generations ?? []);
    setLoading(false);
  }

  async function toggleFavorite(item: Generation) {
    setItems((prev) => prev.map((row) => (row.id === item.id ? { ...row, favorite: !row.favorite } : row)));
    await fetch(`/api/generations/${item.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ favorite: !item.favorite }),
    });
  }

  async function remove(id: number) {
    setItems((prev) => prev.filter((item) => item.id !== id));
    await fetch(`/api/generations/${id}`, { method: "DELETE" });
  }

  const tools = useMemo(() => Array.from(new Set(items.map((item) => item.tool))), [items]);
  const visible = items.filter((item) => {
    if (favoritesOnly && !item.favorite) return false;
    if (toolFilter !== "all" && item.tool !== toolFilter) return false;
    return true;
  });

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <header className="space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight text-white">Library</h1>
        <p className="max-w-2xl text-sm leading-relaxed text-slate-400">
          Every studio output is versioned here. Favorite the keepers, copy the markdown, or delete the misses.
        </p>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setToolFilter("all")}
          className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition ${
            toolFilter === "all" ? "bg-white/15 text-white" : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
          }`}
        >
          All ({items.length})
        </button>
        {tools.map((tool) => (
          <button
            key={tool}
            type="button"
            onClick={() => setToolFilter(tool)}
            className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition ${
              toolFilter === tool ? "bg-white/15 text-white" : "bg-white/[0.04] text-slate-400 hover:text-slate-200"
            }`}
          >
            {TOOL_MAP[tool]?.name ?? tool}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setFavoritesOnly((prev) => !prev)}
          className={`ml-auto rounded-lg border px-3 py-1.5 text-[12px] font-medium transition ${
            favoritesOnly
              ? "border-amber-300/50 bg-amber-300/10 text-amber-200"
              : "border-white/10 text-slate-400 hover:text-slate-200"
          }`}
        >
          ★ Favorites only
        </button>
      </div>

      {loading && <p className="text-sm text-slate-500">Loading library…</p>}

      {!loading && visible.length === 0 && (
        <div className="rounded-2xl border border-dashed border-white/15 p-10 text-center">
          <p className="text-sm text-slate-400">Nothing here yet.</p>
          <a
            href="/studio"
            className="mt-3 inline-block rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-2 text-sm font-semibold text-slate-950"
          >
            Generate something in the studio
          </a>
        </div>
      )}

      <div className="space-y-3">
        {visible.map((item) => (
          <article key={item.id} className="glass rounded-2xl p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="flex items-center gap-2 text-sm font-semibold text-white">
                  <span>{TOOL_MAP[item.tool]?.icon ?? "◆"}</span>
                  <span className="truncate">{item.title}</span>
                </p>
                <p className="mt-1 text-[11px] text-slate-500">
                  {TOOL_MAP[item.tool]?.name ?? item.tool} · tone {item.tone} · {item.audience} ·{" "}
                  <span className="font-mono">{item.engine}</span> ·{" "}
                  {new Date(item.createdAt).toLocaleString()}
                </p>
                <p className="mt-2 max-w-2xl text-[13px] text-slate-500">Brief: {item.prompt}</p>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <button
                  type="button"
                  onClick={() => void toggleFavorite(item)}
                  className={`rounded-lg border px-2.5 py-1 text-[11px] transition ${
                    item.favorite
                      ? "border-amber-300/50 bg-amber-300/10 text-amber-200"
                      : "border-white/10 bg-white/5 text-slate-400 hover:text-amber-200"
                  }`}
                >
                  {item.favorite ? "★ Saved" : "☆ Favorite"}
                </button>
                <CopyButton text={item.output} />
                <button
                  type="button"
                  onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-300 transition hover:bg-white/10 hover:text-white"
                >
                  {expanded === item.id ? "Collapse" : "Expand"}
                </button>
                <button
                  type="button"
                  onClick={() => void remove(item.id)}
                  className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-400 transition hover:border-rose-400/40 hover:text-rose-300"
                >
                  Delete
                </button>
              </div>
            </div>

            <div
              className={`mt-4 overflow-hidden border-t border-white/10 pt-4 ${
                expanded === item.id ? "" : "max-h-64"
              }`}
            >
              <Markdown content={item.output} />
            </div>
            {expanded !== item.id && (
              <div className="pointer-events-none -mt-16 h-16 bg-gradient-to-t from-[#0a0d18] to-transparent" />
            )}
          </article>
        ))}
      </div>
    </div>
  );
}
