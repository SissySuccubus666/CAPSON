"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CopyButton } from "@/components/CopyButton";
import { Markdown } from "@/components/Markdown";
import { PERSONAS } from "@/lib/ai/engine";

type ThreadSummary = {
  id: number;
  title: string;
  persona: string;
  updatedAt: string;
  messageCount: number;
};

type ChatMessage = {
  id: number;
  role: string;
  content: string;
  engine: string | null;
};

const SUGGESTIONS = [
  "What makes us different from generic AI tools?",
  "Draft a follow-up email after a pricing call",
  "How should we sequence our next 90 days?",
  "Write five taglines and tell me which one to pick",
];

export function ChatClient({ initialPrompt }: { initialPrompt: string }) {
  const [threads, setThreads] = useState<ThreadSummary[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [persona, setPersona] = useState("generalist");
  const [input, setInput] = useState(initialPrompt);
  const [sending, setSending] = useState(false);
  const [loadingThread, setLoadingThread] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const loadThreads = useCallback(async () => {
    try {
      const response = await fetch("/api/conversations", { cache: "no-store" });
      const data = (await response.json()) as { conversations?: ThreadSummary[] };
      setThreads(data.conversations ?? []);
    } catch {
      setError("Could not load conversations.");
    }
  }, []);

  useEffect(() => {
    void loadThreads();
  }, [loadThreads]);

  useEffect(() => {
    if (activeId == null) return;
    let cancelled = false;
    setLoadingThread(true);
    (async () => {
      try {
        const response = await fetch(`/api/conversations/${activeId}`, { cache: "no-store" });
        const data = (await response.json()) as {
          conversation?: { persona: string };
          messages?: ChatMessage[];
        };
        if (cancelled) return;
        setMessages(data.messages ?? []);
        if (data.conversation?.persona) setPersona(data.conversation.persona);
      } finally {
        if (!cancelled) setLoadingThread(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, sending]);

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || sending) return;
      setError(null);
      setSending(true);
      setInput("");
      const optimistic: ChatMessage = { id: Date.now(), role: "user", content: text, engine: null };
      setMessages((prev) => [...prev, optimistic]);

      try {
        const response = await fetch("/api/chat", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ conversationId: activeId, message: text, persona }),
        });
        if (!response.ok) throw new Error("Request failed");
        const data = (await response.json()) as {
          conversationId: number;
          message: ChatMessage;
        };
        setMessages((prev) => [...prev.filter((m) => m.id !== optimistic.id), optimistic, data.message]);
        setActiveId(data.conversationId);
        await loadThreads();
      } catch {
        setError("The assistant could not respond. Please try again.");
        setMessages((prev) => prev.filter((m) => m.id !== optimistic.id));
        setInput(text);
      } finally {
        setSending(false);
      }
    },
    [activeId, loadThreads, persona, sending],
  );

  async function newThread() {
    setActiveId(null);
    setMessages([]);
    setInput("");
  }

  async function deleteThread(id: number) {
    await fetch(`/api/conversations/${id}`, { method: "DELETE" });
    if (activeId === id) {
      setActiveId(null);
      setMessages([]);
    }
    void loadThreads();
  }

  const empty = messages.length === 0 && !sending;

  return (
    <div className="grid h-[calc(100vh-6rem)] gap-4 lg:h-[calc(100vh-8rem)] lg:grid-cols-[260px_1fr]">
      <aside className="glass hidden flex-col gap-3 rounded-2xl p-4 lg:flex">
        <button
          type="button"
          onClick={newThread}
          className="rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-2.5 text-sm font-semibold text-slate-950 transition hover:brightness-110"
        >
          + New conversation
        </button>
        <p className="px-1 text-[11px] uppercase tracking-[0.16em] text-slate-500">Threads</p>
        <div className="flex-1 space-y-1.5 overflow-y-auto pr-1">
          {threads.map((thread) => (
            <div
              key={thread.id}
              className={`group flex items-start gap-1 rounded-xl border px-3 py-2 transition ${
                activeId === thread.id
                  ? "border-cyan-300/40 bg-white/[0.08]"
                  : "border-transparent hover:border-white/10 hover:bg-white/5"
              }`}
            >
              <button
                type="button"
                onClick={() => setActiveId(thread.id)}
                className="flex-1 text-left"
              >
                <p className="line-clamp-2 text-[13px] text-slate-200">{thread.title}</p>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {thread.messageCount} msg · {PERSONAS[thread.persona]?.name ?? thread.persona}
                </p>
              </button>
              <button
                type="button"
                onClick={() => void deleteThread(thread.id)}
                className="mt-0.5 text-xs text-slate-600 opacity-0 transition group-hover:opacity-100 hover:text-rose-400"
                aria-label="Delete conversation"
              >
                ✕
              </button>
            </div>
          ))}
          {threads.length === 0 && (
            <p className="px-1 text-[13px] leading-relaxed text-slate-600">
              No threads yet. Ask something to start one.
            </p>
          )}
        </div>
      </aside>

      <section className="glass flex min-h-0 flex-col rounded-2xl">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-5 py-3.5">
          <div>
            <p className="text-sm font-semibold text-white">Capson Assistant</p>
            <p className="text-[11px] text-slate-500">
              Grounded in your knowledge base · {threads.length} thread{threads.length === 1 ? "" : "s"}
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {Object.entries(PERSONAS).map(([id, meta]) => (
              <button
                key={id}
                type="button"
                onClick={() => setPersona(id)}
                title={meta.blurb}
                className={`rounded-lg px-2.5 py-1.5 text-[11px] font-medium transition ${
                  persona === id
                    ? "bg-white/15 text-white"
                    : "bg-white/[0.04] text-slate-400 hover:bg-white/10 hover:text-slate-200"
                }`}
              >
                {meta.name}
              </button>
            ))}
          </div>
        </header>

        <div ref={scrollRef} className="flex-1 space-y-5 overflow-y-auto px-5 py-6">
          {loadingThread && <p className="text-xs text-slate-500">Loading conversation…</p>}

          {empty && (
            <div className="rise mx-auto max-w-2xl space-y-5 py-6 text-center">
              <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 via-indigo-500 to-cyan-400 text-xl font-black text-slate-950">
                C
              </div>
              <div>
                <h2 className="text-xl font-semibold text-white">Ask Capson anything</h2>
                <p className="mt-1 text-sm text-slate-400">
                  Running as <span className="text-slate-200">{PERSONAS[persona]?.name}</span> — {PERSONAS[persona]?.blurb.toLowerCase()}.
                </p>
              </div>
              <div className="grid gap-2 text-left sm:grid-cols-2">
                {SUGGESTIONS.map((suggestion) => (
                  <button
                    key={suggestion}
                    type="button"
                    onClick={() => void send(suggestion)}
                    className="rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[13px] text-slate-300 transition hover:border-cyan-300/40 hover:text-white"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div key={message.id} className={`rise flex gap-3 ${message.role === "user" ? "justify-end" : ""}`}>
              {message.role !== "user" && (
                <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 text-xs font-bold text-slate-950">
                  C
                </span>
              )}
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                  message.role === "user"
                    ? "bg-gradient-to-br from-indigo-500/80 to-violet-500/70 text-white"
                    : "border border-white/10 bg-white/[0.03]"
                }`}
              >
                {message.role === "user" ? (
                  <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{message.content}</p>
                ) : (
                  <>
                    <Markdown content={message.content} />
                    <div className="mt-3 flex items-center gap-2 border-t border-white/5 pt-2.5">
                      <span className="font-mono text-[10px] uppercase tracking-wide text-slate-600">
                        {message.engine ?? "capson-engine"}
                      </span>
                      <CopyButton text={message.content} />
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}

          {sending && (
            <div className="flex gap-3">
              <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gradient-to-br from-violet-500 to-cyan-400 text-xs font-bold text-slate-950">
                C
              </span>
              <div className="flex items-center gap-1.5 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3.5">
                <span className="dot h-1.5 w-1.5 rounded-full bg-cyan-300" />
                <span className="dot h-1.5 w-1.5 rounded-full bg-cyan-300 [animation-delay:0.15s]" />
                <span className="dot h-1.5 w-1.5 rounded-full bg-cyan-300 [animation-delay:0.3s]" />
                <span className="ml-2 text-xs text-slate-500">retrieving knowledge & composing…</span>
              </div>
            </div>
          )}

          {error && <p className="text-center text-xs text-rose-400">{error}</p>}
        </div>

        <footer className="border-t border-white/10 p-3">
          <div className="flex items-end gap-2 rounded-2xl border border-white/10 bg-white/[0.03] p-2 focus-within:border-cyan-300/40">
            <textarea
              value={input}
              onChange={(event) => setInput(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  void send(input);
                }
              }}
              rows={1}
              placeholder="Ask anything, or say “draft an email about…”"
              className="max-h-40 min-h-[44px] flex-1 resize-none bg-transparent px-3 py-2.5 text-[15px] text-slate-100 outline-none placeholder:text-slate-600"
            />
            <button
              type="button"
              disabled={sending || !input.trim()}
              onClick={() => void send(input)}
              className="rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-2.5 text-sm font-semibold text-slate-950 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Send
            </button>
          </div>
          <p className="mt-2 px-2 text-[11px] text-slate-600">
            Enter to send · Shift+Enter for a new line · answers cite the knowledge entries they used
          </p>
        </footer>
      </section>
    </div>
  );
}
