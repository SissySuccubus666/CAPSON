"use client";

import { useEffect, useMemo, useState } from "react";
import { CopyButton } from "@/components/CopyButton";
import { Markdown } from "@/components/Markdown";
import { TOOLS, TONES, TOOL_MAP } from "@/lib/ai/tools";

type Grounding = { title: string; category: string; score: number };

type GenerateResponse = {
  output?: string;
  engine?: string;
  title?: string;
  grounding?: Grounding[];
  error?: string;
};

export function StudioClient({ initialTool }: { initialTool: string }) {
  const [toolId, setToolId] = useState(TOOL_MAP[initialTool] ? initialTool : TOOLS[0].id);
  const [prompt, setPrompt] = useState("");
  const [audience, setAudience] = useState("general");
  const [tone, setTone] = useState<string>("professional");
  const [fields, setFields] = useState<Record<string, string>>({});
  const [result, setResult] = useState<GenerateResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const tool = useMemo(() => TOOL_MAP[toolId] ?? TOOLS[0], [toolId]);

  useEffect(() => {
    setFields({});
  }, [toolId]);

  async function generate() {
    if (!prompt.trim() || busy) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ tool: toolId, prompt, tone, audience, fields, save: true }),
      });
      const data = (await response.json()) as GenerateResponse;
      if (!response.ok) throw new Error(data.error ?? "Generation failed");
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Generation failed");
    } finally {
      setBusy(false);
    }
  }

  const fieldValues = Object.values(fields).filter((value) => value && value.trim()).length;

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <header className="space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight text-white">Studio</h1>
        <p className="max-w-2xl text-sm leading-relaxed text-slate-400">
          Ten grounded generators. Every output is saved to your library, favoritable, and cites the knowledge entries
          it drew on.
        </p>
      </header>

      <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-5">
        {TOOLS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setToolId(item.id)}
            className={`rounded-xl border p-3 text-left transition ${
              toolId === item.id
                ? "border-cyan-300/50 bg-white/[0.08]"
                : "border-white/10 bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.05]"
            }`}
          >
            <span className="text-base">{item.icon}</span>
            <p className="mt-1.5 text-[13px] font-semibold leading-tight text-white">{item.name}</p>
            <p className="mt-0.5 text-[10px] uppercase tracking-wide text-slate-500">{item.tagline}</p>
          </button>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,420px)_1fr]">
        <div className="glass h-fit space-y-5 rounded-2xl p-5">
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-[0.16em] text-slate-500">{tool.promptLabel}</label>
            <textarea
              value={prompt}
              onChange={(event) => setPrompt(event.target.value)}
              rows={4}
              placeholder={tool.promptPlaceholder}
              className="w-full resize-none rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-3 text-[15px] text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
            />
          </div>

          {tool.fields.map((field) => (
            <div key={field.id} className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.16em] text-slate-500">{field.label}</label>
              {field.type === "select" ? (
                <select
                  value={fields[field.id] ?? field.options?.[0] ?? ""}
                  onChange={(event) => setFields((prev) => ({ ...prev, [field.id]: event.target.value }))}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none focus:border-cyan-300/40"
                >
                  {field.options?.map((option) => (
                    <option key={option} value={option} className="bg-slate-900">
                      {option}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  value={fields[field.id] ?? ""}
                  onChange={(event) => setFields((prev) => ({ ...prev, [field.id]: event.target.value }))}
                  placeholder={field.placeholder}
                  className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
                />
              )}
            </div>
          ))}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Audience</label>
              <input
                value={audience}
                onChange={(event) => setAudience(event.target.value)}
                placeholder="e.g. procurement leads"
                className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-300/40"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Tone</label>
              <select
                value={tone}
                onChange={(event) => setTone(event.target.value)}
                className="w-full rounded-xl border border-white/10 bg-white/[0.03] px-3.5 py-2.5 text-sm text-slate-100 outline-none focus:border-cyan-300/40"
              >
                {TONES.map((item) => (
                  <option key={item} value={item} className="bg-slate-900">
                    {item}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void generate()}
            disabled={busy || !prompt.trim()}
            className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-4 py-3 text-sm font-semibold text-slate-950 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {busy ? "Generating…" : `Generate ${tool.name}`}
          </button>
          <p className="text-[11px] text-slate-600">
            {prompt.trim() ? `${prompt.trim().split(/\s+/).length} words in · ${fieldValues} detail field(s)` : "Add a brief to enable generation"}
          </p>
        </div>

        <div className="glass min-h-[420px] rounded-2xl p-6">
          {busy && (
            <div className="flex h-full items-center justify-center gap-2">
              <span className="dot h-2 w-2 rounded-full bg-cyan-300" />
              <span className="dot h-2 w-2 rounded-full bg-cyan-300 [animation-delay:0.15s]" />
              <span className="dot h-2 w-2 rounded-full bg-cyan-300 [animation-delay:0.3s]" />
              <span className="ml-2 text-sm text-slate-500">running {tool.name.toLowerCase()}…</span>
            </div>
          )}

          {!busy && !result && (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <span className={`grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br ${tool.accent} text-2xl`}>
                {tool.icon}
              </span>
              <p className="text-sm font-semibold text-white">{tool.name}</p>
              <p className="max-w-sm text-[13px] leading-relaxed text-slate-500">{tool.description}</p>
            </div>
          )}

          {!busy && result?.output && (
            <div className="rise space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
                <div>
                  <p className="text-sm font-semibold text-white">{result.title}</p>
                  <p className="text-[11px] text-slate-500">
                    {tool.name} · tone {tone} · saved to library
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-lg bg-white/5 px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-slate-500">
                    {result.engine ?? "capson-engine"}
                  </span>
                  <CopyButton text={result.output} label="Copy markdown" />
                </div>
              </div>

              <Markdown content={result.output} />

              {result.grounding && result.grounding.length > 0 && (
                <div className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
                  <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Grounded in</p>
                  <ul className="mt-2 space-y-1">
                    {result.grounding.map((item) => (
                      <li key={item.title} className="text-[13px] text-slate-300">
                        {item.title} <span className="text-slate-600">· {item.category}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {!busy && error && <p className="text-center text-sm text-rose-400">{error}</p>}
        </div>
      </div>
    </div>
  );
}
