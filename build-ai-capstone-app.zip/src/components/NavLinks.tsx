"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "Overview", icon: "◎" },
  { href: "/chat", label: "Assistant", icon: "◍" },
  { href: "/studio", label: "Studio", icon: "◈" },
  { href: "/knowledge", label: "Knowledge", icon: "◇" },
  { href: "/library", label: "Library", icon: "▤" },
];

export function NavLinks() {
  const pathname = usePathname();
  return (
    <nav className="flex flex-col gap-1">
      {LINKS.map((link) => {
        const active = pathname === link.href;
        return (
          <Link
            key={link.href}
            href={link.href}
            className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition ${
              active
                ? "bg-white/10 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
                : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
            }`}
          >
            <span
              className={`grid h-7 w-7 place-items-center rounded-lg text-[13px] transition ${
                active ? "bg-gradient-to-br from-violet-500 to-cyan-400 text-slate-950" : "bg-white/5 text-slate-400"
              }`}
            >
              {link.icon}
            </span>
            {link.label}
          </Link>
        );
      })}
    </nav>
  );
}
