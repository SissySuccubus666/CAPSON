"use client";

import type { ReactNode } from "react";

/* Lightweight markdown renderer: headings, lists, tables, quotes, rules,
   inline bold/italic/code. No HTML injection, no extra dependencies. */

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const pattern = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let index = 0;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > lastIndex) nodes.push(text.slice(lastIndex, match.index));
    const token = match[0];
    const key = `${keyPrefix}-i${index++}`;
    if (token.startsWith("**")) {
      nodes.push(
        <strong key={key} className="font-semibold text-white">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("`")) {
      nodes.push(
        <code key={key} className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-[0.85em] text-cyan-200">
          {token.slice(1, -1)}
        </code>,
      );
    } else {
      nodes.push(
        <em key={key} className="italic text-slate-300">
          {token.slice(1, -1)}
        </em>,
      );
    }
    lastIndex = match.index + token.length;
  }
  if (lastIndex < text.length) nodes.push(text.slice(lastIndex));
  return nodes;
}

export function Markdown({ content }: { content: string }) {
  const lines = content.replace(/<!--[\s\S]*?-->/g, "").split("\n");
  const blocks: ReactNode[] = [];
  let listBuffer: string[] = [];
  let listType: "ul" | "ol" | null = null;
  let tableBuffer: string[] = [];
  let paragraphBuffer: string[] = [];
  let key = 0;

  const flushList = () => {
    if (!listBuffer.length || !listType) return;
    const items = listBuffer.map((item, idx) => (
      <li key={idx} className="pl-1 marker:text-cyan-400/80">
        {inline(item, `li-${key}-${idx}`)}
      </li>
    ));
    blocks.push(
      listType === "ul" ? (
        <ul key={`ul-${key++}`} className="my-2 list-disc space-y-1.5 pl-5 text-slate-300">
          {items}
        </ul>
      ) : (
        <ol key={`ol-${key++}`} className="my-2 list-decimal space-y-1.5 pl-5 text-slate-300">
          {items}
        </ol>
      ),
    );
    listBuffer = [];
    listType = null;
  };

  const flushTable = () => {
    if (tableBuffer.length < 2) {
      if (tableBuffer.length) paragraphBuffer.push(...tableBuffer);
      tableBuffer = [];
      return;
    }
    const rows = tableBuffer
      .map((row) => row.split("|").slice(1, -1).map((cell) => cell.trim()))
      .filter((cells) => !cells.every((cell) => /^-+$/.test(cell)));
    const [header, ...body] = rows;
    blocks.push(
      <div key={`table-${key++}`} className="my-3 overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full border-collapse text-left text-sm">
          <thead className="bg-white/5">
            <tr>
              {header.map((cell, idx) => (
                <th key={idx} className="px-3 py-2 text-xs font-semibold uppercase tracking-wide text-slate-300">
                  {inline(cell, `th-${idx}`)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {body.map((cells, rowIdx) => (
              <tr key={rowIdx} className="border-t border-white/5">
                {cells.map((cell, idx) => (
                  <td key={idx} className="px-3 py-2 text-slate-300">
                    {inline(cell, `td-${rowIdx}-${idx}`)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>,
    );
    tableBuffer = [];
  };

  const flushParagraph = () => {
    if (!paragraphBuffer.length) return;
    const text = paragraphBuffer.join(" ");
    blocks.push(
      <p key={`p-${key++}`} className="my-2 leading-relaxed text-slate-300">
        {inline(text, `p-${key}`)}
      </p>,
    );
    paragraphBuffer = [];
  };

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();

    if (/^\|.*\|/.test(line.trim())) {
      flushList();
      flushParagraph();
      tableBuffer.push(line.trim());
      continue;
    }
    flushTable();

    if (!line.trim()) {
      flushList();
      flushParagraph();
      continue;
    }

    if (/^###\s+/.test(line)) {
      flushList();
      flushParagraph();
      blocks.push(
        <h3 key={`h3-${key++}`} className="mt-4 mb-1 text-sm font-semibold uppercase tracking-wide text-cyan-300">
          {inline(line.replace(/^###\s+/, ""), `h3-${key}`)}
        </h3>,
      );
      continue;
    }
    if (/^##\s+/.test(line)) {
      flushList();
      flushParagraph();
      blocks.push(
        <h2 key={`h2-${key++}`} className="mt-5 mb-2 text-lg font-semibold text-white">
          {inline(line.replace(/^##\s+/, ""), `h2-${key}`)}
        </h2>,
      );
      continue;
    }
    if (/^#\s+/.test(line)) {
      flushList();
      flushParagraph();
      blocks.push(
        <h2 key={`h1-${key++}`} className="mt-5 mb-2 text-xl font-semibold text-white">
          {inline(line.replace(/^#\s+/, ""), `h1-${key}`)}
        </h2>,
      );
      continue;
    }
    if (/^(-{3,}|\*{3,})$/.test(line.trim())) {
      flushList();
      flushParagraph();
      blocks.push(<hr key={`hr-${key++}`} className="my-4 border-white/10" />);
      continue;
    }
    if (/^>\s?/.test(line)) {
      flushList();
      flushParagraph();
      blocks.push(
        <blockquote
          key={`bq-${key++}`}
          className="my-3 rounded-r-lg border-l-2 border-cyan-400/70 bg-cyan-400/5 px-4 py-2 text-slate-200"
        >
          {inline(line.replace(/^>\s?/, ""), `bq-${key}`)}
        </blockquote>,
      );
      continue;
    }
    if (/^[-*]\s+/.test(line)) {
      flushParagraph();
      if (listType === "ol") flushList();
      listType = "ul";
      listBuffer.push(line.replace(/^[-*]\s+/, ""));
      continue;
    }
    if (/^\d+\.\s+/.test(line)) {
      flushParagraph();
      if (listType === "ul") flushList();
      listType = "ol";
      listBuffer.push(line.replace(/^\d+\.\s+/, ""));
      continue;
    }

    flushList();
    paragraphBuffer.push(line.trim());
  }

  flushList();
  flushTable();
  flushParagraph();

  return <div className="text-[15px]">{blocks}</div>;
}
