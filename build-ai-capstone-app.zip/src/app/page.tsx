import Link from "next/link";
import { CopyButton } from "@/components/CopyButton";
import { PERSONAS } from "@/lib/ai/engine";
import { engineLabel } from "@/lib/ai/provider";
import { TOOLS } from "@/lib/ai/tools";
import { listKnowledge, workspaceStats } from "@/lib/data";

export const dynamic = "force-dynamic";

const QUICK_PROMPTS = [
  "What is our positioning against generic AI tools?",
  "Draft a follow-up email after a pricing call",
  "Give me a 90-day plan to grow self-serve revenue",
  "Write five taglines for Capson and explain the pick",
];

export default async function OverviewPage() {
  const [stats, knowledge] = await Promise.all([workspaceStats(), listKnowledge()]);

  const cards = [
    { label: "Knowledge entries", value: stats.knowledge, hint: "facts the AI grounds in" },
    { label: "Conversations", value: stats.conversations, hint: "saved threads" },
    { label: "Messages", value: stats.messages, hint: "total turns" },
    { label: "Studio outputs", value: stats.generations, hint: `${stats.favorites} favorited` },
  ];

  return (
    <div className="mx-auto max-w-6xl space-y-10">
      <header className="rise space-y-5">
        <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-slate-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          Engine online · <span className="font-mono lowercase tracking-normal">{engineLabel()}</span>
        </span>
        <h1 className="max-w-3xl text-4xl font-semibold leading-[1.1] tracking-tight text-white sm:text-5xl">
          Your AI workspace, grounded in{" "}
          <span className="bg-gradient-to-r from-violet-400 via-indigo-300 to-cyan-300 bg-clip-text text-transparent">
            what only you know
          </span>
          .
        </h1>
        <p className="max-w-2xl text-[15px] leading-relaxed text-slate-400">
          Capson answers questions, writes your copy and plans your next quarter using your own knowledge base — and
          shows exactly which entries it used. Ten studio tools, five personas, everything saved and searchable.
        </p>
        <div className="flex flex-wrap gap-3">
          <Link
            href="/chat"
            className="rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-semibold text-slate-950 transition hover:brightness-110"
          >
            Open the assistant
          </Link>
          <Link
            href="/studio"
            className="rounded-xl border border-white/15 bg-white/5 px-5 py-2.5 text-sm font-semibold text-slate-100 transition hover:bg-white/10"
          >
            Try the studio tools
          </Link>
          <Link
            href="/knowledge"
            className="rounded-xl border border-white/10 px-5 py-2.5 text-sm font-semibold text-slate-400 transition hover:border-white/20 hover:text-white"
          >
            Add brand facts
          </Link>
        </div>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="glass rounded-2xl p-5">
            <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">{card.label}</p>
            <p className="mt-2 text-3xl font-semibold text-white">{card.value}</p>
            <p className="mt-1 text-xs text-slate-500">{card.hint}</p>
          </div>
        ))}
      </section>

      <section className="space-y-4">
        <div className="flex items-baseline justify-between">
          <h2 className="text-lg font-semibold text-white">Studio tools</h2>
          <Link href="/studio" className="text-xs text-cyan-300 hover:text-cyan-200">
            Open studio →
          </Link>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {TOOLS.slice(0, 6).map((tool) => (
            <Link
              key={tool.id}
              href={`/studio?tool=${tool.id}`}
              className="glass group rounded-2xl p-5 transition hover:border-white/25 hover:bg-white/[0.07]"
            >
              <div
                className={`mb-3 grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${tool.accent} text-lg`}
              >
                {tool.icon}
              </div>
              <p className="text-sm font-semibold text-white">{tool.name}</p>
              <p className="mt-1 text-xs uppercase tracking-wide text-slate-500">{tool.tagline}</p>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{tool.description}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <div className="glass rounded-2xl p-5 lg:col-span-2">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">Start with a question</h2>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {QUICK_PROMPTS.map((prompt) => (
              <Link
                key={prompt}
                href={`/chat?q=${encodeURIComponent(prompt)}`}
                className="rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3 text-[13px] text-slate-300 transition hover:border-cyan-300/40 hover:text-white"
              >
                {prompt}
              </Link>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">Personas</h2>
          <ul className="mt-4 space-y-3">
            {Object.entries(PERSONAS).map(([id, persona]) => (
              <li key={id}>
                <p className="text-[13px] font-semibold text-slate-100">{persona.name}</p>
                <p className="text-xs leading-relaxed text-slate-500">{persona.blurb}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="glass rounded-2xl p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-[0.16em] text-slate-500">
            Knowledge the AI is using
          </h2>
          <Link href="/knowledge" className="text-xs text-cyan-300 hover:text-cyan-200">
            Manage →
          </Link>
        </div>
        <ul className="mt-4 space-y-3">
          {knowledge.slice(0, 5).map((item) => (
            <li key={item.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-[13px] font-semibold text-white">{item.title}</p>
                  <p className="text-[11px] uppercase tracking-wide text-slate-500">{item.category}</p>
                </div>
                <CopyButton text={item.content} />
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{item.content}</p>
            </li>
          ))}
          {knowledge.length === 0 && (
            <li className="rounded-xl border border-dashed border-white/15 p-6 text-center text-sm text-slate-500">
              No entries yet — add your first fact on the Knowledge page.
            </li>
          )}
        </ul>
      </section>
    </div>
  );
}
