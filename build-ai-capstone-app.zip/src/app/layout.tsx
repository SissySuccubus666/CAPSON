import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { NavLinks } from "@/components/NavLinks";
import { engineLabel } from "@/lib/ai/provider";
import "./globals.css";

export const metadata: Metadata = {
  title: "Capson AI Studio",
  description:
    "Capson is an AI workspace that grounds every answer and every draft in your own knowledge base.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const engine = engineLabel();
  return (
    <html lang="en">
      <body className="min-h-screen text-slate-200 antialiased">
        <div className="mx-auto flex min-h-screen w-full max-w-[1500px] flex-col lg:flex-row">
          <aside className="glass sticky top-0 z-20 flex shrink-0 flex-col gap-6 border-b border-white/10 px-5 py-5 lg:h-screen lg:w-[264px] lg:border-b-0 lg:border-r lg:px-5 lg:py-7">
            <Link href="/" className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-violet-500 via-indigo-500 to-cyan-400 text-base font-black text-slate-950">
                C
              </span>
              <span className="leading-tight">
                <span className="block text-[15px] font-semibold tracking-tight text-white">Capson</span>
                <span className="block text-[11px] uppercase tracking-[0.18em] text-slate-500">AI Studio</span>
              </span>
            </Link>

            <NavLinks />

            <div className="mt-auto hidden space-y-3 lg:block">
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <p className="text-[11px] uppercase tracking-[0.16em] text-slate-500">Engine</p>
                <p className="mt-1 flex items-center gap-2 text-sm text-slate-200">
                  <span className="h-2 w-2 rounded-full bg-emerald-400" />
                  <span className="font-mono text-[13px]">{engine}</span>
                </p>
                <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
                  Local generation engine, grounded in your knowledge base. Add an API key to route through a hosted
                  model instead.
                </p>
              </div>
            </div>
          </aside>

          <main className="grid-noise min-h-screen flex-1 px-4 py-6 sm:px-8 sm:py-10">{children}</main>
        </div>
      </body>
    </html>
  );
}
