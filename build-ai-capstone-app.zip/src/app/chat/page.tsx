import { ChatClient } from "@/components/ChatClient";

export const dynamic = "force-dynamic";

export default async function ChatPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  return (
    <div className="h-full">
      <ChatClient initialPrompt={q ?? ""} />
    </div>
  );
}
