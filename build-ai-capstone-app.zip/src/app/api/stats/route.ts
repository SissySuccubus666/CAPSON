import { engineLabel } from "@/lib/ai/provider";
import { workspaceStats } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const stats = await workspaceStats();
    return Response.json({ ...stats, engine: engineLabel() });
  } catch {
    return Response.json({ error: "Stats unavailable" }, { status: 500 });
  }
}
