import { db } from "@/db";
import { conversations } from "@/db/schema";
import { listConversations } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await listConversations();
  return Response.json({ conversations: rows });
}

export async function POST(request: Request) {
  let title = "New conversation";
  let persona = "generalist";
  try {
    const body = (await request.json()) as { title?: string; persona?: string };
    if (body.title?.trim()) title = body.title.trim().slice(0, 120);
    if (body.persona?.trim()) persona = body.persona.trim().slice(0, 40);
  } catch {
    // defaults are fine
  }
  const [created] = await db.insert(conversations).values({ title, persona }).returning();
  return Response.json({ conversation: created }, { status: 201 });
}
