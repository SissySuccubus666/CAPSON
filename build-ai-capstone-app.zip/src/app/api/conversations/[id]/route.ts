import { db } from "@/db";
import { conversations } from "@/db/schema";
import { listMessages } from "@/lib/data";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function GET(_request: Request, { params }: Params) {
  const { id } = await params;
  const conversationId = Number(id);
  if (!Number.isInteger(conversationId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  const [conversation] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId));
  if (!conversation) {
    return Response.json({ error: "Not found" }, { status: 404 });
  }
  const rows = await listMessages(conversationId);
  return Response.json({ conversation, messages: rows });
}

export async function PATCH(request: Request, { params }: Params) {
  const { id } = await params;
  const conversationId = Number(id);
  if (!Number.isInteger(conversationId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  const body = (await request.json().catch(() => ({}))) as { title?: string; persona?: string };
  const patch: Record<string, string | Date> = { updatedAt: new Date() };
  if (typeof body.title === "string" && body.title.trim()) patch.title = body.title.trim().slice(0, 120);
  if (typeof body.persona === "string" && body.persona.trim()) patch.persona = body.persona.trim().slice(0, 40);
  const [updated] = await db
    .update(conversations)
    .set(patch)
    .where(eq(conversations.id, conversationId))
    .returning();
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ conversation: updated });
}

export async function DELETE(_request: Request, { params }: Params) {
  const { id } = await params;
  const conversationId = Number(id);
  if (!Number.isInteger(conversationId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  await db.delete(conversations).where(eq(conversations.id, conversationId));
  return Response.json({ ok: true });
}
