import { db } from "@/db";
import { knowledgeItems } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const { id } = await params;
  const itemId = Number(id);
  if (!Number.isInteger(itemId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  const body = (await request.json().catch(() => ({}))) as {
    title?: string;
    category?: string;
    content?: string;
    tags?: string;
  };
  const patch: Record<string, string> = {};
  if (typeof body.title === "string" && body.title.trim()) patch.title = body.title.trim().slice(0, 160);
  if (typeof body.category === "string" && body.category.trim()) patch.category = body.category.trim().slice(0, 48);
  if (typeof body.content === "string" && body.content.trim()) patch.content = body.content.trim().slice(0, 4000);
  if (typeof body.tags === "string") patch.tags = body.tags.trim().slice(0, 240);
  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Nothing to update" }, { status: 400 });
  }
  const [updated] = await db
    .update(knowledgeItems)
    .set(patch)
    .where(eq(knowledgeItems.id, itemId))
    .returning();
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ item: updated });
}

export async function DELETE(_request: Request, { params }: Params) {
  const { id } = await params;
  const itemId = Number(id);
  if (!Number.isInteger(itemId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  await db.delete(knowledgeItems).where(eq(knowledgeItems.id, itemId));
  return Response.json({ ok: true });
}
