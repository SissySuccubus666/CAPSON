import { db } from "@/db";
import { knowledgeItems } from "@/db/schema";
import { listKnowledge } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await listKnowledge();
  return Response.json({ knowledge: rows });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    title?: string;
    category?: string;
    content?: string;
    tags?: string;
  };
  const title = (body.title ?? "").trim();
  const content = (body.content ?? "").trim();
  if (!title || !content) {
    return Response.json({ error: "Title and content are required" }, { status: 400 });
  }
  const [created] = await db
    .insert(knowledgeItems)
    .values({
      title: title.slice(0, 160),
      category: (body.category ?? "General").trim().slice(0, 48) || "General",
      content: content.slice(0, 4000),
      tags: (body.tags ?? "").trim().slice(0, 240),
    })
    .returning();
  return Response.json({ item: created }, { status: 201 });
}
