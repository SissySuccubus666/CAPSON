import { db } from "@/db";
import { generations } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const { id } = await params;
  const generationId = Number(id);
  if (!Number.isInteger(generationId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  const body = (await request.json().catch(() => ({}))) as { favorite?: boolean };
  const [updated] = await db
    .update(generations)
    .set({ favorite: Boolean(body.favorite) })
    .where(eq(generations.id, generationId))
    .returning();
  if (!updated) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ generation: updated });
}

export async function DELETE(_request: Request, { params }: Params) {
  const { id } = await params;
  const generationId = Number(id);
  if (!Number.isInteger(generationId)) {
    return Response.json({ error: "Invalid id" }, { status: 400 });
  }
  await db.delete(generations).where(eq(generations.id, generationId));
  return Response.json({ ok: true });
}
