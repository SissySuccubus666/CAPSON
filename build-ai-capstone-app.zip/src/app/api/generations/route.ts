import { listGenerations } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const favoritesOnly = url.searchParams.get("favorites") === "1";
  const rows = await listGenerations(favoritesOnly);
  return Response.json({ generations: rows });
}
