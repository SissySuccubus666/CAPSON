import { db } from "@/db";
import { generations } from "@/db/schema";
import { isTone, runTool, type Tone } from "@/lib/ai/engine";
import { remoteComplete } from "@/lib/ai/provider";
import { isToolId, TOOL_MAP } from "@/lib/ai/tools";
import { listKnowledge } from "@/lib/data";

export const dynamic = "force-dynamic";

type Body = {
  tool?: string;
  prompt?: string;
  tone?: string;
  audience?: string;
  fields?: Record<string, string>;
  save?: boolean;
};

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as Body;
  const toolId = body.tool ?? "";
  const prompt = (body.prompt ?? "").trim();

  if (!isToolId(toolId)) {
    return Response.json({ error: "Unknown tool" }, { status: 400 });
  }
  if (!prompt) {
    return Response.json({ error: "A prompt is required" }, { status: 400 });
  }

  const tool = TOOL_MAP[toolId];
  const tone: Tone = isTone(body.tone ?? "") ? (body.tone as Tone) : "professional";
  const audience = (body.audience ?? "general").trim().slice(0, 64) || "general";
  const fields = body.fields ?? {};

  const knowledge = await listKnowledge();
  const local = runTool({ tool: toolId, prompt, tone, audience, fields, knowledge });

  const knowledgeContext = knowledge
    .map((item) => `- [${item.category}] ${item.title}: ${item.content}`)
    .join("\n");

  const fieldLines = Object.entries(fields)
    .filter(([, value]) => value && value.trim())
    .map(([key, value]) => `- ${key}: ${value}`)
    .join("\n");

  const system = `You are Capson, running the "${tool.name}" tool in Capson AI Studio.
Deliver ${tool.tagline.toLowerCase()} in clean markdown with short headings, tight bullets and tables where useful.
Tone: ${tone}. Audience: ${audience}.
Be specific and decision-changing. Never use hype adjectives. Do not add a preamble or a closing disclaimer.
Ground the output in the KNOWLEDGE section when relevant.

KNOWLEDGE:
${knowledgeContext || "(none)"}`;

  const userPrompt = `Brief: ${prompt}
${fieldLines ? `Additional inputs:\n${fieldLines}` : ""}
Knowledge entries used for grounding: ${
    local.grounding.length ? local.grounding.map((item) => item.title).join(", ") : "none matched"
  }`;

  let output = local.output;
  let engine = "capson-engine";
  const remote = await remoteComplete(system, [{ role: "user", content: userPrompt }]);
  if (remote) {
    output = remote.text;
    engine = remote.provider.id;
  }

  const shouldSave = body.save !== false;
  let saved = null;
  if (shouldSave) {
    const [row] = await db
      .insert(generations)
      .values({
        tool: toolId,
        title: local.title,
        prompt: prompt.slice(0, 2000),
        tone,
        audience,
        output,
        engine,
        meta: { grounding: local.grounding.length, fields: Object.keys(fields).length },
      })
      .returning();
    saved = row;
  }

  return Response.json({
    output,
    engine,
    title: local.title,
    grounding: local.grounding,
    saved,
  });
}
