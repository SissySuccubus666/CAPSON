import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { chatReply, isPersona, type ChatTurn } from "@/lib/ai/engine";
import { remoteComplete } from "@/lib/ai/provider";
import { listKnowledge, makeTitle } from "@/lib/data";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Body = {
  conversationId?: number | null;
  message?: string;
  persona?: string;
};

export async function POST(request: Request) {
  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const text = (body.message ?? "").trim();
  if (!text) {
    return Response.json({ error: "Message is required" }, { status: 400 });
  }
  const persona = isPersona(body.persona ?? "") ? (body.persona as string) : "generalist";

  const knowledge = await listKnowledge();
  const knowledgeContext = knowledge
    .map((item) => `- [${item.category}] ${item.title}: ${item.content}`)
    .join("\n");

  let conversationId = body.conversationId ?? null;

  if (!conversationId) {
    const [created] = await db
      .insert(conversations)
      .values({ title: makeTitle(text), persona })
      .returning({ id: conversations.id });
    conversationId = created.id;
  } else {
    const [existing] = await db
      .select({ id: conversations.id, persona: conversations.persona })
      .from(conversations)
      .where(eq(conversations.id, conversationId));
    if (!existing) {
      return Response.json({ error: "Conversation not found" }, { status: 404 });
    }
  }

  await db.insert(messages).values({ conversationId, role: "user", content: text });

  const history = await db
    .select({ role: messages.role, content: messages.content })
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.id);

  const turns: ChatTurn[] = history.map((row) => ({
    role: row.role === "assistant" ? "assistant" : "user",
    content: row.content,
  }));

  const personaBrief = {
    generalist: "a balanced generalist assistant",
    strategist: "a sharp business strategist focused on sequencing, bets and measurable outcomes",
    marketer: "a positioning and copy expert who writes in the customer's language",
    engineer: "a pragmatic engineer focused on mechanics, tradeoffs and failure modes",
    coach: "a direct, warm coach who always ends with a concrete next action",
  }[persona] ?? "a balanced assistant";

  const system = `You are Capson, ${personaBrief}. You are running inside Capson AI Studio.
Rules:
- Ground every answer in the KNOWLEDGE section when it is relevant, and say which entries you used.
- Use markdown with short headings, tight bullets and tables where they help.
- Prefer specific, decision-changing content over filler. No hype adjectives.
- End with a concrete next action when it helps.

KNOWLEDGE:
${knowledgeContext || "(no knowledge base entries yet)"}`;

  const local = chatReply({ history: turns, persona, knowledge });
  let content = local.content;
  let engine = "capson-engine";

  const remote = await remoteComplete(
    system,
    turns.slice(-12).map((turn) => ({ role: turn.role === "assistant" ? "assistant" : "user", content: turn.content })),
  );
  if (remote) {
    content = remote.text;
    engine = remote.provider.id;
  }

  const [assistantMessage] = await db
    .insert(messages)
    .values({ conversationId, role: "assistant", content, engine })
    .returning();

  const [thread] = await db
    .update(conversations)
    .set({ updatedAt: new Date(), persona })
    .where(eq(conversations.id, conversationId))
    .returning({ id: conversations.id, title: conversations.title });

  return Response.json({
    conversationId,
    title: thread?.title ?? makeTitle(text),
    message: assistantMessage,
    engine,
    grounding: local.grounding,
  });
}
