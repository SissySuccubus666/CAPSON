import { KnowledgeClient } from "@/components/KnowledgeClient";

export const dynamic = "force-dynamic";

export default function KnowledgePage() {
  return <KnowledgeClient />;
}
