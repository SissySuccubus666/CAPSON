import { StudioClient } from "@/components/StudioClient";

export const dynamic = "force-dynamic";

export default async function StudioPage({
  searchParams,
}: {
  searchParams: Promise<{ tool?: string }>;
}) {
  const { tool } = await searchParams;
  return <StudioClient initialTool={tool ?? ""} />;
}
