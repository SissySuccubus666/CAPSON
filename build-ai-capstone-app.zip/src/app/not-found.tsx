import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center justify-center gap-4 py-24 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 to-cyan-400 text-xl font-black text-slate-950">
        C
      </span>
      <h1 className="text-2xl font-semibold text-white">That page is not part of the workspace</h1>
      <p className="text-sm text-slate-400">
        Try the assistant, the studio tools, or your knowledge base instead.
      </p>
      <Link
        href="/"
        className="rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-semibold text-slate-950"
      >
        Back to overview
      </Link>
    </div>
  );
}
