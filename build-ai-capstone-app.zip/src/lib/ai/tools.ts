export type ToolField = {
  id: string;
  label: string;
  placeholder: string;
  type?: "text" | "textarea" | "select";
  options?: string[];
  optional?: boolean;
};

export type ToolDefinition = {
  id: string;
  name: string;
  icon: string;
  tagline: string;
  description: string;
  promptLabel: string;
  promptPlaceholder: string;
  fields: ToolField[];
  accent: string;
};

export const TONES = [
  "professional",
  "friendly",
  "bold",
  "playful",
  "luxury",
  "technical",
] as const;

export type Tone = (typeof TONES)[number];

export const TOOLS: ToolDefinition[] = [
  {
    id: "tagline",
    name: "Tagline Forge",
    icon: "✨",
    tagline: "Positioning lines & slogans",
    description:
      "Generates a spread of taglines with the strategic reasoning behind each option.",
    promptLabel: "What are we naming or positioning?",
    promptPlaceholder: "Capson — an AI workspace for small industrial suppliers",
    fields: [
      {
        id: "benefit",
        label: "Core benefit",
        placeholder: "Cuts quote turnaround from days to minutes",
      },
    ],
    accent: "from-violet-500 to-fuchsia-500",
  },
  {
    id: "value-prop",
    name: "Value Proposition",
    icon: "🎯",
    tagline: "Positioning & messaging",
    description:
      "Builds a full positioning statement, proof points, and objection handling.",
    promptLabel: "Product or offer",
    promptPlaceholder: "Capson AI Studio for manufacturing sales teams",
    fields: [
      { id: "audience", label: "Who it's for", placeholder: "Quoting teams at mid-size distributors" },
      { id: "differentiator", label: "Key differentiator", placeholder: "Grounded in your own product data" },
    ],
    accent: "from-sky-500 to-cyan-400",
  },
  {
    id: "product-copy",
    name: "Product Copy",
    icon: "📦",
    tagline: "Listing & landing copy",
    description:
      "Long-form product copy with headline variants, features rewritten as benefits, and a CTA.",
    promptLabel: "Product details",
    promptPlaceholder: "Wireless vibration sensor with 3-year battery, MQTT output",
    fields: [
      { id: "specs", label: "Specs worth mentioning", placeholder: "IP67, 3-year battery, 200Hz sampling" },
    ],
    accent: "from-emerald-500 to-teal-400",
  },
  {
    id: "email",
    name: "Email Composer",
    icon: "✉️",
    tagline: "Outbound & follow-up",
    description: "Subject lines, body copy, and a follow-up cadence for one goal.",
    promptLabel: "What is the email about?",
    promptPlaceholder: "Following up after a demo with a procurement lead",
    fields: [
      { id: "goal", label: "Desired outcome", placeholder: "Book a 20-minute technical review" },
    ],
    accent: "from-amber-500 to-orange-500",
  },
  {
    id: "blog-outline",
    name: "Content Architect",
    icon: "📝",
    tagline: "Outlines & drafts",
    description: "SEO-aware outline, section briefs, and meta description for an article.",
    promptLabel: "Article topic",
    promptPlaceholder: "Why grounded AI beats generic AI in B2B quoting",
    fields: [
      { id: "keyword", label: "Primary keyword", placeholder: "AI quoting software" },
    ],
    accent: "from-rose-500 to-pink-500",
  },
  {
    id: "strategy",
    name: "Strategy Sprint",
    icon: "🧭",
    tagline: "Plans & roadmaps",
    description: "A 90-day plan with bets, milestones, risks, and how to measure progress.",
    promptLabel: "Initiative or problem",
    promptPlaceholder: "Grow self-serve revenue without adding sales headcount",
    fields: [
      { id: "constraint", label: "Main constraint", placeholder: "Team of 4, no paid budget" },
    ],
    accent: "from-indigo-500 to-blue-500",
  },
  {
    id: "swot",
    name: "SWOT Analyst",
    icon: "⚖️",
    tagline: "Decision support",
    description: "Structured SWOT plus a recommendation and the assumptions to validate.",
    promptLabel: "Decision, company, or idea",
    promptPlaceholder: "Expanding into the Mexican industrial market",
    fields: [
      { id: "context", label: "Extra context", placeholder: "2 competitors, 60-day cash runway" },
    ],
    accent: "from-slate-400 to-slate-200",
  },
  {
    id: "social",
    name: "Social Pack",
    icon: "📣",
    tagline: "Multi-channel posts",
    description: "A week of channel-native posts built from one announcement.",
    promptLabel: "Announcement",
    promptPlaceholder: "We shipped the new quote comparison view",
    fields: [
      {
        id: "channel",
        label: "Primary channel",
        type: "select",
        placeholder: "LinkedIn",
        options: ["LinkedIn", "X / Twitter", "Instagram", "TikTok", "Newsletter"],
      },
    ],
    accent: "from-fuchsia-500 to-purple-600",
  },
  {
    id: "faq",
    name: "FAQ Builder",
    icon: "❓",
    tagline: "Support & sales enablement",
    description: "Customer questions grouped by theme with answers you can ship.",
    promptLabel: "Product or policy",
    promptPlaceholder: "Capson's usage-based pricing tiers",
    fields: [
      { id: "audience", label: "Who asks these questions", placeholder: "New self-serve customers" },
    ],
    accent: "from-cyan-500 to-sky-600",
  },
  {
    id: "job-post",
    name: "Role Brief",
    icon: "🧑‍💻",
    tagline: "Hiring copy",
    description: "A job post, scorecard, and interview loop for a role.",
    promptLabel: "Role to hire",
    promptPlaceholder: "Founding full-stack engineer",
    fields: [
      { id: "mission", label: "Team mission", placeholder: "Ship the grounded AI engine" },
    ],
    accent: "from-lime-500 to-emerald-500",
  },
];

export const TOOL_MAP: Record<string, ToolDefinition> = Object.fromEntries(
  TOOLS.map((tool) => [tool.id, tool]),
);

export function isToolId(id: string): boolean {
  return Boolean(TOOL_MAP[id]);
}
