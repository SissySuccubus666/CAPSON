import type { KnowledgeItem } from "@/db/schema";
import type { Tone } from "./tools";

export type { Tone };

/* -------------------------------------------------------------------------- */
/*  Text utilities                                                            */
/* -------------------------------------------------------------------------- */

const STOP_WORDS = new Set(
  `a an the and or but if then than that this these those of for to in on at by with from into about as is are was were be been being it its it's we you they i our your their how what why when where which who whom can could should would will do does did have has had not no nor so too very just more most other some such only own same s t don now me my he she them us out up down over under again further once here there all any both each few own s
  `
    .split(/\s+/)
    .filter(Boolean),
);

export function keywords(input: string): string[] {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((word) => word.length > 2 && !STOP_WORDS.has(word));
}

function titleCase(input: string): string {
  return input
    .split(/\s+/)
    .map((word) => (word.length > 3 ? word[0].toUpperCase() + word.slice(1) : word))
    .join(" ")
    .trim();
}

function sentence(input: string): string {
  const trimmed = input.trim().replace(/\s+/g, " ");
  if (!trimmed) return "";
  const first = trimmed[0].toUpperCase() + trimmed.slice(1);
  return /[.!?]$/.test(first) ? first : `${first}.`;
}

function stripTrailingPeriod(input: string): string {
  return input.trim().replace(/[.\s]+$/, "");
}

function pick<T>(items: T[], seed: number): T {
  return items[Math.abs(seed) % items.length];
}

function hash(input: string): number {
  let value = 0;
  for (let i = 0; i < input.length; i += 1) {
    value = (value * 31 + input.charCodeAt(i)) | 0;
  }
  return value;
}

function tidy(item: string): string {
  return item.trim().replace(/\s+/g, " ").replace(/\.\s*$/, ".");
}

function bullets(items: string[]): string {
  return items.filter(Boolean).map((item) => `- ${tidy(item)}`).join("\n");
}

function numbered(items: string[]): string {
  return items.filter(Boolean).map((item, index) => `${index + 1}. ${tidy(item)}`).join("\n");
}

/* -------------------------------------------------------------------------- */
/*  Tone lexicon                                                              */
/* -------------------------------------------------------------------------- */

const TONE_VOICE: Record<Tone, { label: string; adjectives: string[]; verbs: string[]; closer: string }> = {
  professional: {
    label: "Professional",
    adjectives: ["dependable", "measurable", "well-governed", "operationally sound"],
    verbs: ["streamline", "validate", "operationalize", "de-risk"],
    closer: "Every claim above maps to something you can measure within one reporting cycle.",
  },
  friendly: {
    label: "Friendly",
    adjectives: ["approachable", "human", "straightforward", "genuinely useful"],
    verbs: ["simplify", "unpack", "walk through", "make sense of"],
    closer: "Nothing here needs a manual — start with the smallest version and build from there.",
  },
  bold: {
    label: "Bold",
    adjectives: ["unmistakable", "fast-moving", "unapologetic", "category-defining"],
    verbs: ["own", "compress", "outpace", "redefine"],
    closer: "Move before the market makes the decision for you.",
  },
  playful: {
    label: "Playful",
    adjectives: ["delightful", "punchy", "unreasonably fun", "easy to love"],
    verbs: ["sprinkle", "turbocharge", "nerd out on", "level up"],
    closer: "Ship it, watch the replies, then do more of whatever worked.",
  },
  luxury: {
    label: "Luxury",
    adjectives: ["considered", "quietly confident", "precision-made", "rarefied"],
    verbs: ["elevate", "refine", "curate", "perfect"],
    closer: "Restraint is the strategy: fewer words, higher signal.",
  },
  technical: {
    label: "Technical",
    adjectives: ["deterministic", "auditable", "low-latency", "reproducible"],
    verbs: ["instrument", "benchmark", "hardened", "validate"],
    closer: "Assume nothing: instrument each step and keep a rollback path.",
  },
};

export function isTone(value: string): value is Tone {
  return value in TONE_VOICE;
}

/* -------------------------------------------------------------------------- */
/*  Knowledge retrieval                                                       */
/* -------------------------------------------------------------------------- */

export type Grounding = { title: string; category: string; content: string; score: number };

export function retrieveKnowledge(
  query: string,
  knowledge: Pick<KnowledgeItem, "title" | "category" | "content" | "tags">[],
  limit = 3,
): Grounding[] {
  const terms = [...keywords(query), ...keywords(query).map((word) => word.slice(0, Math.max(4, word.length - 2)))];
  const scored = knowledge
    .map((item) => {
      const haystack = `${item.title} ${item.category} ${item.tags} ${item.content}`.toLowerCase();
      let score = 0;
      for (const term of terms) {
        if (!term) continue;
        if (haystack.includes(term)) score += term.length > 6 ? 3 : 2;
        if (item.title.toLowerCase().includes(term)) score += 4;
        if (item.tags.toLowerCase().includes(term)) score += 3;
      }
      return { title: item.title, category: item.category, content: item.content, score };
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score);
  return scored.slice(0, limit);
}

function groundingSection(matches: Grounding[]): string {
  if (!matches.length) return "";
  return `\n\n---\n\n**Grounded in your knowledge base**\n${bullets(
    matches.map((match) => `**${match.title}** *(${match.category})* — ${sentence(match.content)}`),
  )}`;
}

function knowledgeFacts(matches: Grounding[]): string[] {
  return matches.map((match) => stripTrailingPeriod(match.content));
}

/* -------------------------------------------------------------------------- */
/*  Studio tool generation                                                    */
/* -------------------------------------------------------------------------- */

export type ToolRequest = {
  tool: string;
  prompt: string;
  tone: Tone;
  audience: string;
  fields: Record<string, string>;
  knowledge: Pick<KnowledgeItem, "title" | "category" | "content" | "tags">[];
};

export type ToolResult = {
  output: string;
  title: string;
  grounding: Grounding[];
};

const PREFIX_LABELS: Record<string, string> = {
  tagline: "Tagline set",
  "value-prop": "Value proposition",
  "product-copy": "Product copy",
  email: "Email draft",
  "blog-outline": "Content outline",
  strategy: "Strategy sprint",
  swot: "SWOT analysis",
  social: "Social pack",
  faq: "FAQ set",
  "job-post": "Role brief",
};

function audienceLabel(audience: string): string {
  const trimmed = audience.trim();
  if (!trimmed || /^general$/i.test(trimmed)) return "a general business audience";
  return trimmed.replace(/^for\s+/i, "");
}

export function runTool(request: ToolRequest): ToolResult {
  const { tool, tone } = request;
  const subject = stripTrailingPeriod(request.prompt || "your offering");
  const shortSubject = subject.split(/[.,;]/)[0] || subject;
  const audience = audienceLabel(request.audience);
  const fields = request.fields ?? {};
  const voice = TONE_VOICE[tone] ?? TONE_VOICE.professional;
  const seed = hash(`${tool}|${subject}|${tone}|${request.audience}`);
  const matches = retrieveKnowledge(`${subject} ${Object.values(fields).join(" ")}`, request.knowledge);
  const facts = knowledgeFacts(matches);

  let output = "";

  switch (tool) {
    case "tagline": {
      const benefit = stripTrailingPeriod(fields.benefit || facts[0] || "the work gets done faster");
      const outcome = benefitPhrase(benefit);
      const patterns = [
        `${titleCase(shortSubject)}. ${titleCase(benefit)}.`,
        `${titleCase(benefit)} — powered by ${titleCase(shortSubject)}.`,
        `Less friction. More ${titleCase(outcome)}.`,
        `${titleCase(shortSubject)} for teams that measure ${outcome}.`,
        `Where ${outcome} becomes the default.`,
        `${titleCase(shortSubject)}. Built for ${audience}.`,
        `Ship ${outcome} before lunch.`,
      ];
      output = `## Tagline options for ${titleCase(shortSubject)}\n\n${numbered(
        patterns.map((line) => `**${line}**`),
      )}\n\n### Why these work\n${bullets([
        `Each line leads with the outcome (${sentence(benefit.toLowerCase())}), not the feature.`,
        `Three lengths are represented: 4–5 words for a logo lockup, ~8 words for a homepage hero, and a longer line for ads.`,
        `The vocabulary is tuned to a ${voice.label.toLowerCase()} register: ${voice.adjectives.join(", ")}.`,
      ])}\n\n### Recommended pick\n> **${pick(patterns, seed)}**\n\n### Where to use each\n${bullets([
        "Header/hero: the shortest line, no supporting sentence.",
        "Ads & packaging: pair the pick with one proof number.",
        "Sales decks: the longest line plus the differentiator slide.",
      ])}`;
      break;
    }

    case "value-prop": {
      const target = audienceLabel(fields.audience || request.audience);
      const differentiator = stripTrailingPeriod(
        fields.differentiator || facts[0] || "it is grounded in your own data instead of generic templates",
      );
      const edge = cleanClause(differentiator);
      const need = pick(
        [
          "a faster path from a request to a finished result",
          "output that is specific to their business instead of merely plausible",
          "senior-quality work without hiring for it",
        ],
        seed,
      );
      output = `## Positioning for ${titleCase(shortSubject)}\n\n### Positioning statement\n> For **${target}** who need ${need}, **${titleCase(shortSubject)}** is the ${voice.adjectives[0]} option — ${edge}. Unlike generic alternatives, it takes on the whole workflow instead of one step.\n\n### Message hierarchy\n${numbered([
        `**Primary promise (10 words max):** ${titleCase(shortSubject)} — ${edge}, built for ${target}.`,
        `**Reason to believe:** ${facts[0] ? sentence(facts[0]) : `It runs on your own context, so every output is specific instead of plausible-sounding.`}`,
        `**Proof point:** a before/after metric captured in the first two weeks of use.`,
        `**Risk reversal:** a pilot scoped to one workflow, one owner, one success metric.`,
      ])}\n\n### Objection handling\n${bullets([
        `"We already have a tool for this." → Reframe around the handoff cost between tools, not the tools themselves.`,
        `"It won't know our business." → Point at the knowledge base: ${facts.length ? `${facts.length} grounded fact(s) informed this draft` : "upload your docs and the same draft regenerates in your language"}.`,
        `"Too early for us." → Offer a 5-day, one-workflow pilot with a written success metric.`,
        `"What does it cost to switch?" → Show the migration path as a checklist with hours, not weeks.`,
      ])}\n\n### One-liner for the top of the funnel\n**${titleCase(shortSubject)}** — ${voice.adjectives[1]} by design, built for ${target}.`;
      break;
    }

    case "product-copy": {
      const specs = (fields.specs || facts[0] || "").split(/[,\n]/).map((item) => item.trim()).filter(Boolean);
      output = `## ${titleCase(shortSubject)}\n\n### Headline variants\n${numbered([
        `**${titleCase(shortSubject)}**, built so you stop babysitting it.`,
        `**${titleCase(shortSubject)}** — ${voice.adjectives[0]} where it counts.`,
        `Meet **${titleCase(shortSubject)}**: everything you need, nothing you don't.`,
      ])}\n\n### Subheadline\n${sentence(
        `${titleCase(shortSubject)} is designed for ${audience}, with a ${voice.adjectives[1]} experience that holds up on the worst day of the week, not just the demo.`,
      )}\n\n### Features rewritten as benefits\n${
        specs.length
          ? bullets(
              specs.map((spec) => {
                const clean = stripTrailingPeriod(spec);
                return `**${titleCase(clean)}** — so ${audience} can ${voice.verbs[0]} the workflow without a support ticket.`;
              }),
            )
          : bullets([
              `**Set up in an afternoon** — so ${audience} start on value this week.`,
              `**Works with what you already use** — so nothing gets re-keyed.`,
              `**Readable output** — so anyone on the team can ${voice.verbs[1]} the result.`,
            ])
      }\n\n### Body copy\n${sentence(
        `Most teams do not need more software; they need the work they already do to take fewer steps`,
      )} That is the whole idea behind ${titleCase(shortSubject)}. ${
        facts[0] ? sentence(facts[0]) : "You add your own context once, and everything after that is specific to you."
      } Every part of the product is judged against one question: does this remove a step?\n\n### Call to action\n**Start with one workflow.** ${
        voice.closer
      }`;
      break;
    }

    case "email": {
      const goal = stripTrailingPeriod(fields.goal || "book the next 20-minute conversation");
      const emailTopic = shortSubject
        .replace(/^(following up (on|after)|following up|re:?\s*|about|regarding|touching base (on|about))\s*/i, "")
        .replace(/\s+/g, " ")
        .trim() || shortSubject;
      output = `## Email draft — ${titleCase(shortSubject)}\n\n### Subject lines to test\n${bullets([
        `Quick follow-up: ${emailTopic.toLowerCase()}`,
        `One question about ${emailTopic.toLowerCase()}`,
        `Worth 20 minutes on ${emailTopic.toLowerCase()}?`,
        `${titleCase(emailTopic)} — next step`,
      ])}\n\n### Email body\n\nHi {{first_name}},\n\n${sentence(
        `Thanks for the time — circling back on ${emailTopic.toLowerCase()}`,
      )}\n\nThe part I keep thinking about: ${
        facts[0] ? sentence(facts[0]) : `you mentioned the current process eats more time than anyone planned for.`
      }\n\nHere is what I would suggest as the next step:\n\n${bullets([
        `A 20-minute working session to ${goal.toLowerCase()}.`,
        "Bring one real example — we will use it live rather than walking through slides.",
        "If it is not a fit, I will say so on the call.",
      ])}\n\nDoes Thursday or Friday work better?\n\nBest,\n{{sender_name}}\n\n### Follow-up cadence\n${numbered([
        `**Day 0** — send the email above.`,
        `**Day 3** — one-line bump: "Floating this back up in case it got buried."`,
        `**Day 8** — add value, don't ask again: share a short note or example relevant to ${shortSubject.toLowerCase()}.`,
        `**Day 15** — close the loop: "Assuming this isn't a priority this quarter — I'll stop here."`,
      ])}\n\n### Tone notes\n${
        voice.label === "Bold" || voice.label === "Playful"
          ? "Short sentences. One ask. No hedging words."
          : "Warm but specific — lead with their context, not your product."
      }`;
      break;
    }

    case "blog-outline": {
      const keyword = stripTrailingPeriod(fields.keyword || subject);
      output = `## Outline — "${titleCase(subject)}"\n\n**Target keyword:** ${keyword}\n**Primary reader:** ${audience}\n**Working title options:**\n${bullets([
        `${titleCase(subject)}: What Actually Changes`,
        `The Honest Guide to ${titleCase(subject)}`,
        `${titleCase(keyword)} — a practitioner's breakdown`,
      ])}\n\n### Structure\n${numbered([
        `**Hook (120 words)** — Open with the cost of the status quo. ${facts[0] ? sentence(facts[0]) : "Name the number nobody publishes."}`,
        `**The problem, restated precisely (250 words)** — Separate the symptom from the mechanism. Most writing on ${keyword.toLowerCase()} skips this.`,
        `**The framework (600 words)** — 3 named steps, each with: what it is, what it replaces, how to tell it worked.`,
        `**Worked example (400 words)** — One concrete before/after. Include the messy middle, not just the happy path.`,
        `**Common failure modes (300 words)** — What goes wrong, why, and the cheap fix.`,
        `**What to do Monday (150 words)** — A checklist of three actions.`,
      ])}\n\n### Section briefs\n${bullets([
        "**Framework section** — each step needs a one-sentence definition that would survive being quoted out of context.",
        "**Worked example** — use real numbers, rounded, with a note on how they were measured.",
        "**Failure modes** — three items maximum; more reads as filler.",
      ])}\n\n### Meta description (under 155 characters)\n> ${sentence(
    `A practical breakdown of ${keyword.toLowerCase()}, with a framework, a worked example, and the failure modes to avoid`,
  ).slice(0, 152)}\n\n### Internal linking\n${bullets([
        `Link the framework section to your product page for ${titleCase(shortSubject)} when the reader is primed for a solution.`,
        "Link the failure-mode section to your most concrete case study.",
      ])}`;
      break;
    }

    case "strategy": {
      const constraint = stripTrailingPeriod(fields.constraint || facts[0] || "limited team and budget");
      output = `## 90-day sprint — ${titleCase(shortSubject)}\n\n### The bet\n${
        sentence(`We believe ${audience} will adopt ${shortSubject.toLowerCase()} if we remove the setup cost entirely`)
      } If that is wrong, we learn it by day 45 rather than day 90.\n\n### Constraint we design around\n> ${titleCase(constraint)}\n\n### Phase 1 — Days 1–30: prove the mechanism\n${bullets([
        `Pick **one** workflow touched by ${shortSubject.toLowerCase()} and instrument it end to end.`,
        "Write the success metric as a number with a baseline captured *before* anything ships.",
        `Ship the smallest ${voice.adjectives[2]} version — ugly is fine, unmeasured is not.`,
      ])}\n\n### Phase 2 — Days 31–60: find the repeatability\n${bullets([
        "Run the same play with three more instances of the workflow.",
        "Log where humans had to intervene; that list is your roadmap.",
        "Kill anything that needs a bespoke explanation to a new teammate.",
      ])}\n\n### Phase 3 — Days 61–90: compound it\n${bullets([
        "Automate the top two manual interventions from Phase 2.",
        "Document the play so someone else can run it without you.",
        "Decide: scale this bet, or stop and take the learning.",
      ])}\n\n### Milestones\n| Day | Milestone | Evidence |\n| --- | --- | --- |\n| 15 | First end-to-end run | Recorded walkthrough |\n| 30 | Baseline vs. new metric | One-page comparison |\n| 60 | Repeated 3× | Consistent result across runs |\n| 90 | Go / no-go decision | Written memo |\n\n### Risks\n${bullets([
        `**Attention risk** — ${titleCase(constraint)} means partial focus. Assign a single owner with protected hours.`,
        "**Measurement risk** — no baseline means no story. Capture it on day one.",
        "**Scope risk** — the second workflow is a phase-3 decision, not a phase-1 detour.",
      ])}\n\n### How we will know it worked\n${numbered([
        "The chosen metric moved by a number you would put in a company-wide update.",
        "The play ran at least once without you in the room.",
        "Someone asked to use it — unprompted.",
      ])}`;
      break;
    }

    case "swot": {
      const context = fields.context || facts[0] || "";
      output = `## SWOT — ${titleCase(shortSubject)}\n\n${context ? `**Context:** ${sentence(context)}\n\n` : ""}### Strengths\n${bullets([
        `Direct control over the ${voice.adjectives[0]} parts of the value chain.`,
        `Existing trust with ${audience} — the relationship already exists, it just needs a reason to deepen.`,
        facts[1] ? sentence(facts[1]) : "Small surface area means fast decisions.",
      ])}\n\n### Weaknesses\n${bullets([
        "Proof is thinner than ambition — fewer case studies than the category leader.",
        "Dependence on a small number of people for anything nonstandard.",
        context ? sentence(context) : "Brand recognition lags product quality.",
      ])}\n\n### Opportunities\n${bullets([
        `Adjacent workflows that share the same data — same effort, second use case.`,
        "Partners who already own the customer relationship and lack the capability.",
        "A category narrative still being written — nobody has claimed the framing yet.",
      ])}\n\n### Threats\n${bullets([
        "Incumbents bundling a good-enough version into something already paid for.",
        "A shift in buyer behaviour that makes the current channel more expensive.",
        "Regulatory or procurement requirements that lengthen the sales cycle.",
      ])}\n\n### Recommendation\n${
        sentence(`Lead with strength one, shore up the proof gap in the next 45 days, and treat the first opportunity as the only bet until it is measurable`)
      }\n\n### Assumptions to validate\n${numbered([
        `That ${audience} rank this problem in their top three, not their top ten.`,
        "That the proof you can produce in 45 days is enough to change a purchase decision.",
        "That the pricing model survives contact with a real procurement process.",
      ])}`;
      break;
    }

    case "social": {
      const channel = fields.channel || "LinkedIn";
      output = `## Social pack — ${titleCase(shortSubject)}\n\n**Primary channel:** ${channel} · **Tone:** ${voice.label} · **Audience:** ${audience}\n\n### Day 1 — The announcement\n${
        sentence(`${titleCase(shortSubject)} is live`)
      } ${
        facts[0] ? sentence(facts[0]) : "Built it because the existing options all stopped one step short."
      }\n\nWhat changed, in one line: fewer steps between intent and done.\n\n#${channel === "LinkedIn" ? "buildinpublic" : "shipping"}\n\n### Day 2 — The before/after\n**Before:** ${
        sentence(`three tools, two handoffs, one person chasing status`)
      }\n**After:** one view, one owner, done by Tuesday.\n\n### Day 3 — The opinion\nUnpopular take: most conversations about ${shortSubject.toLowerCase()} focus on the wrong layer. The hard part is not generation, it is grounding. ${
        voice.closer
      }\n\n### Day 4 — The proof\n${
        sentence(`One screenshot, one number, zero adjectives`)
      } Post the metric, not the mockup.\n\n### Day 5 — The invitation\nWe are looking for ${
        audience.includes("general") ? "five teams" : `${audience}`
      } to try this on a real workflow. Reply and I will send the details.\n\n### Day 6 — The behind-the-scenes\nWhat we got wrong on the first build, and what we changed. Shipping the fix was faster than defending the original.\n\n### Day 7 — The recap\nA thread of everything above, condensed to one post for people who missed the week.\n\n### Channel notes\n${bullets([
        `${channel === "LinkedIn" ? "LinkedIn: first 140 characters do the work; no external link in the first comment window." : `${channel}: hook in the first line, one idea per post.`}`,
        "Reuse Day 3 as a newsletter section — the opinion post has the longest shelf life.",
        "Keep the metric post free of adjectives; numbers travel further.",
      ])}`;
      break;
    }

    case "faq": {
      const askers = audienceLabel(fields.audience || request.audience);
      const themes = [
        {
          theme: "Getting started",
          items: [
            `How long does setup take for ${shortSubject.toLowerCase()}? — Under an hour for the default setup; plan on a half-day if you are importing existing context.`,
            "Do I need to change how we work today? — No. Start with one workflow and keep everything else untouched.",
          ],
        },
        {
          theme: "How it works",
          items: [
            facts[0]
              ? `What is it actually built on? — ${sentence(facts[0])}`
              : "What is it actually built on? — Your own context, retrieved per request, so answers are specific rather than plausible.",
            "Why is the output different each time? — Generation is non-deterministic by design; the facts it draws on are not.",
          ],
        },
        {
          theme: "Money and risk",
          items: [
            "How is it priced? — Usage-based, with a ceiling so a busy week does not become a surprise invoice.",
            "What happens to our data? — It stays in your workspace and is only used to answer your own requests.",
          ],
        },
      ];
      output = `## FAQ — ${titleCase(shortSubject)}\n\n**Written for:** ${askers}\n\n${themes
        .map(
          (group) =>
            `### ${group.theme}\n${bullets(group.items.map((item) => `**${item.split(" — ")[0]}** — ${item.split(" — ").slice(1).join(" — ")}`))}`,
        )
        .join("\n\n")}\n\n### Questions worth adding once you have support tickets\n${bullets([
        "The question three different customers asked in slightly different words.",
        "The question your team answers differently depending on who replies — that one needs a canonical answer.",
        "The pricing edge case that keeps coming up in procurement.",
      ])}`;
      break;
    }

    case "job-post": {
      const mission = stripTrailingPeriod(fields.mission || facts[0] || "ship work that removes real steps for real teams");
      output = `## Role brief — ${titleCase(shortSubject)}\n\n### The one-paragraph pitch\n${sentence(
        `You will ${mission.toLowerCase()} as part of a small team where the distance between an idea and a shipped change is measured in days`,
      )} ${
        voice.closer
      }\n\n### What you will actually do in month one\n${bullets([
        "Own one surface end to end, including the parts nobody demos.",
        "Ship something a customer notices in your first two weeks.",
        "Write down one thing the team was doing from memory and turn it into a documented decision.",
      ])}\n\n### What we are looking for\n${bullets([
        "Comfortable being the person who decides when the tradeoff is not obvious.",
        `Evidence you can ${voice.verbs[0]} messy scope into something shippable.`,
        "Writes clearly enough that a decision written on Tuesday still makes sense on Friday.",
      ])}\n\n### What we are not looking for\n${bullets([
        "A perfect checklist match — the brief matters more than the years.",
        "Someone whose first instinct is to add a process layer.",
      ])}\n\n### Interview loop\n| Stage | Length | What we assess |\n| --- | --- | --- |\n| Intro call | 25 min | Mutual fit, the actual scope of the role |\n| Work session | 60 min | Real problem, pair with the team |\n| Deep dive | 45 min | Past work, tradeoffs you made |\n| References | 20 min | How you operate under ambiguity |\n\n### Scorecard\n${bullets([
        "**Technical range** — can move across the stack without waiting on someone else.",
        "**Judgment** — asks about the goal before the implementation.",
        "**Communication** — writes decisions down unprompted.",
      ])}`;
      break;
    }

    default: {
      output = `## ${titleCase(subject)}\n\nI can produce structured work for this, but I need a little more specificity.\n\n### What would help\n${bullets([
        "The outcome you want the reader, buyer, or teammate to walk away with.",
        `The audience — "everyone" usually produces ${voice.adjectives[0]} but forgettable output.`,
        "One constraint worth respecting (budget, deadline, tone, legal).",
      ])}\n\n### In the meantime\n${numbered([
        `Try a studio tool such as **Value Proposition** or **Strategy Sprint** for ${shortSubject.toLowerCase()}.`,
        "Add a knowledge base entry so future drafts are grounded in your own facts.",
        "Ask the assistant to critique what you already have — that is often faster than starting over.",
      ])}`;
    }
  }

  const title = `${PREFIX_LABELS[tool] ? `${PREFIX_LABELS[tool]}: ` : ""}${titleCase(shortSubject).slice(0, 70)}`;

  return {
    output: `${output}${groundingSection(matches)}\n\n<!-- capson-engine · tone:${tone} · tool:${tool} -->`,
    title,
    grounding: matches,
  };
}

function benefitOf(subject: string): string {
  return `a faster path from intent to a finished result with ${subject.toLowerCase()}`;
}

/** Normalises a "key differentiator" so it reads as a clause: "is grounded in your data". */
function cleanClause(input: string): string {
  const cleaned = stripTrailingPeriod(input)
    .toLowerCase()
    .replace(/^(it |this |that |which |because )+/g, "")
    .replace(/^(is |are |was |were |has |have |does |do |gets |get |provides |provides )+/g, "")
    .replace(/^(it|this|that)\b/g, "")
    .trim();
  return cleaned || "does the boring part correctly, every time";
}

/** Turns a stated benefit into a noun-ish outcome phrase usable mid-sentence. */
function benefitPhrase(benefit: string): string {
  const cleaned = stripTrailingPeriod(benefit)
    .toLowerCase()
    .replace(
      /^(we |it |this )?(helps? to |helps? |cuts? |reduces? |saves? |increases? |improves? |delivers? |means? |gives? you |gets? )+/,
      "",
    )
    .replace(/^(more |less |better |faster )+/, "")
    .replace(/\bfrom days to minutes\b/g, "in minutes instead of days")
    .replace(/\bin days\b/g, "in hours")
    .trim();
  return cleaned || "the work getting done faster";
}

/* -------------------------------------------------------------------------- */
/*  Chat engine                                                               */
/* -------------------------------------------------------------------------- */

export type ChatTurn = { role: "user" | "assistant" | "system"; content: string };

export type ChatRequest = {
  history: ChatTurn[];
  persona: string;
  knowledge: Pick<KnowledgeItem, "title" | "category" | "content" | "tags">[];
};

export type ChatResponse = {
  content: string;
  engine: string;
  grounding: Grounding[];
};

const GREETING_RE = /^(hi|hey|hello|yo|good (morning|afternoon|evening)|howdy)\b/i;
const CAPABILITY_RE = /\b(what can you do|who are you|help me|what are you|capabilities|how do you work)\b/i;
const SHORTER_RE = /\b(shorter|tighter|more concise|too long|trim|cut it down|brief version)\b/i;
const TOOL_KEYWORDS: Array<[RegExp, string]> = [
  [/\b(tagline|slogan|motto|naming)\b/i, "tagline"],
  [/\b(value prop|positioning|messaging|one.?liner)\b/i, "value-prop"],
  [/\b(product (copy|description|page)|listing)\b/i, "product-copy"],
  [/\b(email|follow.?up|outreach|cold message)\b/i, "email"],
  [/\b(outline|blog|article|content (plan|calendar)|seo)\b/i, "blog-outline"],
  [/\b(strategy|roadmap|plan|priorit|90.day|quarter)\b/i, "strategy"],
  [/\b(swot|pros and cons|trade.?offs|should (we|i))\b/i, "swot"],
  [/\b(social|linkedin|twitter|post|tweet|instagram)\b/i, "social"],
  [/\b(faq|support|customer question)\b/i, "faq"],
  [/\b(hire|job post|role brief|recruit|job description)\b/i, "job-post"],
];

export const PERSONAS: Record<string, { name: string; blurb: string; lens: string }> = {
  generalist: {
    name: "Generalist",
    blurb: "Balanced, structured answers for everyday questions",
    lens: "Balanced",
  },
  strategist: {
    name: "Strategist",
    blurb: "Bets, sequencing, and what to measure",
    lens: "Strategic",
  },
  marketer: {
    name: "Marketer",
    blurb: "Positioning, copy, and channel-native language",
    lens: "Market-facing",
  },
  engineer: {
    name: "Engineer",
    blurb: "Concrete mechanics, tradeoffs, and edge cases",
    lens: "Technical",
  },
  coach: {
    name: "Coach",
    blurb: "Direct, warm, action-first guidance",
    lens: "Action-first",
  },
};

export function isPersona(value: string): boolean {
  return value in PERSONAS;
}

export function chatReply(request: ChatRequest): ChatResponse {
  const history = request.history.filter((turn) => turn.content.trim().length > 0);
  const lastUser = [...history].reverse().find((turn) => turn.role === "user");
  const userText = lastUser?.content ?? "";
  const persona = PERSONAS[request.persona] ?? PERSONAS.generalist;
  const matches = retrieveKnowledge(
    history.slice(-4).map((turn) => turn.content).join(" ") || userText,
    request.knowledge,
  );
  const facts = knowledgeFacts(matches);
  const seed = hash(userText + persona.name);

  if (!userText) {
    return {
      content: "I am ready when you are. Tell me what you are working on and I will structure it.",
      engine: "capson-engine",
      grounding: [],
    };
  }

  if (GREETING_RE.test(userText) && userText.length < 40) {
    return {
      content: `Hey — good to see you.\n\nI am **Capson**, currently running as **${persona.name}** (${
        persona.blurb.toLowerCase()
      }).\n\nThree ways to start:\n${numbered([
        "Ask me anything about your business — I answer using your knowledge base first, general reasoning second.",
        "Ask for a draft: taglines, emails, positioning, outlines, plans, FAQs.",
        "Say **make it shorter** or **more technical** at any point and I will rework my last answer.",
      ])}\n\nWhat is on the docket?`,
      engine: "capson-engine",
      grounding: [],
    };
  }

  if (CAPABILITY_RE.test(userText)) {
    return {
      content: `## What I do\n\nI am Capson — an AI workspace that grounds every answer in **your** knowledge base rather than generic training data.\n\n### Assistant\n${bullets([
        `Answer questions about your business with sources pulled from ${request.knowledge.length} knowledge entr${request.knowledge.length === 1 ? "y" : "ies"}.`,
        "Switch personas to change the lens: Strategist, Marketer, Engineer, Coach.",
        "Iterate — ask for shorter, bolder, or more technical and I rework the same answer.",
      ])}\n\n### Studio tools\n${bullets([
        "**Tagline Forge** — positioning lines with reasoning.",
        "**Value Proposition** — positioning statement, hierarchy, objection handling.",
        "**Email Composer** — subject lines, body, follow-up cadence.",
        "**Strategy Sprint** — a 90-day plan with milestones and risks.",
        "...plus SWOT, FAQ, social, product copy, outlines, and role briefs.",
      ])}\n\n### How grounding works\n${
        request.knowledge.length
          ? `When you mention ${matches.map((match) => match.title.toLowerCase()).join(", ") || "a topic you have written about"}, I retrieve those entries and cite them under the answer.`
          : "Your knowledge base is empty right now — add entries on the Knowledge page and every answer gets specific."
      }`,
      engine: "capson-engine",
      grounding: matches,
    };
  }

  const wantsShorter =
    SHORTER_RE.test(userText) && history.length > 1;

  if (wantsShorter) {
    const priorAssistant = [...history].reverse().find((turn) => turn.role === "assistant")?.content ?? "";
    const keyLines = priorAssistant
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.startsWith("- **") || line.startsWith("> "))
      .slice(0, 4);
    return {
      content: `## Tightened version\n\n${
        keyLines.length
          ? keyLines.join("\n")
          : bullets([
              facts[0] ? sentence(facts[0]) : "Keep the single most important claim.",
              "Cut every sentence that does not change a decision.",
              "One ask, one owner, one date.",
            ])
      }\n\n**The short version:** ${titleCase(
        stripTrailingPeriod(userText.length > 60 ? userText.slice(0, 60) : userText),
      )} — decide the one metric, then move.`,
      engine: "capson-engine",
      grounding: matches,
    };
  }

  const toolHit = TOOL_KEYWORDS.find(([pattern]) => pattern.test(userText));
  if (toolHit && /\b(write|draft|generate|create|give me|build|make|help me)\b/i.test(userText)) {
    const result = runTool({
      tool: toolHit[1],
      prompt: userText.replace(/\b(write|draft|generate|create|give me|build|make|help me)\b/gi, "").trim() || userText,
      tone: "professional",
      audience: "general",
      fields: {},
      knowledge: request.knowledge,
    });
    return {
      content: `Here is a first pass. I routed this to **${toolHit[1]}** — ask for any change and I will rework it rather than restart.\n\n${result.output}`,
      engine: "capson-engine",
      grounding: result.grounding,
    };
  }

  /* General structured answer. */
  const questionish = /\?|^(how|why|what|when|which|should|can|is|are|do|does)\b/i.test(userText);
  const topic = titleCase(stripTrailingPeriod(userText.split("?")[0]).slice(0, 70));
  const lensLine: Record<string, string> = {
    Strategist: `Framed through sequencing: what to do first, what to defer, and what proves the bet.`,
    "Market-facing": `Framed for the buyer: how this sounds from the outside, in their words.`,
    Technical: `Framed through mechanics: moving parts, failure modes, and what to instrument.`,
    "Action-first": `Framed for momentum: the smallest useful next step, today.`,
    Balanced: `Balanced framing: the substance first, then the practical steps.`,
  };

  const answer = `## ${topic}\n\n### Short answer\n${
    facts[0]
      ? sentence(facts[0])
      : sentence(
          `${pick(
            [
              "Yes — with caveats worth naming up front",
              "It depends on one variable more than any other",
              "There is a workable path here, and it is narrower than it first looks",
            ],
            seed,
          )}: ${stripTrailingPeriod(userText).toLowerCase()}`,
        )
  }\n\n### The reasoning\n${numbered([
  `**What is actually being asked.** ${sentence(stripTrailingPeriod(userText))} The useful version of this question is narrower — ${
    persona.name === "Engineer"
      ? "what specifically breaks, and under what load"
      : persona.name === "Strategist"
        ? "what has to be true for this to be worth doing"
        : "what decision changes based on the answer"
  }.`,
  facts[1]
    ? `**What your own context says.** ${sentence(facts[1])}`
    : `**What is likely true already.** ${pick(
        [
          "The constraint is usually process, not capability",
          "The cost sits in the handoffs, not the steps",
          "The first version should be smaller than feels comfortable",
        ],
        seed,
      )}.`,
  `**Where the risk is.** ${pick(
    [
      "The failure mode is measuring the wrong thing and declaring victory early",
      "The failure mode is scope that quietly doubles after week two",
      "The failure mode is a solution that only works when the same person runs it",
    ],
    seed + 7,
  )}.`,
])}\n\n### What I would do next\n${bullets([
  `Define one metric with a baseline captured before anything changes.`,
  facts[2]
    ? `Use this as the anchor: ${stripTrailingPeriod(facts[2]).toLowerCase()}.`
    : `Run the smallest version on ${persona.name === "Marketer" ? "one segment" : "one workflow"} rather than the whole surface.`,
  "Write down the go/no-go date in advance so the decision is not emotional.",
])}\n\n### Worth watching\n${bullets([
  questionish ? "Whether the answer changes if the timeline halves." : "Whether this still holds in three months.",
  `Second-order effects on ${audienceOf(userText)} — the people who have to live with the change.`,
])}\n\n---\n\n*Lens: ${persona.name} — ${lensLine[persona.lens] ?? lensLine.Balanced}*`;

  return {
    content: `${answer}${groundingSection(matches)}`,
    engine: "capson-engine",
    grounding: matches,
  };
}

function audienceOf(text: string): string {
  const words = keywords(text);
  return words.length ? words.slice(0, 3).join(" ") : "the team";
}
