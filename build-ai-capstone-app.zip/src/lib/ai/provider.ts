/**
 * Capson can run in two modes:
 *  1. "capson-engine" — the built-in local generation engine. Always available,
 *     fully deterministic, no network calls, no keys required.
 *  2. A hosted model, used automatically when an API key is present in the
 *     environment. Keys are only ever read on the server.
 */

export type RemoteMessage = { role: "user" | "assistant"; content: string };

export type ProviderInfo = {
  id: string;
  label: string;
};

export function activeProvider(): ProviderInfo | null {
  if (process.env.OPENAI_API_KEY) return { id: "openai", label: "OpenAI" };
  if (process.env.ANTHROPIC_API_KEY) return { id: "anthropic", label: "Anthropic" };
  if (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY) {
    return { id: "gemini", label: "Gemini" };
  }
  return null;
}

const TIMEOUT_MS = 25_000;

async function withTimeout<T>(work: (signal: AbortSignal) => Promise<T>): Promise<T | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await work(controller.signal);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function callOpenAI(system: string, messages: RemoteMessage[]): Promise<string | null> {
  return withTimeout(async (signal) => {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      signal,
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL ?? "gpt-4o-mini",
        temperature: 0.7,
        messages: [{ role: "system", content: system }, ...messages],
      }),
    });
    if (!response.ok) return null;
    const data = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    return data.choices?.[0]?.message?.content?.trim() ?? null;
  });
}

async function callAnthropic(system: string, messages: RemoteMessage[]): Promise<string | null> {
  return withTimeout(async (signal) => {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal,
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY ?? "",
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL ?? "claude-3-5-sonnet-latest",
        max_tokens: 1600,
        system,
        messages,
      }),
    });
    if (!response.ok) return null;
    const data = (await response.json()) as { content?: Array<{ text?: string }> };
    return data.content?.map((part) => part.text ?? "").join("").trim() || null;
  });
}

/**
 * Attempt a hosted-model completion. Returns null when no key is configured or
 * the call fails, in which case callers fall back to the local engine.
 */
export async function remoteComplete(
  system: string,
  messages: RemoteMessage[],
): Promise<{ text: string; provider: ProviderInfo } | null> {
  const provider = activeProvider();
  if (!provider) return null;

  let text: string | null = null;
  if (provider.id === "openai") text = await callOpenAI(system, messages);
  if (provider.id === "anthropic") text = await callAnthropic(system, messages);

  if (!text) return null;
  return { text, provider };
}

export function engineLabel(): string {
  const provider = activeProvider();
  return provider ? `${provider.id}-capson` : "capson-engine";
}
