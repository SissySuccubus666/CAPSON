import { db } from "@/db";
import { conversations, generations, knowledgeItems, messages } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export const SEED_KNOWLEDGE = [
  {
    title: "What Capson is",
    category: "Product",
    tags: "capson, product, overview, ai workspace",
    content:
      "Capson is an AI workspace that grounds every answer and every draft in a company's own context. Instead of a generic chatbot, Capson retrieves the brand's facts first and writes from them.",
  },
  {
    title: "Who Capson serves",
    category: "Market",
    tags: "audience, customers, icp, segment",
    content:
      "Capson serves small and mid-size teams who do not have a dedicated content or strategy function: quoting teams, founder-led sales, and operations leads who need senior-quality output without hiring for it.",
  },
  {
    title: "Primary differentiator",
    category: "Positioning",
    tags: "differentiation, grounding, moat, why us",
    content:
      "Generic AI produces plausible output; Capson produces specific output because every generation is grounded in the customer's own knowledge base and cites which entries it used.",
  },
  {
    title: "Brand voice",
    category: "Voice",
    tags: "tone, voice, writing style, language",
    content:
      "Capson's voice is plain, confident and specific. Short sentences. No hype adjectives. Claims come with a number or an example attached.",
  },
  {
    title: "Pricing posture",
    category: "Commercial",
    tags: "pricing, packaging, trial, plans",
    content:
      "Capson is packaged as a usage-based subscription with a spend ceiling, plus a 14-day pilot scoped to one workflow so the buyer can measure value before committing.",
  },
];

let seedChecked = false;

/** Idempotently loads starter knowledge so the workspace is never empty. */
export async function ensureSeedData(): Promise<void> {
  if (seedChecked) return;
  try {
    const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(knowledgeItems);
    if ((row?.count ?? 0) === 0) {
      await db.insert(knowledgeItems).values(SEED_KNOWLEDGE);
    }
    seedChecked = true;
  } catch {
    // Table may not exist yet during first boot; ignore and retry later.
  }
}

export async function listKnowledge() {
  await ensureSeedData();
  return db.select().from(knowledgeItems).orderBy(desc(knowledgeItems.createdAt));
}

export async function listConversations() {
  return db
    .select({
      id: conversations.id,
      title: conversations.title,
      persona: conversations.persona,
      updatedAt: conversations.updatedAt,
      messageCount: sql<number>`(select count(*)::int from ${messages} where ${messages.conversationId} = ${conversations.id})`,
    })
    .from(conversations)
    .orderBy(desc(conversations.updatedAt))
    .limit(50);
}

export async function listMessages(conversationId: number) {
  return db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.id);
}

export async function listGenerations(favoritesOnly = false) {
  const query = db.select().from(generations);
  const rows = favoritesOnly
    ? await query.where(eq(generations.favorite, true)).orderBy(desc(generations.createdAt)).limit(100)
    : await query.orderBy(desc(generations.createdAt)).limit(100);
  return rows;
}

export async function workspaceStats() {
  await ensureSeedData();
  const [knowledge] = await db.select({ count: sql<number>`count(*)::int` }).from(knowledgeItems);
  const [threads] = await db.select({ count: sql<number>`count(*)::int` }).from(conversations);
  const [turns] = await db.select({ count: sql<number>`count(*)::int` }).from(messages);
  const [outputs] = await db.select({ count: sql<number>`count(*)::int` }).from(generations);
  const [favorites] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(generations)
    .where(eq(generations.favorite, true));
  const toolBreakdown = await db
    .select({ tool: generations.tool, count: sql<number>`count(*)::int` })
    .from(generations)
    .groupBy(generations.tool)
    .orderBy(desc(sql`count(*)`))
    .limit(6);

  return {
    knowledge: knowledge?.count ?? 0,
    conversations: threads?.count ?? 0,
    messages: turns?.count ?? 0,
    generations: outputs?.count ?? 0,
    favorites: favorites?.count ?? 0,
    toolBreakdown,
  };
}

export function makeTitle(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "New conversation";
  const cut = clean.length > 52 ? `${clean.slice(0, 52).trimEnd()}…` : clean;
  return cut.charAt(0).toUpperCase() + cut.slice(1);
}
