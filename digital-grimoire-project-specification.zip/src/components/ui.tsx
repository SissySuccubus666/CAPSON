import Link from "next/link";

import { CONFIDENCE_CLASS, labelSpec } from "@/lib/labels";

export function LabelBadge({ label, title }: { label: string; title?: boolean }) {
  const spec = labelSpec(label);
  return (
    <span
      title={spec.description}
      className={`mono inline-flex items-center rounded-sm border px-1.5 py-0.5 uppercase tracking-wider ${spec.className}`}
    >
      {title ? spec.key : spec.short}
    </span>
  );
}

export function ConfidenceBadge({ level, note }: { level: string; note?: boolean }) {
  return (
    <span
      title={note ? `CONFIDENCE: ${level}` : undefined}
      className={`mono inline-flex items-center rounded-sm border px-1.5 py-0.5 uppercase tracking-wider ${
        CONFIDENCE_CLASS[level] ?? CONFIDENCE_CLASS.LOW
      }`}
    >
      {level}
    </span>
  );
}

export function PageHeader({
  eyebrow,
  title,
  lead,
  children,
}: {
  eyebrow?: string;
  title: string;
  lead?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="mb-8">
      {eyebrow ? (
        <p className="mono mb-2 text-[11px] uppercase tracking-[0.3em] text-brass-500/80">{eyebrow}</p>
      ) : null}
      <h1 className="text-3xl leading-tight sm:text-4xl">{title}</h1>
      {lead ? <p className="mt-3 max-w-3xl text-[15px] leading-relaxed text-parchment-200/70">{lead}</p> : null}
      {children ? <div className="mt-4">{children}</div> : null}
    </div>
  );
}

export function Stat({ value, label, href }: { value: number | string; label: string; href?: string }) {
  const inner = (
    <div className="panel h-full p-4 transition hover:border-brass-500/40">
      <p className="text-2xl text-brass-300">{value}</p>
      <p className="mono mt-1 text-[10px] uppercase tracking-[0.2em] text-parchment-200/50">{label}</p>
    </div>
  );
  return href ? (
    <Link href={href} className="no-underline">
      {inner}
    </Link>
  ) : (
    inner
  );
}

export function Field({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div className="border-b border-brass-500/10 py-2">
      <dt className="mono text-[10px] uppercase tracking-[0.2em] text-brass-500/70">{label}</dt>
      <dd className="mt-1 text-sm leading-relaxed text-parchment-200/85">{value}</dd>
    </div>
  );
}
