"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";

type GraphNode = { key: string; kind: string; label: string; slug: string; degree: number };
type GraphEdge = { from: string; to: string; predicate: string; label: string; weight: number };

const W = 960;
const H = 640;

const KIND_STYLE: Record<string, { fill: string; stroke: string; r: number }> = {
  tradition: { fill: "#c9a227", stroke: "#e6cf94", r: 13 },
  entity: { fill: "#4ea19a", stroke: "#8fd3cd", r: 9 },
  symbol: { fill: "#9b3a3a", stroke: "#d99a9a", r: 7 },
  document: { fill: "#6f5aa8", stroke: "#b7a7ea", r: 7 },
};

const LINK_LABEL: Record<string, string> = {
  tradition: "traditions",
  entity: "entities",
  symbol: "symbols",
  document: "documents",
};

export function GraphExplorer({ initialFocus }: { initialFocus: string | null }) {
  const [focus, setFocus] = useState<string | null>(initialFocus);
  const [data, setData] = useState<{ nodes: GraphNode[]; edges: GraphEdge[] } | null>(null);
  const [selected, setSelected] = useState<GraphNode | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const url = focus ? `/api/graph?focus=${encodeURIComponent(focus)}` : "/api/graph";
    fetch(url)
      .then((res) => res.json())
      .then((json: { nodes: GraphNode[]; edges: GraphEdge[] }) => {
        if (!cancelled) {
          setData(json);
          setLoading(false);
        }
      })
      .catch(() => setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [focus]);

  const positions = useMemo(() => {
    if (!data) return new Map<string, { x: number; y: number }>();
    const map = new Map<string, { x: number; y: number; vx: number; vy: number }>();
    data.nodes.forEach((node, index) => {
      const angle = (index / Math.max(data.nodes.length, 1)) * Math.PI * 2;
      const radius = node.kind === "tradition" ? 120 : 230;
      map.set(node.key, {
        x: W / 2 + Math.cos(angle) * radius + ((index * 37) % 60) - 30,
        y: H / 2 + Math.sin(angle) * radius + ((index * 53) % 60) - 30,
        vx: 0,
        vy: 0,
      });
    });

    const k = 0.02;
    const repulse = 2600;
    for (let step = 0; step < 320; step += 1) {
      // repulsion
      const keys = [...map.keys()];
      for (let i = 0; i < keys.length; i += 1) {
        for (let j = i + 1; j < keys.length; j += 1) {
          const a = map.get(keys[i])!;
          const b = map.get(keys[j])!;
          let dx = b.x - a.x;
          let dy = b.y - a.y;
          let dist2 = dx * dx + dy * dy;
          if (dist2 < 1) {
            dx = (i % 3) - 1 || 0.5;
            dy = (j % 3) - 1 || 0.5;
            dist2 = 1;
          }
          const dist = Math.sqrt(dist2);
          const force = repulse / dist2;
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          a.vx -= fx;
          a.vy -= fy;
          b.vx += fx;
          b.vy += fy;
        }
      }
      // spring attraction along edges
      data.edges.forEach((edge) => {
        const a = map.get(edge.from);
        const b = map.get(edge.to);
        if (!a || !b) return;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dist = Math.max(Math.sqrt(dx * dx + dy * dy), 1);
        const target = 130 - edge.weight * 8;
        const force = (dist - target) * 0.012 * edge.weight;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        a.vx += fx;
        a.vy += fy;
        b.vx -= fx;
        b.vy -= fy;
      });
      // integrate + centre gravity
      map.forEach((pos, key) => {
        const node = data.nodes.find((n) => n.key === key)!;
        pos.vx += (W / 2 - pos.x) * 0.004;
        pos.vy += (H / 2 - pos.y) * 0.004;
        pos.x += Math.max(-12, Math.min(12, pos.vx)) * k * 6;
        pos.y += Math.max(-12, Math.min(12, pos.vy)) * k * 6;
        pos.vx *= 0.72;
        pos.vy *= 0.72;
        pos.x = Math.max(node.kind === "tradition" ? 60 : 26, Math.min(W - 26, pos.x));
        pos.y = Math.max(22, Math.min(H - 22, pos.y));
      });
    }

    const out = new Map<string, { x: number; y: number }>();
    map.forEach((pos, key) => out.set(key, { x: pos.x, y: pos.y }));
    return out;
  }, [data]);

  const focusNode = useCallback(
    (node: GraphNode) => {
      setSelected(node);
      setFocus(node.key);
    },
    [],
  );

  const nodeHref = (node: GraphNode) => {
    switch (node.kind) {
      case "entity":
        return `/entities/${node.slug}`;
      case "document":
        return `/library/${node.slug}`;
      case "tradition":
        return `/library?tradition=${node.slug}`;
      default:
        return `/symbols?q=${node.slug}`;
    }
  };

  const highlight = hover ?? selected?.key ?? null;
  const connected = new Set<string>();
  if (highlight && data) {
    connected.add(highlight);
    data.edges.forEach((edge) => {
      if (edge.from === highlight) connected.add(edge.to);
      if (edge.to === highlight) connected.add(edge.from);
    });
  }

  const counts = useMemo(() => {
    const map = new Map<string, number>();
    data?.nodes.forEach((n) => map.set(n.kind, (map.get(n.kind) ?? 0) + 1));
    return map;
  }, [data]);

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
      <div className="panel relative overflow-hidden p-2">
        {loading ? (
          <p className="mono absolute left-4 top-4 z-10 text-[11px] uppercase tracking-[0.2em] text-brass-500/80">
            traversing…
          </p>
        ) : null}
        <svg viewBox={`0 0 ${W} ${H}`} className="h-[640px] w-full" role="img" aria-label="knowledge graph">
          <g>
            {data?.edges.map((edge, index) => {
              const a = positions.get(edge.from);
              const b = positions.get(edge.to);
              if (!a || !b) return null;
              const active = !highlight || edge.from === highlight || edge.to === highlight;
              return (
                <g key={index}>
                  <line
                    x1={a.x}
                    y1={a.y}
                    x2={b.x}
                    y2={b.y}
                    stroke={active ? "rgba(212,180,104,0.42)" : "rgba(226,213,186,0.08)"}
                    strokeWidth={active ? 1 + edge.weight * 0.35 : 0.7}
                  />
                  {highlight && (edge.from === highlight || edge.to === highlight) ? (
                    <text
                      x={(a.x + b.x) / 2}
                      y={(a.y + b.y) / 2 - 4}
                      textAnchor="middle"
                      className="mono"
                      fill="rgba(230,207,148,0.85)"
                      fontSize="9"
                    >
                      {edge.predicate}
                    </text>
                  ) : null}
                </g>
              );
            })}
          </g>
          <g>
            {data?.nodes.map((node) => {
              const pos = positions.get(node.key);
              if (!pos) return null;
              const style = KIND_STYLE[node.kind] ?? KIND_STYLE.symbol;
              const dim = connected.size > 0 && !connected.has(node.key);
              return (
                <g
                  key={node.key}
                  transform={`translate(${pos.x},${pos.y})`}
                  onMouseEnter={() => setHover(node.key)}
                  onMouseLeave={() => setHover(null)}
                  onClick={() => focusNode(node)}
                  style={{ cursor: "pointer", opacity: dim ? 0.28 : 1 }}
                >
                  <circle r={style.r + Math.min(node.degree, 8)} fill={style.fill} fillOpacity={0.22} />
                  <circle r={style.r} fill={style.fill} stroke={style.stroke} strokeWidth={1.1} />
                  <text
                    y={style.r + 12}
                    textAnchor="middle"
                    fill={highlight === node.key ? "#f3ead7" : "rgba(243,234,215,0.7)"}
                    fontSize="11"
                  >
                    {node.label.length > 26 ? `${node.label.slice(0, 24)}…` : node.label}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      <aside className="space-y-4">
        <div className="panel p-4">
          <p className="mono text-[10px] uppercase tracking-[0.2em] text-brass-500/70">showing</p>
          <p className="mt-1 text-sm text-parchment-100">
            {focus ? focus.replace(":", " · ") : "the whole archive"}
          </p>
          <div className="mono mt-3 space-y-1 text-[10px] uppercase tracking-[0.18em] text-parchment-200/50">
            {[...counts.entries()].map(([kind, n]) => (
              <p key={kind}>
                <span style={{ color: KIND_STYLE[kind]?.fill }}>{n}</span> {LINK_LABEL[kind] ?? kind}
              </p>
            ))}
            <p>
              <span className="text-brass-400">{data?.edges.length ?? 0}</span> edges
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setFocus(null);
              setSelected(null);
            }}
            className="mono mt-3 rounded-sm border border-brass-500/30 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-parchment-200/70"
          >
            reset view
          </button>
        </div>

        {selected ? (
          <div className="panel p-4">
            <p className="mono text-[10px] uppercase tracking-[0.2em] text-brass-500/70">{selected.kind}</p>
            <h3 className="mt-1 text-lg">{selected.label}</h3>
            <p className="mono mt-1 text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
              {selected.degree} edges · {selected.slug}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link
                href={nodeHref(selected)}
                className="mono rounded-sm border border-brass-500/40 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-brass-200 no-underline"
              >
                open record
              </Link>
              <button
                type="button"
                onClick={() => setFocus(selected.key)}
                className="mono rounded-sm border border-brass-500/25 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-parchment-200/70"
              >
                two-hop view
              </button>
            </div>
          </div>
        ) : null}

        <div className="panel p-4">
          <h3 className="smallcaps mb-2 text-sm text-brass-300">How to read this</h3>
          <p className="text-xs leading-relaxed text-parchment-200/60">
            Click any node to re-centre the graph on it and its two-hop neighbourhood. Hover a node to see its edges
            labelled with the predicate that joins them. Nodes are sized by degree. The layout is computed in the
            browser, so the graph works offline.
          </p>
          <div className="mono mt-3 space-y-1 text-[10px] uppercase tracking-[0.18em] text-parchment-200/50">
            <p><span style={{ color: KIND_STYLE.tradition.fill }}>●</span> traditions</p>
            <p><span style={{ color: KIND_STYLE.entity.fill }}>●</span> entities</p>
            <p><span style={{ color: KIND_STYLE.symbol.fill }}>●</span> symbols</p>
            <p><span style={{ color: KIND_STYLE.document.fill }}>●</span> documents</p>
          </div>
        </div>
      </aside>
    </div>
  );
}
