"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

type Issue = { level: string; path: string; message: string };
type ValidationResult = { ok: boolean; issues: Issue[]; imported?: boolean; grimoire?: { slug: string; name: string } };

const SAMPLE = `grimoire:
  name: "The Black Archive"
  author: "User"
  tradition: "Experimental"
  description: "Working notes from the archive."

entries:
  - type: entity
    name: "Example Entity"
    label: "USER CREATED"
  - type: correspondence
    name: "Mercury / 8"
    meta:
      planet: "Mercury"
      number: 8

sources:
  - title: "Example Source"
    author: "Example Author"
    date: "1900"
`;

export function WorkshopConsole({ grimoires }: { grimoires: { slug: string; name: string; entryCount: number }[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [tradition, setTradition] = useState("");
  const [description, setDescription] = useState("");
  const [author, setAuthor] = useState("User");
  const [creating, setCreating] = useState(false);

  const [raw, setRaw] = useState(SAMPLE);
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [checking, setChecking] = useState(false);

  async function createGrimoire(event: React.FormEvent) {
    event.preventDefault();
    if (!name.trim()) return;
    setCreating(true);
    const res = await fetch("/api/grimoires", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, tradition, description, author }),
    });
    const json = (await res.json()) as { grimoire?: { slug: string } };
    setCreating(false);
    if (json.grimoire) {
      router.push(`/workshop/${json.grimoire.slug}`);
    }
  }

  async function submitGrim(mode: "validate" | "import") {
    setChecking(true);
    const res = await fetch("/api/grim", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ raw, mode }),
    });
    setValidation((await res.json()) as ValidationResult);
    setChecking(false);
    router.refresh();
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <section className="panel p-5">
        <h2 className="smallcaps mb-3 text-base text-brass-300">Create a grimoire</h2>
        <form onSubmit={createGrimoire} className="grid gap-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="name" required aria-label="name" />
          <input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="author" aria-label="author" />
          <input
            value={tradition}
            onChange={(e) => setTradition(e.target.value)}
            placeholder="tradition"
            aria-label="tradition"
          />
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="description"
            rows={3}
            aria-label="description"
          />
          <button
            type="submit"
            disabled={creating}
            className="justify-self-start rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200 disabled:opacity-50"
          >
            {creating ? "opening…" : "create & open"}
          </button>
        </form>

        {grimoires.length > 0 ? (
          <div className="mt-6">
            <h3 className="smallcaps mb-2 text-sm text-brass-300">Your grimoires</h3>
            <ul className="divide-y divide-brass-500/10">
              {grimoires.map((g) => (
                <li key={g.slug} className="flex items-center justify-between gap-2 py-2">
                  <Link href={`/workshop/${g.slug}`} className="link-brass text-sm">
                    {g.name}
                  </Link>
                  <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
                    {g.entryCount} entries
                  </span>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </section>

      <section className="panel p-5">
        <h2 className="smallcaps mb-3 text-base text-brass-300">.grim import / validate</h2>
        <p className="mb-3 text-xs leading-relaxed text-parchment-200/60">
          The .grim format is YAML with three top-level keys: <span className="mono">grimoire</span>,{" "}
          <span className="mono">entries</span>, <span className="mono">sources</span>. Validation checks entry types,
          required names, and warns when user material claims to be a primary source.
        </p>
        <textarea
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          rows={16}
          className="mono w-full"
          aria-label="grim source"
          spellCheck={false}
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => submitGrim("validate")}
            disabled={checking}
            className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200 disabled:opacity-50"
          >
            validate
          </button>
          <button
            type="button"
            onClick={() => submitGrim("import")}
            disabled={checking}
            className="rounded-sm border border-brass-500/30 px-4 py-1.5 text-sm text-parchment-100 disabled:opacity-50"
          >
            import into workshop
          </button>
          <a
            href="/api/grim"
            className="mono rounded-sm border border-brass-500/25 px-3 py-1.5 text-[11px] uppercase tracking-[0.2em] text-parchment-200/70 no-underline"
          >
            download template
          </a>
        </div>

        {validation ? (
          <div className="mt-4 space-y-2">
            <p className={`mono text-[11px] uppercase tracking-[0.2em] ${validation.ok ? "text-emerald-300" : "text-rose-300"}`}>
              {validation.ok ? "valid .grim document" : "invalid .grim document"}
              {validation.imported ? " — imported" : ""}
            </p>
            <ul className="space-y-1">
              {validation.issues.map((issue, i) => (
                <li
                  key={i}
                  className={`mono text-[11px] leading-relaxed ${
                    issue.level === "error" ? "text-rose-300" : "text-amber-300"
                  }`}
                >
                  {issue.level === "error" ? "✗" : "!"} {issue.path} — {issue.message}
                </li>
              ))}
              {validation.issues.length === 0 ? (
                <li className="mono text-[11px] text-emerald-300">✓ no issues found</li>
              ) : null}
            </ul>
            {validation.grimoire ? (
              <Link href={`/workshop/${validation.grimoire.slug}`} className="link-brass mono text-[11px] uppercase tracking-[0.2em]">
                open {validation.grimoire.name} →
              </Link>
            ) : null}
          </div>
        ) : null}
      </section>
    </div>
  );
}
