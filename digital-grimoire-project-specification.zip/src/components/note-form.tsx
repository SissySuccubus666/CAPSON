"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function NoteForm({ documentSlug, entitySlug }: { documentSlug?: string; entitySlug?: string }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [label, setLabel] = useState("USER CREATED");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ title, body, label, documentSlug, entitySlug }),
      });
      if (!res.ok) {
        const json = (await res.json()) as { error?: string };
        throw new Error(json.error ?? "failed");
      }
      setTitle("");
      setBody("");
      router.refresh();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="panel grid gap-3 p-4">
      <p className="smallcaps text-sm text-brass-300">Add a note</p>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="note title"
        required
        aria-label="note title"
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="what you noticed, and where you noticed it"
        rows={4}
        required
        aria-label="note body"
      />
      <div className="flex flex-wrap gap-2">
        <select value={label} onChange={(e) => setLabel(e.target.value)} aria-label="integrity label">
          <option value="USER CREATED">USER CREATED</option>
          <option value="SCHOLARLY INTERPRETATION">SCHOLARLY INTERPRETATION</option>
          <option value="MODERN OCCULT INTERPRETATION">MODERN OCCULT INTERPRETATION</option>
          <option value="UNCERTAIN">UNCERTAIN</option>
        </select>
        <button
          type="submit"
          disabled={busy}
          className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200 disabled:opacity-50"
        >
          {busy ? "saving…" : "save note"}
        </button>
      </div>
      <p className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">
        notes are stored locally in the archive database and always labelled USER CREATED by default
      </p>
      {error ? <p className="text-sm text-rose-300">{error}</p> : null}
    </form>
  );
}
