"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

type Entry = {
  id: number;
  entryType: string;
  name: string;
  body: string;
  label: string;
  meta: Record<string, string | number | null> | null;
  ordinal: number;
};

type Grimoire = {
  id: number;
  slug: string;
  name: string;
  author: string;
  tradition: string;
  description: string;
};

const TYPES = ["entity", "symbol", "correspondence", "text", "note", "illustration", "reference"];

const TYPE_GLYPH: Record<string, string> = {
  entity: "☉",
  symbol: "✧",
  correspondence: "⇌",
  text: "▤",
  note: "✎",
  illustration: "❖",
  reference: "❧",
};

export function GrimoireBuilder({ grimoire, entries }: { grimoire: Grimoire; entries: Entry[] }) {
  const router = useRouter();
  const [entryType, setEntryType] = useState("entity");
  const [name, setName] = useState("");
  const [body, setBody] = useState("");
  const [label, setLabel] = useState("USER CREATED");
  const [meta, setMeta] = useState("");
  const [busy, setBusy] = useState(false);

  const [description, setDescription] = useState(grimoire.description);

  async function addEntry(event: React.FormEvent) {
    event.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    let parsedMeta: Record<string, string | number | null> = {};
    if (meta.trim()) {
      parsedMeta = meta
        .split(/\n|,/)
        .map((line) => line.split(":"))
        .reduce<Record<string, string | number | null>>((acc, [key, value]) => {
          if (!key?.trim() || value === undefined) return acc;
          const trimmed = value.trim();
          acc[key.trim()] = /^-?\d+$/.test(trimmed) ? Number(trimmed) : trimmed;
          return acc;
        }, {});
    }
    await fetch(`/api/grimoires/${grimoire.slug}/entries`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ entryType, name, body, label, meta: parsedMeta }),
    });
    setName("");
    setBody("");
    setMeta("");
    setBusy(false);
    router.refresh();
  }

  async function removeEntry(id: number) {
    await fetch(`/api/grimoires/${grimoire.slug}/entries?id=${id}`, { method: "DELETE" });
    router.refresh();
  }

  async function saveDescription() {
    setBusy(true);
    await fetch(`/api/grimoires/${grimoire.slug}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ description }),
    });
    setBusy(false);
    router.refresh();
  }

  async function destroy() {
    if (!confirm(`Delete ${grimoire.name} and all its entries?`)) return;
    await fetch(`/api/grimoires/${grimoire.slug}`, { method: "DELETE" });
    router.push("/workshop");
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_330px]">
      <div>
        <div className="panel mb-6 p-5">
          <h2 className="smallcaps mb-3 text-base text-brass-300">
            Entries <span className="text-parchment-200/40">({entries.length})</span>
          </h2>
          <div className="space-y-3">
            {entries.map((entry) => (
              <article key={entry.id} className="panel-parchment p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <p className="mono text-[10px] uppercase tracking-[0.2em] text-brass-500/80">
                      {TYPE_GLYPH[entry.entryType] ?? "·"} {entry.entryType} · #{entry.ordinal}
                    </p>
                    <h3 className="mt-1 text-[16px]">{entry.name}</h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="mono rounded-sm border border-teal-500/40 bg-teal-500/10 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-teal-200">
                      {entry.label}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeEntry(entry.id)}
                      className="mono rounded-sm border border-rose-500/30 px-2 py-0.5 text-[10px] uppercase tracking-wider text-rose-300"
                    >
                      remove
                    </button>
                  </div>
                </div>
                {entry.body ? (
                  <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-parchment-200/80">{entry.body}</p>
                ) : null}
                {entry.meta && Object.keys(entry.meta).length > 0 ? (
                  <ul className="mono mt-2 flex flex-wrap gap-2 text-[10px] uppercase tracking-wider text-parchment-200/50">
                    {Object.entries(entry.meta).map(([key, value]) => (
                      <li key={key} className="rounded-sm border border-brass-500/20 px-1.5 py-0.5">
                        {key}: {String(value)}
                      </li>
                    ))}
                  </ul>
                ) : null}
              </article>
            ))}
            {entries.length === 0 ? (
              <p className="text-sm text-parchment-200/55">Empty. Add the first entry on the right.</p>
            ) : null}
          </div>
        </div>

        <div className="panel p-5">
          <h2 className="smallcaps mb-3 text-base text-brass-300">Export</h2>
          <div className="flex flex-wrap gap-2">
            <a
              href={`/api/grimoires/${grimoire.slug}/export`}
              className="mono rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-[11px] uppercase tracking-[0.2em] text-brass-200 no-underline"
            >
              download .grim
            </a>
            <a
              href="/api/grim"
              className="mono rounded-sm border border-brass-500/25 px-4 py-1.5 text-[11px] uppercase tracking-[0.2em] text-parchment-200/70 no-underline"
            >
              blank template
            </a>
            <button
              type="button"
              onClick={destroy}
              className="mono rounded-sm border border-rose-500/30 px-4 py-1.5 text-[11px] uppercase tracking-[0.2em] text-rose-300"
            >
              delete grimoire
            </button>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-parchment-200/55">
            The export writes the grimoire, its entries and every reference entry as a YAML document you can share,
            hand-edit, validate and re-import on another machine. Nothing leaves your system.
          </p>
        </div>
      </div>

      <aside className="space-y-6">
        <form onSubmit={addEntry} className="panel grid gap-3 p-4">
          <p className="smallcaps text-sm text-brass-300">Add an entry</p>
          <select value={entryType} onChange={(e) => setEntryType(e.target.value)} aria-label="entry type">
            {TYPES.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="name" required aria-label="name" />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={4}
            placeholder="body — what this entry records"
            aria-label="body"
          />
          <input
            value={meta}
            onChange={(e) => setMeta(e.target.value)}
            placeholder="meta — planet: Saturn, number: 7"
            aria-label="metadata"
          />
          <select value={label} onChange={(e) => setLabel(e.target.value)} aria-label="integrity label">
            <option value="USER CREATED">USER CREATED</option>
            <option value="PRIMARY SOURCE">PRIMARY SOURCE</option>
            <option value="SECONDARY SOURCE">SECONDARY SOURCE</option>
            <option value="SCHOLARLY INTERPRETATION">SCHOLARLY INTERPRETATION</option>
            <option value="MODERN OCCULT INTERPRETATION">MODERN OCCULT INTERPRETATION</option>
            <option value="FICTIONAL">FICTIONAL</option>
            <option value="UNCERTAIN">UNCERTAIN</option>
          </select>
          <button
            type="submit"
            disabled={busy}
            className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200 disabled:opacity-50"
          >
            {busy ? "working…" : "add entry"}
          </button>
        </form>

        <div className="panel p-4">
          <p className="smallcaps mb-2 text-sm text-brass-300">Description</p>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            aria-label="grimoire description"
          />
          <button
            type="button"
            onClick={saveDescription}
            disabled={busy}
            className="mono mt-2 rounded-sm border border-brass-500/30 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-parchment-200/70 disabled:opacity-50"
          >
            save description
          </button>
        </div>

        <div className="panel p-4">
          <p className="smallcaps mb-2 text-sm text-brass-300">Record</p>
          <ul className="mono space-y-1 text-[10px] uppercase tracking-[0.15em] text-parchment-200/50">
            <li>slug: {grimoire.slug}</li>
            <li>author: {grimoire.author}</li>
            <li>tradition: {grimoire.tradition}</li>
            <li>entries: {entries.length}</li>
          </ul>
        </div>
      </aside>
    </div>
  );
}
