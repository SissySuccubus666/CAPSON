"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

type Persona = { slug: string; name: string; focus: string; capabilities: string[] };

type Citation = {
  document: string;
  slug: string;
  locator: string;
  author: string;
  date: string;
  tradition: string;
  label: string;
  snippet: string;
  score: number;
};

type RetrievedCorrespondence = {
  domain: string;
  key: string;
  attribute: string;
  value: string;
  sourceRef: string;
  label: string;
  score: number;
};

type Answer = {
  question: string;
  persona: string;
  personaName: string;
  answer: string;
  engine: string;
  model: string | null;
  confidence: string;
  citations: Citation[];
  correspondences?: RetrievedCorrespondence[];
};

const EXAMPLES = [
  "What is the historical relationship between Hermeticism and alchemy?",
  "Compare Renaissance ceremonial magic with modern ceremonial magic.",
  "What are the correspondences of Saturn?",
  "Which sources first catalogue Paimon?",
  "Explain the translation history of the Picatrix.",
];

export function OracleConsole({ personas }: { personas: Persona[] }) {
  const [persona, setPersona] = useState(personas[0]?.slug ?? "archivist");
  const [question, setQuestion] = useState("");
  const [history, setHistory] = useState<Answer[]>([]);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ reachable: boolean; model: string; url: string } | null>(null);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetch("/api/ask")
      .then((res) => res.json())
      .then((json: { ollama: { reachable: boolean; model: string; url: string } }) => setStatus(json.ollama))
      .catch(() => setStatus({ reachable: false, model: "?", url: "?" }));
  }, []);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [history, busy]);

  async function ask(text?: string) {
    const q = (text ?? question).trim();
    if (!q || busy) return;
    setBusy(true);
    setQuestion("");
    try {
      const res = await fetch("/api/ask", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ question: q, persona }),
      });
      const json = (await res.json()) as Answer;
      setHistory((prev) => [...prev, json]);
    } finally {
      setBusy(false);
    }
  }

  const active = personas.find((p) => p.slug === persona);

  return (
    <div className="grid gap-6 lg:grid-cols-[300px_minmax(0,1fr)]">
      <aside className="space-y-4">
        <div className="panel p-4">
          <h2 className="smallcaps mb-3 text-sm text-brass-300">Research personas</h2>
          <div className="space-y-2">
            {personas.map((p) => (
              <button
                key={p.slug}
                type="button"
                onClick={() => setPersona(p.slug)}
                className={`w-full rounded-sm border p-3 text-left transition ${
                  p.slug === persona
                    ? "border-brass-500/50 bg-brass-500/10"
                    : "border-brass-500/15 hover:border-brass-500/35"
                }`}
              >
                <p className="text-[15px] text-parchment-100">{p.name}</p>
                <p className="mt-1 text-xs leading-relaxed text-parchment-200/60">{p.focus}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="panel p-4">
          <h2 className="smallcaps mb-2 text-sm text-brass-300">Local model</h2>
          {status ? (
            <>
              <p className="mono text-[11px] uppercase tracking-[0.15em] text-parchment-200/55">
                ollama · {status.model}
              </p>
              <p className={`mt-2 text-sm ${status.reachable ? "text-emerald-300" : "text-amber-300"}`}>
                {status.reachable ? "reachable — answers will be synthesised" : "not reachable — retrieval-only mode"}
              </p>
              <p className="mono mt-2 text-[10px] break-all uppercase tracking-wider text-parchment-200/35">
                {status.url}
              </p>
              <p className="mt-3 text-xs leading-relaxed text-parchment-200/55">
                Set <span className="mono">OLLAMA_URL</span> and <span className="mono">OLLAMA_MODEL</span> to point at
                your own machine. Without a model the guide still answers, but only by reporting what the retrieval
                engine found.
              </p>
            </>
          ) : (
            <p className="mono text-[11px] text-parchment-200/45">checking…</p>
          )}
        </div>

        {active ? (
          <div className="panel p-4">
            <h2 className="smallcaps mb-2 text-sm text-brass-300">Capabilities</h2>
            <ul className="mono space-y-1 text-[10px] uppercase tracking-[0.15em] text-parchment-200/50">
              {active.capabilities.map((c) => (
                <li key={c}>· {c}</li>
              ))}
            </ul>
          </div>
        ) : null}
      </aside>

      <div className="panel flex min-h-[640px] flex-col">
        <div className="flex-1 space-y-5 overflow-y-auto p-5">
          {history.length === 0 ? (
            <div className="space-y-4">
              <p className="text-sm leading-relaxed text-parchment-200/70">
                Ask the archive. The guide runs your question through retrieval first, then answers only from what it
                found — and prints the sources it used, with a confidence rating.
              </p>
              <div className="space-y-2">
                {EXAMPLES.map((example) => (
                  <button
                    key={example}
                    type="button"
                    onClick={() => ask(example)}
                    className="block w-full rounded-sm border border-brass-500/20 p-2 text-left text-sm text-parchment-200/75 transition hover:border-brass-500/45 hover:text-parchment-100"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {history.map((entry, index) => (
            <article key={index} className="space-y-3">
              <div className="flex justify-end">
                <p className="max-w-[85%] rounded-sm border border-brass-500/25 bg-brass-500/10 p-3 text-sm text-parchment-100">
                  {entry.question}
                </p>
              </div>
              <div className="panel-parchment p-4">
                <div className="mb-2 flex flex-wrap items-center gap-2">
                  <span className="mono text-[10px] uppercase tracking-[0.2em] text-brass-500/80">
                    {entry.personaName}
                  </span>
                  <span className="mono rounded-sm border border-brass-500/25 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-parchment-200/60">
                    {entry.engine === "ollama" ? `local model · ${entry.model}` : "retrieval-only"}
                  </span>
                  <span
                    className={`mono rounded-sm border px-1.5 py-0.5 text-[10px] uppercase tracking-wider ${
                      entry.confidence === "HIGH"
                        ? "border-emerald-500/40 text-emerald-300"
                        : entry.confidence === "MEDIUM"
                          ? "border-amber-500/40 text-amber-300"
                          : "border-rose-500/40 text-rose-300"
                    }`}
                  >
                    confidence {entry.confidence}
                  </span>
                </div>
                <p className="whitespace-pre-wrap text-[15px] leading-[1.75] text-parchment-100/90">{entry.answer}</p>

                {entry.citations.length > 0 ? (
                  <div className="mt-4 border-t border-brass-500/15 pt-3">
                    <p className="mono mb-2 text-[10px] uppercase tracking-[0.2em] text-brass-500/70">
                      sources · {entry.citations.length} passages
                    </p>
                    <ul className="space-y-2">
                      {entry.citations.map((citation, i) => (
                        <li key={`${citation.slug}-${i}`} className="text-xs leading-relaxed text-parchment-200/65">
                          <span className="mono mr-1 text-brass-500/80">[{i + 1}]</span>
                          <Link href={`/library/${citation.slug}`} className="link-brass">
                            {citation.document}
                          </Link>{" "}
                          — {citation.locator} — {citation.date} — {citation.tradition} —{" "}
                          <span className="mono uppercase tracking-wider">{citation.label}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <p className="mt-4 border-t border-brass-500/15 pt-3 text-xs text-rose-300">
                    No passages were retrieved for this question, so nothing above should be trusted as sourced.
                  </p>
                )}

                {entry.correspondences && entry.correspondences.length > 0 ? (
                  <div className="mt-3 border-t border-brass-500/15 pt-3">
                    <p className="mono mb-2 text-[10px] uppercase tracking-[0.2em] text-brass-500/70">
                      correspondence rows matched · {entry.correspondences.length}
                    </p>
                    <ul className="grid gap-1 sm:grid-cols-2">
                      {entry.correspondences.map((row, i) => (
                        <li key={i} className="mono text-[11px] text-parchment-200/70">
                          <span className="text-parchment-100">{row.key}</span> · {row.attribute} = {row.value}{" "}
                          <span className="text-parchment-200/35">[{row.sourceRef}]</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : null}
              </div>
            </article>
          ))}

          {busy ? (
            <p className="mono text-[11px] uppercase tracking-[0.2em] text-brass-500/80">
              searching the archive · building context · consulting…
            </p>
          ) : null}
          <div ref={bottom} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void ask();
          }}
          className="flex flex-wrap gap-2 border-t border-brass-500/15 p-4"
        >
          <input
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="ask the archive…"
            className="min-w-[240px] flex-1"
            aria-label="question"
          />
          <button
            type="submit"
            disabled={busy}
            className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-5 py-2 text-sm text-brass-200 disabled:opacity-50"
          >
            {busy ? "working…" : "ask"}
          </button>
        </form>
      </div>
    </div>
  );
}
