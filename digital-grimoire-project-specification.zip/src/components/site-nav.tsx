"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const LINKS = [
  { href: "/", label: "Archive" },
  { href: "/library", label: "Library" },
  { href: "/search", label: "Search" },
  { href: "/entities", label: "Entities" },
  { href: "/symbols", label: "Symbols" },
  { href: "/graph", label: "Graph" },
  { href: "/timeline", label: "Timeline" },
  { href: "/oracle", label: "Oracle" },
  { href: "/workshop", label: "Workshop" },
  { href: "/cli", label: "CLI" },
];

export function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);

  return (
    <header className="sticky top-0 z-40 border-b border-brass-500/20 bg-ink-900/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-5 py-3 sm:px-8">
        <Link href="/" className="flex items-center gap-3 no-underline">
          <span className="grid size-9 place-items-center rounded-sm border border-brass-500/40 text-brass-400">
            🜏
          </span>
          <span className="leading-tight">
            <span className="block text-base text-parchment-100">The Digital Grimoire</span>
            <span className="mono block text-[10px] uppercase tracking-[0.25em] text-brass-500/70">
              archive · ai · graph
            </span>
          </span>
        </Link>

        <nav className="ml-auto hidden items-center gap-1 lg:flex">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-sm px-3 py-1.5 text-sm no-underline transition ${
                isActive(link.href)
                  ? "bg-brass-500/15 text-brass-300"
                  : "text-parchment-200/70 hover:bg-ink-700/60 hover:text-parchment-100"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="ml-auto rounded-sm border border-brass-500/30 px-3 py-1.5 text-sm text-brass-300 lg:hidden"
        >
          {open ? "close" : "menu"}
        </button>
      </div>

      {open ? (
        <nav className="grid grid-cols-2 gap-1 border-t border-brass-500/15 px-5 py-3 sm:px-8 lg:hidden">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className={`rounded-sm px-3 py-2 text-sm no-underline ${
                isActive(link.href) ? "bg-brass-500/15 text-brass-300" : "text-parchment-200/70"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      ) : null}
    </header>
  );
}
