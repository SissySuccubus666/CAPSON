"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type Option = { value: string; label: string };

type SearchResponse = {
  query: string;
  counts: {
    documents: number;
    entities: number;
    symbols: number;
    traditions: number;
    passages: number;
    correspondences: number;
  };
  documents: {
    slug: string;
    title: string;
    dateCreated: string;
    language: string | null;
    tradition: string | null;
    summary: string;
    label: string;
  }[];
  entities: { slug: string; name: string; kind: string; historicalPeriod: string | null; label: string; confidence: string }[];
  symbols: { slug: string; name: string; glyph: string; category: string; label: string }[];
  traditions: { slug: string; name: string; summary: string }[];
  passages: {
    document: string;
    slug: string;
    locator: string;
    author: string;
    date: string;
    tradition: string;
    label: string;
    snippet: string;
    score: number;
  }[];
  correspondences: { domain: string; key: string; attribute: string; value: string; sourceRef: string; label: string }[];
};

const SUGGESTIONS = [
  "Hermes",
  "Saturn",
  "as above so below",
  "Holy Guardian Angel",
  "Seal of Solomon",
  "Baphomet",
  "planetary hours",
];

export function SearchPanel({ traditions, languages }: { traditions: Option[]; languages: Option[] }) {
  const [q, setQ] = useState("");
  const [tradition, setTradition] = useState("");
  const [language, setLanguage] = useState("");
  const [label, setLabel] = useState("");
  const [data, setData] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);

  const run = useCallback(async () => {
    if (!q.trim()) {
      setData(null);
      return;
    }
    setBusy(true);
    const params = new URLSearchParams({ q });
    if (tradition) params.set("tradition", tradition);
    if (language) params.set("language", language);
    if (label) params.set("label", label);
    const res = await fetch(`/api/search?${params.toString()}`);
    setData((await res.json()) as SearchResponse);
    setBusy(false);
  }, [q, tradition, language, label]);

  useEffect(() => {
    const timer = setTimeout(run, 250);
    return () => clearTimeout(timer);
  }, [run]);

  return (
    <div>
      <div className="panel mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="> SEARCH: Hermes"
          className="lg:col-span-2"
          aria-label="search query"
          autoFocus
        />
        <select value={tradition} onChange={(e) => setTradition(e.target.value)} aria-label="tradition">
          <option value="">tradition — all</option>
          {traditions.map((t) => (
            <option key={t.value} value={t.value}>
              {t.label}
            </option>
          ))}
        </select>
        <select value={language} onChange={(e) => setLanguage(e.target.value)} aria-label="language">
          <option value="">language — all</option>
          {languages.map((l) => (
            <option key={l.value || "unknown"} value={l.value}>
              {l.label}
            </option>
          ))}
        </select>
        <select value={label} onChange={(e) => setLabel(e.target.value)} aria-label="label">
          <option value="">label — all</option>
          <option value="PRIMARY SOURCE">PRIMARY SOURCE</option>
          <option value="SECONDARY SOURCE">SECONDARY SOURCE</option>
          <option value="SCHOLARLY INTERPRETATION">SCHOLARLY INTERPRETATION</option>
          <option value="MODERN OCCULT INTERPRETATION">MODERN OCCULT INTERPRETATION</option>
          <option value="UNCERTAIN">UNCERTAIN</option>
        </select>
        <div className="mono flex flex-wrap items-center gap-2 sm:col-span-2 lg:col-span-5">
          <span className="text-[10px] uppercase tracking-[0.2em] text-parchment-200/40">try:</span>
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setQ(s)}
              className="rounded-sm border border-brass-500/20 px-2 py-0.5 text-[10px] uppercase tracking-[0.15em] text-parchment-200/60 hover:border-brass-500/50 hover:text-brass-300"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {data ? (
        <>
          <div className="panel mb-6 p-4">
            <p className="mono text-[11px] uppercase tracking-[0.2em] text-brass-500/80">
              {data.counts.documents} documents · {data.counts.entities} entities · {data.counts.symbols} symbols ·{" "}
              {data.counts.traditions} traditions · {data.counts.passages} passages ·{" "}
              {data.counts.correspondences} correspondences
              {busy ? " · searching…" : ""}
            </p>
          </div>

          {data.passages.length > 0 ? (
            <section className="mb-8">
              <h2 className="smallcaps mb-3 text-lg text-brass-300">Passages ranked</h2>
              <div className="space-y-3">
                {data.passages.map((p, i) => (
                  <article key={`${p.slug}-${i}`} className="panel-parchment p-4">
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                      <p className="mono text-[11px] uppercase tracking-[0.15em] text-brass-500/80">
                        score {p.score} · {p.tradition}
                      </p>
                      <span className="mono rounded-sm border px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-parchment-200/70">
                        {p.label}
                      </span>
                    </div>
                    <Link href={`/library/${p.slug}`} className="link-brass text-base">
                      {p.document}
                    </Link>
                    <span className="ml-2 text-xs text-parchment-200/50">{p.locator}</span>
                    <p className="mt-2 text-sm leading-relaxed text-parchment-200/75">{p.snippet}…</p>
                    <p className="mono mt-2 text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">
                      {p.author} · {p.date}
                    </p>
                  </article>
                ))}
              </div>
            </section>
          ) : null}

          <div className="grid gap-8 lg:grid-cols-2">
            <section className="mb-8">
              <h2 className="smallcaps mb-3 text-lg text-brass-300">Documents</h2>
              <ul className="panel divide-y divide-brass-500/10">
                {data.documents.map((d) => (
                  <li key={d.slug} className="p-3">
                    <Link href={`/library/${d.slug}`} className="link-brass">
                      {d.title}
                    </Link>
                    <p className="mono mt-1 text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
                      {d.dateCreated} · {d.language} · {d.label}
                    </p>
                  </li>
                ))}
                {data.documents.length === 0 ? <li className="p-3 text-sm text-parchment-200/50">none</li> : null}
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="smallcaps mb-3 text-lg text-brass-300">Entities</h2>
              <ul className="panel divide-y divide-brass-500/10">
                {data.entities.map((e) => (
                  <li key={e.slug} className="flex items-center justify-between gap-3 p-3">
                    <Link href={`/entities/${e.slug}`} className="link-brass">
                      {e.name}
                    </Link>
                    <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
                      {e.kind} · {e.confidence}
                    </span>
                  </li>
                ))}
                {data.entities.length === 0 ? <li className="p-3 text-sm text-parchment-200/50">none</li> : null}
              </ul>

              <h2 className="smallcaps mb-3 mt-6 text-lg text-brass-300">Symbols</h2>
              <ul className="panel divide-y divide-brass-500/10">
                {data.symbols.map((s) => (
                  <li key={s.slug} className="flex items-center justify-between gap-3 p-3">
                    <span className="text-parchment-100">
                      <span className="mr-2 text-brass-400">{s.glyph}</span>
                      <Link href={`/symbols?q=${encodeURIComponent(s.name)}`} className="link-brass">
                        {s.name}
                      </Link>
                    </span>
                    <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">{s.category}</span>
                  </li>
                ))}
                {data.symbols.length === 0 ? <li className="p-3 text-sm text-parchment-200/50">none</li> : null}
              </ul>
            </section>

            <section className="mb-8 lg:col-span-2">
              <h2 className="smallcaps mb-3 text-lg text-brass-300">Correspondences</h2>
              <div className="panel overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="mono text-[10px] uppercase tracking-[0.18em] text-brass-500/70">
                      <th className="p-2">domain</th>
                      <th className="p-2">key</th>
                      <th className="p-2">attribute</th>
                      <th className="p-2">value</th>
                      <th className="p-2">source</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.correspondences.map((c, i) => (
                      <tr key={i} className="border-t border-brass-500/10">
                        <td className="p-2 text-parchment-200/60">{c.domain}</td>
                        <td className="p-2 text-parchment-100">{c.key}</td>
                        <td className="p-2 text-parchment-200/70">{c.attribute}</td>
                        <td className="p-2 text-parchment-100">{c.value}</td>
                        <td className="mono p-2 text-[10px] uppercase tracking-wider text-parchment-200/45">
                          {c.sourceRef}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {data.correspondences.length === 0 ? (
                  <p className="p-3 text-sm text-parchment-200/50">no correspondence rows matched</p>
                ) : null}
              </div>
            </section>
          </div>
        </>
      ) : (
        <p className="panel p-6 text-sm text-parchment-200/60">
          Type a query above. The engine searches titles, attributions, summaries, passages, alternate entity names,
          symbol meanings and every correspondence table in one pass.
        </p>
      )}
    </div>
  );
}
