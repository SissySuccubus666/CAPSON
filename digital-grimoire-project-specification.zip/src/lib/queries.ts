import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";

import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import {
  authors,
  correspondences,
  documents,
  entities,
  grimoireEntries,
  customGrimoires,
  notes,
  passages,
  relations,
  sources,
  symbols,
  timelineEvents,
  traditions,
} from "@/db/schema";

export type GraphNode = {
  key: string;
  kind: string;
  label: string;
  slug: string;
  degree: number;
};

export type GraphEdge = {
  from: string;
  to: string;
  predicate: string;
  label: string;
  weight: number;
};

async function ready() {
  await ensureSeeded();
}

/* ------------------------------------------------------------------ */
/* Stats                                                               */
/* ------------------------------------------------------------------ */
export async function getStats() {
  await ready();
  const [[docs], [ents], [syms], [trads], [corr], [rel], [evs], [grim]] = await Promise.all([
    db.select({ n: sql<number>`count(*)::int` }).from(documents),
    db.select({ n: sql<number>`count(*)::int` }).from(entities),
    db.select({ n: sql<number>`count(*)::int` }).from(symbols),
    db.select({ n: sql<number>`count(*)::int` }).from(traditions),
    db.select({ n: sql<number>`count(*)::int` }).from(correspondences),
    db.select({ n: sql<number>`count(*)::int` }).from(relations),
    db.select({ n: sql<number>`count(*)::int` }).from(timelineEvents),
    db.select({ n: sql<number>`count(*)::int` }).from(customGrimoires),
  ]);
  return {
    documents: docs.n,
    entities: ents.n,
    symbols: syms.n,
    traditions: trads.n,
    correspondences: corr.n,
    relations: rel.n,
    timeline: evs.n,
    grimoires: grim.n,
  };
}

/* ------------------------------------------------------------------ */
/* Library                                                             */
/* ------------------------------------------------------------------ */
export type DocumentFilters = {
  q?: string;
  tradition?: string;
  language?: string;
  docType?: string;
  label?: string;
  period?: string;
};

export async function listDocuments(filters: DocumentFilters = {}) {
  await ready();
  const where = [];
  if (filters.q) {
    where.push(
      or(
        ilike(documents.title, `%${filters.q}%`),
        ilike(documents.attribution, `%${filters.q}%`),
        ilike(documents.summary, `%${filters.q}%`),
      ),
    );
  }
  if (filters.tradition) where.push(eq(traditions.slug, filters.tradition));
  if (filters.language) where.push(eq(documents.language, filters.language));
  if (filters.docType) where.push(eq(documents.docType, filters.docType));
  if (filters.label) where.push(eq(documents.label, filters.label));
  if (filters.period) where.push(eq(documents.historicalPeriod, filters.period));

  return db
    .select({
      id: documents.id,
      slug: documents.slug,
      title: documents.title,
      originalTitle: documents.originalTitle,
      attribution: documents.attribution,
      dateCreated: documents.dateCreated,
      yearStart: documents.yearStart,
      language: documents.language,
      docType: documents.docType,
      historicalPeriod: documents.historicalPeriod,
      region: documents.region,
      summary: documents.summary,
      label: documents.label,
      tradition: traditions.name,
      traditionSlug: traditions.slug,
      authorName: authors.name,
      translator: documents.translator,
      copyrightStatus: documents.copyrightStatus,
    })
    .from(documents)
    .leftJoin(traditions, eq(documents.traditionId, traditions.id))
    .leftJoin(authors, eq(documents.authorId, authors.id))
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(documents.yearStart), asc(documents.title));
}

export async function getLibraryFacets() {
  await ready();
  const [tradRows, langRows, typeRows, periodRows] = await Promise.all([
    db.select({ slug: traditions.slug, name: traditions.name }).from(traditions).orderBy(asc(traditions.name)),
    db
      .select({ value: documents.language, n: sql<number>`count(*)::int` })
      .from(documents)
      .groupBy(documents.language)
      .orderBy(desc(sql`count(*)`)),
    db
      .select({ value: documents.docType, n: sql<number>`count(*)::int` })
      .from(documents)
      .groupBy(documents.docType)
      .orderBy(desc(sql`count(*)`)),
    db
      .select({ value: documents.historicalPeriod, n: sql<number>`count(*)::int` })
      .from(documents)
      .groupBy(documents.historicalPeriod)
      .orderBy(desc(sql`count(*)`)),
  ]);
  return { traditions: tradRows, languages: langRows, docTypes: typeRows, periods: periodRows };
}

export async function getDocument(slug: string) {
  await ready();
  const [doc] = await db
    .select({
      id: documents.id,
      slug: documents.slug,
      title: documents.title,
      originalTitle: documents.originalTitle,
      attribution: documents.attribution,
      dateCreated: documents.dateCreated,
      yearStart: documents.yearStart,
      yearEnd: documents.yearEnd,
      region: documents.region,
      language: documents.language,
      translator: documents.translator,
      edition: documents.edition,
      copyrightStatus: documents.copyrightStatus,
      docType: documents.docType,
      historicalPeriod: documents.historicalPeriod,
      summary: documents.summary,
      label: documents.label,
      tradition: traditions.name,
      traditionSlug: traditions.slug,
      authorName: authors.name,
      authorFlourished: authors.flourished,
      sourceTitle: sources.title,
      sourceUrl: sources.url,
      sourceType: sources.sourceType,
    })
    .from(documents)
    .leftJoin(traditions, eq(documents.traditionId, traditions.id))
    .leftJoin(authors, eq(documents.authorId, authors.id))
    .leftJoin(sources, eq(documents.sourceId, sources.id))
    .where(eq(documents.slug, slug))
    .limit(1);
  if (!doc) return null;

  const [docPassages, docNotes, edges] = await Promise.all([
    db.select().from(passages).where(eq(passages.documentId, doc.id)).orderBy(asc(passages.ordinal)),
    db.select().from(notes).where(eq(notes.documentSlug, slug)).orderBy(desc(notes.createdAt)),
    db
      .select()
      .from(relations)
      .where(or(eq(relations.fromKey, `document:${slug}`), eq(relations.toKey, `document:${slug}`))),
  ]);

  return { document: doc, passages: docPassages, notes: docNotes, edges };
}

/* ------------------------------------------------------------------ */
/* Entities                                                            */
/* ------------------------------------------------------------------ */
export async function listEntities(filters: { q?: string; kind?: string; tradition?: string } = {}) {
  await ready();
  const where = [];
  if (filters.q) {
    where.push(
      or(
        ilike(entities.name, `%${filters.q}%`),
        ilike(entities.symbolism, `%${filters.q}%`),
        sql`array_to_string(${entities.alternateNames}, ' ') ilike ${`%${filters.q}%`}`,
      ),
    );
  }
  if (filters.kind) where.push(eq(entities.kind, filters.kind));
  if (filters.tradition) where.push(eq(traditions.slug, filters.tradition));

  return db
    .select({
      slug: entities.slug,
      name: entities.name,
      kind: entities.kind,
      alternateNames: entities.alternateNames,
      historicalPeriod: entities.historicalPeriod,
      symbolism: entities.symbolism,
      confidence: entities.confidence,
      label: entities.label,
      tradition: traditions.name,
      traditionSlug: traditions.slug,
    })
    .from(entities)
    .leftJoin(traditions, eq(entities.traditionId, traditions.id))
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(entities.name));
}

export async function getEntity(slug: string) {
  await ready();
  const [entity] = await db
    .select({
      entity: entities,
      tradition: traditions,
    })
    .from(entities)
    .leftJoin(traditions, eq(entities.traditionId, traditions.id))
    .where(eq(entities.slug, slug))
    .limit(1);
  if (!entity) return null;

  const [edges, corr] = await Promise.all([
    db
      .select()
      .from(relations)
      .where(or(eq(relations.fromKey, `entity:${slug}`), eq(relations.toKey, `entity:${slug}`))),
    db.select().from(correspondences).where(eq(correspondences.key, entity.entity.name)),
  ]);

  return { ...entity, edges, correspondences: corr };
}

/* ------------------------------------------------------------------ */
/* Symbols & correspondences                                           */
/* ------------------------------------------------------------------ */
export async function listSymbols(filters: { q?: string; category?: string } = {}) {
  await ready();
  const where = [];
  if (filters.q) {
    where.push(
      or(
        ilike(symbols.name, `%${filters.q}%`),
        ilike(symbols.meaning, `%${filters.q}%`),
        ilike(symbols.usage, `%${filters.q}%`),
      ),
    );
  }
  if (filters.category) where.push(eq(symbols.category, filters.category));
  return db
    .select({
      slug: symbols.slug,
      name: symbols.name,
      glyph: symbols.glyph,
      category: symbols.category,
      meaning: symbols.meaning,
      usage: symbols.usage,
      firstAttested: symbols.firstAttested,
      confidence: symbols.confidence,
      label: symbols.label,
      tradition: traditions.name,
    })
    .from(symbols)
    .leftJoin(traditions, eq(symbols.traditionId, traditions.id))
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(symbols.name));
}

export async function listCorrespondences(filters: { domain?: string; key?: string } = {}) {
  await ready();
  const where = [];
  if (filters.domain) where.push(eq(correspondences.domain, filters.domain));
  if (filters.key) where.push(eq(correspondences.key, filters.key));
  return db
    .select()
    .from(correspondences)
    .where(where.length ? and(...where) : undefined)
    .orderBy(asc(correspondences.domain), asc(correspondences.key), asc(correspondences.attribute));
}

/* ------------------------------------------------------------------ */
/* Knowledge graph                                                     */
/* ------------------------------------------------------------------ */
export async function getGraph(focus?: string): Promise<{ nodes: GraphNode[]; edges: GraphEdge[] }> {
  await ready();
  const [relRows, entRows, symRows, tradRows, docRows] = await Promise.all([
    db.select().from(relations),
    db.select({ slug: entities.slug, name: entities.name }).from(entities),
    db.select({ slug: symbols.slug, name: symbols.name }).from(symbols),
    db.select({ slug: traditions.slug, name: traditions.name }).from(traditions),
    db.select({ slug: documents.slug, name: documents.title }).from(documents),
  ]);

  const labelOf = new Map<string, { label: string; kind: string }>();
  entRows.forEach((e) => labelOf.set(`entity:${e.slug}`, { label: e.name, kind: "entity" }));
  symRows.forEach((s) => labelOf.set(`symbol:${s.slug}`, { label: s.name, kind: "symbol" }));
  tradRows.forEach((t) => labelOf.set(`tradition:${t.slug}`, { label: t.name, kind: "tradition" }));
  docRows.forEach((d) => labelOf.set(`document:${d.slug}`, { label: d.name, kind: "document" }));

  const degree = new Map<string, number>();
  const edges: GraphEdge[] = relRows.map((r) => ({
    from: r.fromKey,
    to: r.toKey,
    predicate: r.predicate,
    label: r.label,
    weight: r.weight,
  }));

  if (focus) {
    const seed = focus.includes(":") ? focus : `entity:${focus}`;
    // Breadth-first expansion to two hops, following edges in both directions.
    const keptEdges = new Set<number>();
    let frontier = new Set<string>([seed]);
    const visited = new Set<string>([seed]);
    for (let depth = 0; depth < 2; depth += 1) {
      const next = new Set<string>();
      edges.forEach((edge, index) => {
        if (keptEdges.has(index)) return;
        const fromFrontier = frontier.has(edge.from);
        const toFrontier = frontier.has(edge.to);
        if (!fromFrontier && !toFrontier) return;
        keptEdges.add(index);
        const neighbour = fromFrontier ? edge.to : edge.from;
        if (!visited.has(neighbour)) {
          visited.add(neighbour);
          next.add(neighbour);
        }
      });
      frontier = next;
      if (frontier.size === 0) break;
    }
    const activeEdges = edges.filter((_, index) => keptEdges.has(index));
    const nodes: GraphNode[] = [...visited]
      .filter((key) => labelOf.has(key))
      .map((key) => ({
        key,
        kind: labelOf.get(key)!.kind,
        label: labelOf.get(key)!.label,
        slug: key.split(":")[1],
        degree: 0,
      }));
    nodes.forEach((n) => {
      n.degree = activeEdges.filter((e) => e.from === n.key || e.to === n.key).length;
    });
    return { nodes, edges: activeEdges };
  }

  edges.forEach((e) => {
    degree.set(e.from, (degree.get(e.from) ?? 0) + 1);
    degree.set(e.to, (degree.get(e.to) ?? 0) + 1);
  });
  const nodes: GraphNode[] = [...labelOf.entries()].map(([key, v]) => ({
    key,
    kind: v.kind,
    label: v.label,
    slug: key.split(":")[1],
    degree: degree.get(key) ?? 0,
  }));
  return { nodes, edges };
}

/* ------------------------------------------------------------------ */
/* Timeline                                                            */
/* ------------------------------------------------------------------ */
export async function getTimeline() {
  await ready();
  return db.select().from(timelineEvents).orderBy(asc(timelineEvents.yearStart));
}

export async function listTraditions() {
  await ready();
  return db.select().from(traditions).orderBy(asc(traditions.name));
}

/* ------------------------------------------------------------------ */
/* Unified search                                                      */
/* ------------------------------------------------------------------ */
export type SearchResults = Awaited<ReturnType<typeof searchAll>>;

export async function searchAll(q: string, filters: DocumentFilters = {}) {
  await ready();
  if (!q.trim()) {
    return {
      query: q,
      counts: { documents: 0, entities: 0, symbols: 0, traditions: 0, passages: 0, correspondences: 0 },
      documents: [],
      entities: [],
      symbols: [],
      traditions: [],
      passages: [],
      correspondences: [],
    };
  }
  const like = `%${q}%`;
  const [docRows, entRows, symRows, tradRows, corrRows] = await Promise.all([
    listDocuments({ ...filters, q }),
    db
      .select({
        slug: entities.slug,
        name: entities.name,
        kind: entities.kind,
        historicalPeriod: entities.historicalPeriod,
        label: entities.label,
        confidence: entities.confidence,
      })
      .from(entities)
      .where(
        or(
          ilike(entities.name, like),
          ilike(entities.symbolism, like),
          sql`array_to_string(${entities.alternateNames}, ' ') ilike ${like}`,
        ),
      )
      .limit(12),
    db
      .select({
        slug: symbols.slug,
        name: symbols.name,
        glyph: symbols.glyph,
        category: symbols.category,
        label: symbols.label,
      })
      .from(symbols)
      .where(or(ilike(symbols.name, like), ilike(symbols.meaning, like), ilike(symbols.usage, like)))
      .limit(12),
    db
      .select({ slug: traditions.slug, name: traditions.name, summary: traditions.summary })
      .from(traditions)
      .where(or(ilike(traditions.name, like), ilike(traditions.summary, like)))
      .limit(12),
    db
      .select()
      .from(correspondences)
      .where(
        or(
          ilike(correspondences.key, like),
          ilike(correspondences.value, like),
          ilike(correspondences.attribute, like),
        ),
      )
      .limit(24),
  ]);

  const { retrievePassages } = await import("./retrieval");
  const passageRows = await retrievePassages(q, { limit: 8 });

  return {
    query: q,
    counts: {
      documents: docRows.length,
      entities: entRows.length,
      symbols: symRows.length,
      traditions: tradRows.length,
      passages: passageRows.length,
      correspondences: corrRows.length,
    },
    documents: docRows.slice(0, 12),
    entities: entRows,
    symbols: symRows,
    traditions: tradRows,
    passages: passageRows,
    correspondences: corrRows,
  };
}

/* ------------------------------------------------------------------ */
/* Notes                                                              */
/* ------------------------------------------------------------------ */
export async function listNotes() {
  await ready();
  return db.select().from(notes).orderBy(desc(notes.createdAt)).limit(50);
}

export async function createNote(input: {
  title: string;
  body: string;
  documentSlug?: string | null;
  entitySlug?: string | null;
  label?: string;
}) {
  await ready();
  const [row] = await db
    .insert(notes)
    .values({
      title: input.title,
      body: input.body,
      documentSlug: input.documentSlug ?? null,
      entitySlug: input.entitySlug ?? null,
      label: input.label ?? "USER CREATED",
    })
    .returning();
  return row;
}

/* ------------------------------------------------------------------ */
/* Custom grimoires                                                    */
/* ------------------------------------------------------------------ */
export async function listGrimoires() {
  await ready();
  const rows = await db.select().from(customGrimoires).orderBy(desc(customGrimoires.updatedAt));
  const counts = await db
    .select({ grimoireId: grimoireEntries.grimoireId, n: sql<number>`count(*)::int` })
    .from(grimoireEntries)
    .groupBy(grimoireEntries.grimoireId);
  const countMap = new Map(counts.map((c) => [c.grimoireId, c.n]));
  return rows.map((g) => ({ ...g, entryCount: countMap.get(g.id) ?? 0 }));
}

export async function getGrimoire(slug: string) {
  await ready();
  const [grimoire] = await db.select().from(customGrimoires).where(eq(customGrimoires.slug, slug)).limit(1);
  if (!grimoire) return null;
  const entries = await db
    .select()
    .from(grimoireEntries)
    .where(eq(grimoireEntries.grimoireId, grimoire.id))
    .orderBy(asc(grimoireEntries.ordinal), asc(grimoireEntries.id));
  return { grimoire, entries };
}
