import { parse, stringify } from "yaml";

export const GRIM_ENTRY_TYPES = [
  "entity",
  "symbol",
  "correspondence",
  "text",
  "note",
  "illustration",
  "reference",
] as const;

export type GrimEntryType = (typeof GRIM_ENTRY_TYPES)[number];

export type GrimEntry = {
  type: GrimEntryType;
  name: string;
  body?: string;
  label?: string;
  meta?: Record<string, string | number | null>;
};

export type GrimSource = {
  title: string;
  author?: string;
  date?: string;
  locator?: string;
  label?: string;
};

export type GrimFile = {
  grimoire: {
    name: string;
    author?: string;
    tradition?: string;
    description?: string;
  };
  entries: GrimEntry[];
  sources: GrimSource[];
};

export type GrimValidationIssue = {
  level: "error" | "warning";
  path: string;
  message: string;
};

export type GrimValidation = {
  ok: boolean;
  issues: GrimValidationIssue[];
  file: GrimFile | null;
};

/**
 * .grim — the Digital Grimoire interchange format.
 * A YAML document with three top-level keys: grimoire, entries, sources.
 */
export function serialiseGrim(file: GrimFile): string {
  const header = `# .grim v1 — Digital Grimoire interchange format\n# Every entry carries a label from the source-integrity scheme.\n`;
  const doc = {
    grimoire: file.grimoire,
    entries: file.entries.map((entry) => ({
      type: entry.type,
      name: entry.name,
      ...(entry.body ? { body: entry.body } : {}),
      ...(entry.label ? { label: entry.label } : {}),
      ...(entry.meta && Object.keys(entry.meta).length ? { meta: entry.meta } : {}),
    })),
    sources: file.sources,
  };
  return header + stringify(doc, { lineWidth: 100 });
}

export function validateGrim(raw: string): GrimValidation {
  const issues: GrimValidationIssue[] = [];
  let parsed: unknown;
  try {
    parsed = parse(raw);
  } catch (error) {
    return {
      ok: false,
      issues: [{ level: "error", path: "$", message: `YAML could not be parsed: ${(error as Error).message}` }],
      file: null,
    };
  }

  if (typeof parsed !== "object" || parsed === null) {
    return { ok: false, issues: [{ level: "error", path: "$", message: "Root must be a mapping." }], file: null };
  }
  const root = parsed as Record<string, unknown>;

  if (!root.grimoire || typeof root.grimoire !== "object") {
    issues.push({ level: "error", path: "grimoire", message: "Missing required `grimoire` mapping." });
  }
  const grimMeta = (root.grimoire ?? {}) as Record<string, unknown>;
  if (typeof grimMeta.name !== "string" || grimMeta.name.trim() === "") {
    issues.push({ level: "error", path: "grimoire.name", message: "`grimoire.name` must be a non-empty string." });
  }
  if (root.entries === undefined) {
    issues.push({ level: "warning", path: "entries", message: "No `entries` key: the grimoire will be empty." });
  }

  const entries: GrimEntry[] = [];
  if (Array.isArray(root.entries)) {
    (root.entries as Record<string, unknown>[]).forEach((raw, index) => {
      const path = `entries[${index}]`;
      const type = String(raw.type ?? "");
      if (!GRIM_ENTRY_TYPES.includes(type as GrimEntryType)) {
        issues.push({
          level: "error",
          path: `${path}.type`,
          message: `Unknown entry type "${type}". Allowed: ${GRIM_ENTRY_TYPES.join(", ")}.`,
        });
      }
      if (typeof raw.name !== "string" || raw.name.trim() === "") {
        issues.push({ level: "error", path: `${path}.name`, message: "Entries require a `name`." });
      }
      if (raw.label && typeof raw.label === "string" && raw.label === "PRIMARY SOURCE") {
        issues.push({
          level: "warning",
          path: `${path}.label`,
          message:
            "Labelling user work PRIMARY SOURCE asserts historical authority. Prefer USER CREATED unless quoting.",
        });
      }
      entries.push({
        type: (type || "note") as GrimEntryType,
        name: String(raw.name ?? "untitled"),
        body: typeof raw.body === "string" ? raw.body : "",
        label: typeof raw.label === "string" ? raw.label : "USER CREATED",
        meta: (raw.meta as Record<string, string | number | null>) ?? {},
      });
    });
  }

  const sources: GrimSource[] = Array.isArray(root.sources)
    ? (root.sources as Record<string, unknown>[]).map((s) => ({
        title: String(s.title ?? "untitled source"),
        author: typeof s.author === "string" ? s.author : undefined,
        date: typeof s.date === "string" ? s.date : undefined,
        locator: typeof s.locator === "string" ? s.locator : undefined,
        label: typeof s.label === "string" ? s.label : "SECONDARY SOURCE",
      }))
    : [];

  if (entries.length > 0 && sources.length === 0) {
    issues.push({
      level: "warning",
      path: "sources",
      message: "A grimoire with entries but no sources cannot be checked against the archive.",
    });
  }

  const file: GrimFile = {
    grimoire: {
      name: String(grimMeta.name ?? "Untitled Grimoire"),
      author: typeof grimMeta.author === "string" ? grimMeta.author : undefined,
      tradition: typeof grimMeta.tradition === "string" ? grimMeta.tradition : undefined,
      description: typeof grimMeta.description === "string" ? grimMeta.description : undefined,
    },
    entries,
    sources,
  };

  return { ok: !issues.some((i) => i.level === "error"), issues, file };
}

export function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .slice(0, 60) || "grimoire"
  );
}
