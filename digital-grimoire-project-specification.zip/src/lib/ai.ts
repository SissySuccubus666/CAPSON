import { eq } from "drizzle-orm";

import { db } from "@/db";
import { personas } from "@/db/schema";
import type { Citation } from "@/db/schema";
import {
  deriveConfidence,
  extractiveSummary,
  retrieveCorrespondences,
  retrievePassages,
  type RetrievedCorrespondence,
  type ScoredCitation,
} from "./retrieval";

export const OLLAMA_URL = process.env.OLLAMA_URL ?? "http://127.0.0.1:11434";
export const OLLAMA_MODEL = process.env.OLLAMA_MODEL ?? "llama3.2";

export type AskResult = {
  question: string;
  persona: string;
  personaName: string;
  answer: string;
  engine: "ollama" | "retrieval-only";
  model: string | null;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  citations: ScoredCitation[];
  correspondences: RetrievedCorrespondence[];
};

export async function getPersona(slug: string) {
  const [row] = await db.select().from(personas).where(eq(personas.slug, slug)).limit(1);
  return row ?? null;
}

export async function listPersonas() {
  return db.select().from(personas);
}

/* ------------------------------------------------------------------ */
/* Ollama (local model, optional)                                      */
/* ------------------------------------------------------------------ */

export async function ollamaAvailable(): Promise<boolean> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 900);
    const res = await fetch(`${OLLAMA_URL}/api/tags`, { signal: controller.signal });
    clearTimeout(timer);
    return res.ok;
  } catch {
    return false;
  }
}

async function ollamaGenerate(system: string, prompt: string): Promise<string | null> {
  try {
    const res = await fetch(`${OLLAMA_URL}/api/generate`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        system,
        prompt,
        stream: false,
        options: { temperature: 0.2, num_ctx: 4096 },
      }),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { response?: string };
    return json.response?.trim() ?? null;
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Prompt construction — the RAG context block                         */
/* ------------------------------------------------------------------ */

function contextBlock(citations: Citation[], tableRows: RetrievedCorrespondence[]): string {
  if (citations.length === 0 && tableRows.length === 0) {
    return "NO RETRIEVED MATERIAL. The archive returned nothing relevant. Say so plainly and do not speculate.";
  }
  const passages = citations
    .map(
      (c, i) =>
        `[${i + 1}] DOCUMENT: ${c.document} (${c.slug})\n    LOCATOR: ${c.locator}\n    AUTHOR/ATTRIBUTION: ${c.author}\n    DATE: ${c.date}\n    TRADITION: ${c.tradition}\n    INTEGRITY LABEL: ${c.label}\n    PASSAGE: ${c.snippet}`,
    )
    .join("\n\n");
  const table = tableRows.length
    ? `\n\nCORRESPONDENCE TABLES (attribute → value, with the source that prints it):\n${tableRows
      .map((r) => `    ${r.key} · ${r.attribute} = ${r.value}  [${r.sourceRef}] (${r.label})`)
      .join("\n")}`
    : "";
  return passages + table;
}

const GUARDRAILS = `RULES OF THE ARCHIVE (non-negotiable):
- Answer only from the numbered passages supplied. Cite them inline as [1], [2].
- Never invent a manuscript, author, date, shelfmark or quotation.
- Keep the distinctions: PRIMARY SOURCE, SECONDARY SOURCE, SCHOLARLY INTERPRETATION, MODERN OCCULT INTERPRETATION, FICTIONAL, UNCERTAIN.
- If a claim rests on later occult literature rather than early sources, say so explicitly.
- End with a line of the form: CONFIDENCE: HIGH|MEDIUM|LOW — and one sentence justifying it.
- If the retrieved material does not answer the question, say exactly that and suggest what to search for.`;

/* ------------------------------------------------------------------ */
/* The Oracle: retrieve → context → local model → answer + sources     */
/* ------------------------------------------------------------------ */

export async function ask(
  question: string,
  personaSlug: string,
  options: { tradition?: string } = {},
): Promise<AskResult> {
  const persona = (await getPersona(personaSlug)) ?? (await getPersona("archivist"));
  const [citations, tableRows] = await Promise.all([
    retrievePassages(question, { limit: 6, tradition: options.tradition }),
    retrieveCorrespondences(question, 10),
  ]);
  const confidence = deriveConfidence(citations);

  const prompt = `${GUARDRAILS}

QUESTION: ${question}

RETRIEVED FROM THE ARCHIVE:
${contextBlock(citations, tableRows)}

Answer as ${persona?.name ?? "The Archivist"} (${persona?.focus ?? "historical documentation"}).`;

  const generated = await ollamaGenerate(persona?.systemPrompt ?? "", prompt);
  if (generated) {
    return {
      question,
      persona: persona?.slug ?? "archivist",
      personaName: persona?.name ?? "The Archivist",
      answer: generated,
      engine: "ollama",
      model: OLLAMA_MODEL,
      confidence,
      citations,
      correspondences: tableRows,
    };
  }

  return {
    question,
    persona: persona?.slug ?? "archivist",
    personaName: persona?.name ?? "The Archivist",
    answer: composeExtractiveAnswer(
      question,
      persona?.name ?? "The Archivist",
      persona?.focus ?? "",
      citations,
      tableRows,
    ),
    engine: "retrieval-only",
    model: null,
    confidence,
    citations,
    correspondences: tableRows,
  };
}

/**
 * Deterministic, offline answer composer. When no local model is reachable the
 * guide must still answer honestly: it reports only what the retrieval engine
 * actually found, quotes the strongest fragments, and lists its sources.
 */
export function composeExtractiveAnswer(
  question: string,
  personaName: string,
  focus: string,
  citations: ScoredCitation[],
  tableRows: RetrievedCorrespondence[] = [],
): string {
  if (citations.length === 0) {
    return `No material in this archive matches that question.

The retrieval engine returned zero passages, so I will not guess. Try a broader term (a tradition, a proper name, a symbol), or browse the Library to see what the archive actually holds.

CONFIDENCE: LOW — no retrieved evidence.`;
  }

  const fragments = extractiveSummary(citations, question);
  const lines: string[] = [];
  lines.push(
    `${personaName} answering from retrieval only — no local language model is reachable, so this is a direct report of what the archive holds, not a synthesis.`,
  );
  lines.push("");
  lines.push(`WHAT THE ARCHIVE RETURNS (${focus}):`);
  if (fragments.length > 0) {
    fragments.forEach((fragment, index) => {
      lines.push(`- ${fragment} [${citations[Math.min(index, citations.length - 1)].slug}]`);
    });
  } else {
    citations.slice(0, 3).forEach((c) => {
      lines.push(`- ${c.document}, ${c.locator} — ${c.snippet.slice(0, 180)}… [${c.slug}]`);
    });
  }
  lines.push("");
  lines.push("SOURCES USED:");
  citations.forEach((c, i) => {
    lines.push(
      `[${i + 1}] ${c.document} — ${c.locator} — ${c.author} — ${c.date} — ${c.tradition} — ${c.label}`,
    );
  });
  if (tableRows.length > 0) {
    lines.push("");
    lines.push("CORRESPONDENCE ROWS MATCHED:");
    tableRows.forEach((row) => {
      lines.push(`- ${row.key} · ${row.attribute} = ${row.value}  [${row.sourceRef}] (${row.label})`);
    });
  }
  const primaries = citations.filter((c) => c.label === "PRIMARY SOURCE").length;
  lines.push("");
  lines.push(
    `CONFIDENCE: ${deriveConfidence(citations)} — ${primaries} of ${citations.length} retrieved passages are labelled PRIMARY SOURCE; the rest are ${citations
      .filter((c) => c.label !== "PRIMARY SOURCE")
      .map((c) => c.label)
      .join(", ") || "none"}. Start a local Ollama model (OLLAMA_URL=${OLLAMA_URL}) to have these same sources synthesised into prose.`,
  );
  return lines.join("\n");
}
