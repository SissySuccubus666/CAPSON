import { eq } from "drizzle-orm";

import { db } from "@/db";
import { correspondences, documents, passages, traditions } from "@/db/schema";
import type { Citation } from "@/db/schema";
import type { IntegrityLabel } from "@/db/schema";

const STOPWORDS = new Set([
  "the", "a", "an", "of", "and", "or", "to", "in", "is", "are", "was", "were", "what",
  "which", "who", "whom", "how", "why", "when", "where", "does", "did", "do", "for",
  "on", "by", "with", "that", "this", "it", "its", "from", "as", "at", "be", "been",
  "there", "their", "about", "into", "between", "can", "could", "would", "should",
  "tell", "explain", "give", "me", "please", "sources", "source", "any", "some",
]);

export function tokenize(input: string): string[] {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\u00c0-\u024f\u0370-\u03ff\u0590-\u05ff\u0600-\u06ff\s-]/g, " ")
    .split(/[\s-]+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 1 && !STOPWORDS.has(t));
}

type PassageRow = {
  passageId: number;
  ordinal: number;
  locator: string;
  heading: string;
  text: string;
  label: string;
  keywords: string[] | null;
  docTitle: string;
  docSlug: string;
  author: string | null;
  dateCreated: string;
  docType: string;
  tradition: string | null;
};

export type ScoredCitation = Citation & { score: number };

async function loadPassageRows(): Promise<PassageRow[]> {
  const rows = await db
    .select({
      passageId: passages.id,
      ordinal: passages.ordinal,
      locator: passages.locator,
      heading: passages.heading,
      text: passages.text,
      label: passages.label,
      keywords: passages.keywords,
      docTitle: documents.title,
      docSlug: documents.slug,
      author: documents.attribution,
      dateCreated: documents.dateCreated,
      docType: documents.docType,
      tradition: traditions.name,
    })
    .from(passages)
    .innerJoin(documents, eq(passages.documentId, documents.id))
    .leftJoin(traditions, eq(documents.traditionId, traditions.id));
  return rows;
}

/**
 * Retrieval: a transparent BM25-flavoured lexical ranker over the corpus.
 * Runs entirely offline against the local database — no network, no embeddings
 * service required. Every result keeps its document metadata so citations are
 * always traceable.
 */
export async function retrievePassages(
  query: string,
  options: { limit?: number; tradition?: string; label?: string } = {},
): Promise<ScoredCitation[]> {
  const limit = options.limit ?? 6;
  const rows = await loadPassageRows();
  const terms = tokenize(query);
  if (terms.length === 0) return [];

  const docFreq = new Map<string, number>();
  const tokensPerRow: { row: PassageRow; tokens: string[]; tf: Map<string, number> }[] = [];

  for (const row of rows) {
    if (options.tradition && row.tradition !== options.tradition) continue;
    if (options.label && row.label !== options.label) continue;
    // The index covers the passage body, its heading, the parent document's title
    // and attribution, and the tradition it belongs to — so a question naming a
    // tradition ("Hermeticism", "alchemy") reaches the documents of that tradition
    // even when the word itself never occurs in a surviving passage.
    const tokens = [
      ...tokenize(row.text),
      ...tokenize(row.heading),
      ...tokenize(row.docTitle),
      ...tokenize(row.tradition ?? ""),
      ...tokenize(row.docType ?? ""),
      ...tokenize(row.author ?? ""),
      ...(row.keywords ?? []),
    ];
    const tf = new Map<string, number>();
    for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);
    for (const t of new Set(tokens)) docFreq.set(t, (docFreq.get(t) ?? 0) + 1);
    tokensPerRow.push({ row, tokens, tf });
  }

  const N = Math.max(tokensPerRow.length, 1);
  const avgLen =
    tokensPerRow.reduce((acc, r) => acc + r.tokens.length, 0) / N || 1;
  const k1 = 1.4;
  const b = 0.72;
  const lower = query.toLowerCase();
  const stem = (t: string) => (t.length > 5 ? t.replace(/(ing|ed|es|s)$/u, "") : t);

  const scored = tokensPerRow.map(({ row, tokens, tf }) => {
    let score = 0;
    for (const term of terms) {
      const df = docFreq.get(term) ?? docFreq.get(stem(term)) ?? 0;
      if (df === 0) continue;
      const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
      const f = tf.get(term) ?? tf.get(stem(term)) ?? 0;
      if (f === 0) continue;
      score += idf * ((f * (k1 + 1)) / (f + k1 * (1 - b + b * (tokens.length / avgLen))));
    }
    // phrase and title boosts
    if (row.heading.toLowerCase().includes(lower)) score *= 1.35;
    if (row.docTitle.toLowerCase().includes(lower)) score *= 1.2;
    if ((row.keywords ?? []).some((k) => lower.includes(k.toLowerCase()))) score *= 1.25;
    if (row.label === "PRIMARY SOURCE") score *= 1.04;
    return {
      document: row.docTitle,
      slug: row.docSlug,
      locator: row.locator || `passage ${row.ordinal}`,
      author: row.author ?? "anonymous",
      date: row.dateCreated,
      tradition: row.tradition ?? "unassigned",
      label: row.label,
      snippet: row.text.slice(0, 460),
      score: Math.round(score * 100) / 100,
    } satisfies ScoredCitation;
  });

  return scored
    .filter((c) => c.score > 0)
    .sort((a, b2) => b2.score - a.score)
    .slice(0, limit);
}

/* ------------------------------------------------------------------ */
/* Correspondence table retrieval                                      */
/* ------------------------------------------------------------------ */

export type RetrievedCorrespondence = {
  domain: string;
  key: string;
  attribute: string;
  value: string;
  sourceRef: string;
  label: string;
  score: number;
};

/**
 * The Symbolist works from tables, not prose. This matches the query against the
 * correspondence rows themselves — domain, key, attribute, value and source — so
 * "what are the correspondences of Saturn" returns Agrippa's actual row set.
 */
export async function retrieveCorrespondences(
  query: string,
  limit = 10,
): Promise<RetrievedCorrespondence[]> {
  const terms = tokenize(query);
  if (terms.length === 0) return [];
  const rows = await db.select().from(correspondences);
  const lower = query.toLowerCase();

  return rows
    .map((row) => {
      const haystack = `${row.domain} ${row.key} ${row.attribute} ${row.value} ${row.sourceRef} ${row.tradition ?? ""}`.toLowerCase();
      let score = 0;
      for (const term of terms) {
        const stem = term.length > 5 ? term.replace(/(ing|ed|es|s)$/u, "") : term;
        if (haystack.includes(term)) score += 2;
        else if (haystack.includes(stem)) score += 1.4;
      }
      if (haystack.includes(lower)) score += 2;
      if (row.label === "PRIMARY SOURCE") score *= 1.05;
      return {
        domain: row.domain,
        key: row.key,
        attribute: row.attribute,
        value: row.value,
        sourceRef: row.sourceRef,
        label: row.label,
        score: Math.round(score * 100) / 100,
      };
    })
    .filter((row) => row.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/** Best sentence-level fragments for an answer, keyed to their citation. */
export function extractiveSummary(citations: ScoredCitation[], query: string): string[] {
  const terms = new Set(tokenize(query).map((t) => t.replace(/(ing|ed|es|s)$/u, "")));
  const picked: string[] = [];
  for (const citation of citations) {
    const sentences = citation.snippet.split(/(?<=[.;])\s+/);
    const best = sentences
      .map((sentence) => {
        const tokens = tokenize(sentence).map((t) => t.replace(/(ing|ed|es|s)$/u, ""));
        const hits = tokens.filter((t) => terms.has(t)).length;
        return { sentence: sentence.trim(), hits };
      })
      .filter((s) => s.hits > 0)
      .sort((a, b2) => b2.hits - a.hits)[0];
    if (best && best.sentence.length > 30) {
      picked.push(best.sentence.replace(/\s+/u, " "));
    }
    if (picked.length >= 4) break;
  }
  return picked;
}

export function deriveConfidence(
  citations: ScoredCitation[],
  labels: IntegrityLabel[] = [],
): "HIGH" | "MEDIUM" | "LOW" {
  if (citations.length === 0) return "LOW";
  const primaries = citations.filter((c) => c.label === "PRIMARY SOURCE").length;
  const top = citations[0].score;
  if (primaries >= 2 && top > 2) return "HIGH";
  if (primaries >= 1 || top > 1) return "MEDIUM";
  return "LOW";
}
