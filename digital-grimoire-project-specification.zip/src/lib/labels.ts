export type LabelSpec = {
  key: string;
  short: string;
  className: string;
  description: string;
};

export const LABELS: Record<string, LabelSpec> = {
  "PRIMARY SOURCE": {
    key: "PRIMARY SOURCE",
    short: "PRIMARY",
    className: "border-emerald-500/40 bg-emerald-500/10 text-emerald-200",
    description: "Attested in the earliest available source material for this item.",
  },
  "SECONDARY SOURCE": {
    key: "SECONDARY SOURCE",
    short: "SECONDARY",
    className: "border-sky-500/40 bg-sky-500/10 text-sky-200",
    description: "Later compilation, edition or translation of earlier material.",
  },
  "SCHOLARLY INTERPRETATION": {
    key: "SCHOLARLY INTERPRETATION",
    short: "SCHOLARLY",
    className: "border-violet-500/40 bg-violet-500/10 text-violet-200",
    description: "Modern academic reading, argued from evidence rather than attested directly.",
  },
  "MODERN OCCULT INTERPRETATION": {
    key: "MODERN OCCULT INTERPRETATION",
    short: "MODERN OCCULT",
    className: "border-amber-500/40 bg-amber-500/10 text-amber-200",
    description: "Nineteenth-century or later occult re-reading of older material.",
  },
  "USER CREATED": {
    key: "USER CREATED",
    short: "USER",
    className: "border-teal-500/40 bg-teal-500/10 text-teal-200",
    description: "Created in this archive by the user; carries no historical authority.",
  },
  FICTIONAL: {
    key: "FICTIONAL",
    short: "FICTIONAL",
    className: "border-fuchsia-500/40 bg-fuchsia-500/10 text-fuchsia-200",
    description: "A framing narrative or legendary device, not a historical claim.",
  },
  UNCERTAIN: {
    key: "UNCERTAIN",
    short: "UNCERTAIN",
    className: "border-rose-500/40 bg-rose-500/10 text-rose-200",
    description: "Evidence is thin, contested or absent. Treat with suspicion.",
  },
};

export function labelSpec(label: string): LabelSpec {
  return LABELS[label] ?? LABELS.UNCERTAIN;
}

export const CONFIDENCE_CLASS: Record<string, string> = {
  HIGH: "text-emerald-300 border-emerald-500/40 bg-emerald-500/10",
  MEDIUM: "text-amber-300 border-amber-500/40 bg-amber-500/10",
  LOW: "text-rose-300 border-rose-500/40 bg-rose-500/10",
};

export const CONFIDENCE_NOTE: Record<string, string> = {
  HIGH: "Well attested in primary material held in this archive.",
  MEDIUM: "Attested, but the connection depends on later compilation or interpretation.",
  LOW: "This attribution appears primarily in later occult literature and is not clearly established in the earliest available sources.",
};
