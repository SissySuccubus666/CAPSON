import { sql } from "drizzle-orm";

import { db } from "./index";
import {
  authors,
  correspondences,
  documents,
  entities,
  meta,
  passages,
  personas,
  relations,
  sources,
  symbols,
  timelineEvents,
  traditions,
} from "./schema";
import { authorSeeds, documentSeeds, sourceSeeds, traditionSeeds } from "./seed-corpus";
import {
  correspondenceSeeds,
  entitySeeds,
  personaSeeds,
  relationSeeds,
  symbolSeeds,
  timelineSeeds,
} from "./seed-lore";

const SEED_VERSION = "grimoire-corpus-1";

async function alreadySeeded(): Promise<boolean> {
  try {
    const rows = await db.execute<{ value: string }>(
      sql`select value from meta where key = 'seed_version' limit 1`,
    );
    return rows.rows[0]?.value === SEED_VERSION;
  } catch {
    return false;
  }
}

async function runSeed(): Promise<void> {
  // Serialise concurrent seeding attempts across server instances.
  await db.execute(sql`select pg_advisory_lock(918273645)`);
  try {
    if (await alreadySeeded()) return;

    const traditionIds = new Map<string, number>();
    for (const t of traditionSeeds) {
      const [row] = await db
        .insert(traditions)
        .values(t)
        .onConflictDoUpdate({ target: traditions.slug, set: { summary: t.summary } })
        .returning({ id: traditions.id });
      traditionIds.set(t.slug, row.id);
    }

    const authorIds = new Map<string, number>();
    for (const a of authorSeeds) {
      const [row] = await db
        .insert(authors)
        .values(a)
        .onConflictDoUpdate({ target: authors.slug, set: { note: a.note } })
        .returning({ id: authors.id });
      authorIds.set(a.slug, row.id);
    }

    const sourceIds = new Map<string, number>();
    for (const s of sourceSeeds) {
      const [row] = await db
        .insert(sources)
        .values(s)
        .onConflictDoUpdate({ target: sources.slug, set: { note: s.note } })
        .returning({ id: sources.id });
      sourceIds.set(s.slug, row.id);
    }

    for (const d of documentSeeds) {
      const [docRow] = await db
        .insert(documents)
        .values({
          slug: d.slug,
          title: d.title,
          originalTitle: d.originalTitle ?? null,
          authorId: d.authorSlug ? (authorIds.get(d.authorSlug) ?? null) : null,
          attribution: d.attribution,
          dateCreated: d.dateCreated,
          yearStart: d.yearStart,
          yearEnd: d.yearEnd,
          region: d.region,
          language: d.language,
          traditionId: d.traditionSlug ? (traditionIds.get(d.traditionSlug) ?? null) : null,
          translator: d.translator ?? null,
          edition: d.edition ?? null,
          sourceId: d.sourceSlug ? (sourceIds.get(d.sourceSlug) ?? null) : null,
          copyrightStatus: d.copyrightStatus ?? "Public domain",
          docType: d.docType,
          historicalPeriod: d.historicalPeriod,
          summary: d.summary,
          label: d.label,
        })
        .onConflictDoUpdate({
          target: documents.slug,
          set: { summary: d.summary, title: d.title },
        })
        .returning({ id: documents.id });

      await db.delete(passages).where(sql`${passages.documentId} = ${docRow.id}`);
      if (d.passages.length > 0) {
        await db.insert(passages).values(
          d.passages.map((p, index) => ({
            documentId: docRow.id,
            ordinal: index + 1,
            locator: p.locator,
            heading: p.heading,
            text: p.text,
            label: p.label,
            keywords: p.keywords,
          })),
        );
      }
    }

    for (const e of entitySeeds) {
      await db
        .insert(entities)
        .values({
          slug: e.slug,
          name: e.name,
          kind: e.kind,
          alternateNames: e.alternateNames,
          traditionId: e.traditionSlug ? (traditionIds.get(e.traditionSlug) ?? null) : null,
          historicalPeriod: e.historicalPeriod,
          primarySources: e.primarySources,
          secondarySources: e.secondarySources,
          symbolism: e.symbolism,
          associatedSymbols: e.associatedSymbols,
          associatedPlanets: e.associatedPlanets,
          associatedElements: e.associatedElements,
          associatedNumbers: e.associatedNumbers,
          historicalInterpretation: e.historicalInterpretation,
          laterInterpretation: e.laterInterpretation,
          modernInterpretation: e.modernInterpretation,
          references: e.references,
          confidence: e.confidence,
          label: e.label,
        })
        .onConflictDoUpdate({
          target: entities.slug,
          set: { historicalInterpretation: e.historicalInterpretation },
        });
    }

    for (const s of symbolSeeds) {
      await db
        .insert(symbols)
        .values({
          slug: s.slug,
          name: s.name,
          glyph: s.glyph,
          category: s.category,
          traditionId: s.traditionSlug ? (traditionIds.get(s.traditionSlug) ?? null) : null,
          meaning: s.meaning,
          usage: s.usage,
          firstAttested: s.firstAttested,
          confidence: s.confidence,
          label: s.label,
        })
        .onConflictDoUpdate({ target: symbols.slug, set: { meaning: s.meaning } });
    }

    const existingCorrespondences = await db.select({ id: correspondences.id }).from(correspondences).limit(1);
    if (existingCorrespondences.length === 0) {
      await db.insert(correspondences).values(correspondenceSeeds);
    }

    const existingRelations = await db.select({ id: relations.id }).from(relations).limit(1);
    if (existingRelations.length === 0) {
      await db.insert(relations).values(
        relationSeeds.map((r) => ({
          fromKey: r.fromKey,
          toKey: r.toKey,
          predicate: r.predicate,
          weight: r.weight ?? 1,
          note: r.note ?? "",
          label: r.label ?? "SCHOLARLY INTERPRETATION",
        })),
      );
    }

    const existingTimeline = await db.select({ id: timelineEvents.id }).from(timelineEvents).limit(1);
    if (existingTimeline.length === 0) {
      await db.insert(timelineEvents).values(timelineSeeds);
    }

    for (const p of personaSeeds) {
      await db
        .insert(personas)
        .values(p)
        .onConflictDoUpdate({ target: personas.slug, set: { systemPrompt: p.systemPrompt } });
    }

    await db
      .insert(meta)
      .values({ key: "seed_version", value: SEED_VERSION })
      .onConflictDoUpdate({ target: meta.key, set: { value: SEED_VERSION, updatedAt: new Date() } });
  } finally {
    await db.execute(sql`select pg_advisory_unlock(918273645)`);
  }
}

let seedPromise: Promise<void> | null = null;

/** Lazily ensure the corpus exists. Safe to call on every request. */
export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
