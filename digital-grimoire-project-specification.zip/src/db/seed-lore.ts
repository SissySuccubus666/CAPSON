import type { IntegrityLabel } from "./schema";

export type EntitySeed = {
  slug: string;
  name: string;
  kind: string;
  alternateNames: string[];
  traditionSlug?: string;
  historicalPeriod: string;
  primarySources: string;
  secondarySources: string;
  symbolism: string;
  associatedSymbols: string[];
  associatedPlanets: string[];
  associatedElements: string[];
  associatedNumbers: number[];
  historicalInterpretation: string;
  laterInterpretation: string;
  modernInterpretation: string;
  references: string;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  label: IntegrityLabel;
};

export const entitySeeds: EntitySeed[] = [
  {
    slug: "hermes-trismegistus",
    name: "Hermes Trismegistus",
    kind: "figure",
    alternateNames: ["Thoth", "Mercurius Maximus", "Hermes the Thrice-Greatest", "Trismegistos"],
    traditionSlug: "hermeticism",
    historicalPeriod: "Legendary; Hellenistic Egypt (c. 300 BCE – 300 CE)",
    primarySources:
      "Corpus Hermeticum (Greek, c. 100–300 CE); Asclepius (Latin); Stobaeus' excerpts; Nag Hammadi Hermetic codices.",
    secondarySources:
      "Ficino's 1463 Latin translation and commentary; Casaubon's 1614 chronology demonstrating post-Christian dating.",
    symbolism:
      "The union of Greek Hermes (messenger, interpreter, patron of interpretation) with Egyptian Thoth (writing, measure, sacred speech). The 'thrice-greatest' title signals mastery of the three parts of philosophy: alchemy, astrology and theurgy.",
    associatedSymbols: ["caduceus", "emerald-tablet", "ouroboros"],
    associatedPlanets: ["Mercury"],
    associatedElements: ["Air", "Aether"],
    associatedNumbers: [3],
    historicalInterpretation:
      "Not a historical individual. The Corpus Hermeticum is a pseudepigraphic compilation by several anonymous Hellenistic Egyptian authors writing in Greek, drawing on Platonic, Stoic and Jewish material. Isaac Casaubon's chronological demonstration of 1614 ended the pretence of extreme antiquity.",
    laterInterpretation:
      "Renaissance readers including Ficino, Pico and Agrippa took Hermes as a gentile prophet contemporary with Moses, which legitimated the entire project of Christian Hermetic magic. This chronology is false but historically productive.",
    modernInterpretation:
      "Modern occultism (Theosophy, the Kybalion, 20th-century hermetic orders) frequently restates the pre-Casaubon view of Hermes as an ancient adept. This is a modern myth of origin, not a scholarly conclusion.",
    references: "Copenhaver 1992; Fowden, The Egyptian Hermes (1986); Yates, Giordano Bruno (1964).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "solomon",
    name: "King Solomon",
    kind: "figure",
    alternateNames: ["Salomon", "Sulayman", "Son of David"],
    traditionSlug: "solomonic-magic",
    historicalPeriod: "Attributed 10th c. BCE; grimoire literature c. 1100–1700 CE",
    primarySources:
      "1 Kings, 2 Chronicles, Wisdom of Solomon; the Testament of Solomon (Greek, c. 1st–4th c. CE); Hygromanteia; Clavicula Salomonis.",
    secondarySources: "McCown's critical edition of the Testament of Solomon; Butler, Ritual Magic (1949).",
    symbolism:
      "The archetype of the magician-king who commands spirits by divine warrant rather than by personal power; his ring, his seal, and his authority over the djinn in Islamic tradition.",
    associatedSymbols: ["seal-of-solomon", "magic-circle", "brass-vessel"],
    associatedPlanets: ["Sol", "Jupiter"],
    associatedElements: [],
    associatedNumbers: [72],
    historicalInterpretation:
      "The biblical Solomon is a royal figure whose wisdom tradition grew in the Second Temple period. The Testament of Solomon, the earliest text to make him a spirit-binder, is a Christian composition of the first centuries CE.",
    laterInterpretation:
      "Medieval and early modern compilers attached his name to the Clavicula and its descendants purely as an authority device. No Solomonic grimoire predates the 13th–14th century; the ascription is retrospective.",
    modernInterpretation:
      "Modern ceremonial magic treats 'Solomonic' as a technical label for circle-and-triangle spirit work; the historical Solomon is largely irrelevant to that usage.",
    references: "McCown 1922; Klaassen, The Transformations of Magic (2013).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "paimon",
    name: "Paimon",
    kind: "demon",
    alternateNames: ["Paymon", "Paimonia", "King Paimon"],
    traditionSlug: "demonology",
    historicalPeriod: "First catalogued 1563 (Weyer)",
    primarySources:
      "Johann Weyer, Pseudomonarchia Daemonum (1563); Reginald Scot, Discoverie of Witchcraft (1584); Sloane MS 2731 (Goetia).",
    secondarySources: "Waite, Book of Ceremonial Magic (1911); modern annotated Lemegeton editions.",
    symbolism:
      "A crowned king riding a dromedary, preceded by musicians; a spirit of arts, sciences and the binding of others to the operator's will.",
    associatedSymbols: ["sigil", "magic-circle"],
    associatedPlanets: ["Sol", "Lucifer (as lord)"],
    associatedElements: ["Air"],
    associatedNumbers: [9, 200],
    historicalInterpretation:
      "Appears first in Weyer's appendix as one of a list of spirits drawn from an otherwise unrecorded manuscript source. The entry is descriptive: obedience to Lucifer, 200 legions.",
    laterInterpretation:
      "The Goetia expanded the entry with seals and rituals. The name may echo the demon kings of medieval romance and the 'Paimonia' of magical literatures; etymologies proposed from later Arabic or Hebrew sources remain unproven.",
    modernInterpretation:
      "In 20th–21st century practice Paimon is treated as a workable spirit of knowledge; the medieval framing of compelled obedience is often replaced by a contractual or psychological model. This is modern interpretation.",
    references: "Weyer 1563 appendix; Scot 1584 Bk XV; Sloane 2731.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "bael",
    name: "Bael",
    kind: "demon",
    alternateNames: ["Baal", "Buel", "First King"],
    traditionSlug: "demonology",
    historicalPeriod: "Catalogued 1563; name is ancient Semitic",
    primarySources: "Weyer, Pseudomonarchia Daemonum (1563); Goetia, spirit 1.",
    secondarySources: "Comparative studies of Baal in Ugaritic and biblical material.",
    symbolism:
      "Appearing as cat, toad and man, sometimes all at once; grants invisibility; rules 66 legions.",
    associatedSymbols: ["sigil"],
    associatedPlanets: ["Saturn"],
    associatedElements: ["Earth"],
    associatedNumbers: [1, 66],
    historicalInterpretation:
      "The name is borrowed from the ancient Semitic title Ba'al, 'lord', designating deities such as Baal Hadad. The grimoire figure is not the Ugaritic god but a Christian demonisation of the name.",
    laterInterpretation:
      "Goetic and later writers conflated the demon with the biblical 'Baal-zebub'; the equation is a philological confusion produced by Christian polemic.",
    modernInterpretation:
      "Contemporary practice treats Bael almost entirely through the Goetia's description, usually without reference to the Ugaritic background.",
    references: "Weyer 1563; Goetia 1.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "lucifer",
    name: "Lucifer",
    kind: "demon",
    alternateNames: ["Light-Bearer", "Morning Star", "Phosphorus", "Helel ben Shahar"],
    traditionSlug: "demonology",
    historicalPeriod: "Isaiah 14:12 (c. 8th–6th c. BCE); developed 2nd c. BCE – 6th c. CE",
    primarySources: "Isaiah 14:12–15; Life of Adam and Eve; Latin Vulgate rendering; patristic literature.",
    secondarySources: "Studies of Satan's development (Pagels, Forsyth, Kelly).",
    symbolism:
      "The fallen morning star; pride, intellect, rebellion; in later occultism a principle of illumination rather than mere evil.",
    associatedSymbols: ["pentagram-inverted", "morning-star"],
    associatedPlanets: ["Venus"],
    associatedElements: ["Air", "Fire"],
    associatedNumbers: [5],
    historicalInterpretation:
      "In Isaiah the phrase refers to the king of Babylon, probably a mocking use of a royal self-designation. The identification with Satan is a patristic development from the Latin 'lucifer' as a common noun for the morning star.",
    laterInterpretation:
      "Medieval and early modern demonology made Lucifer emperor of hell; grimoires name him as lord over the goetic kings. This is later theological construction.",
    modernInterpretation:
      "Since Lévi and the Luciferian currents of the 19th–20th centuries the figure has been re-read as a Gnostic or Promethean principle. Modern, and explicitly not a reading of Isaiah.",
    references: "Isaiah 14; Pagels, The Origin of Satan (1995).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "asmodeus",
    name: "Asmodeus",
    kind: "demon",
    alternateNames: ["Ashmedai", "Asmoday", "Aeshma"],
    traditionSlug: "demonology",
    historicalPeriod: "Avestan origins; Jewish and Christian texts c. 200 BCE – 500 CE",
    primarySources: "Book of Tobit; Babylonian Talmud (Gittin 68a-b); Testament of Solomon.",
    secondarySources: "Weyer, Pseudomonarchia Daemonum (as Amaymon's associate); Goetia 32.",
    symbolism:
      "Wrath and lust; slayer of seven bridegrooms; builder of the Temple under compulsion; in the Talmud a sophisticated, Torah-studying adversary of Solomon.",
    associatedSymbols: ["magic-circle", "brass-vessel"],
    associatedPlanets: ["Mars", "Venus"],
    associatedElements: ["Fire"],
    associatedNumbers: [3, 7],
    historicalInterpretation:
      "Derived from Avestan Aeshma Daeva, 'wrath'. In Tobit he is a destroyer of marriages; in the Talmudic legends he is a trickster who exposes Solomon's hubris.",
    laterInterpretation:
      "Medieval demonology and the Goetia reduce him to a ranked spirit, Asmoday, teaching arithmetic and geometry — a flattening of the older narrative material.",
    modernInterpretation:
      "Modern practice treats Asmoday as a spirit of desire and geometry; the rich Talmudic irony is generally lost.",
    references: "Tobit 3–8; b. Gittin 68a–b; Testament of Solomon 5.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "lilith",
    name: "Lilith",
    kind: "demon",
    alternateNames: ["Lilit", "Lilitu", "the screech owl", "First Wife of Adam"],
    traditionSlug: "kabbalah",
    historicalPeriod: "Mesopotamian origins (c. 2000 BCE); Jewish texts c. 500–1000 CE",
    primarySources: "Burney Relief (disputed identification); Isaiah 34:14; Babylonian incantation bowls; Alphabet of Ben Sira.",
    secondarySources: "Patai, The Hebrew Goddess; scholarly studies of the incantation bowls.",
    symbolism:
      "Night, sexuality, the unbounded; owls and deserts; the woman who will not submit; in Kabbalah the consort of Samael and the inverse of the Shekhinah.",
    associatedSymbols: ["owl", "burney-relief"],
    associatedPlanets: ["Moon"],
    associatedElements: ["Air", "Night"],
    associatedNumbers: [17],
    historicalInterpretation:
      "The Mesopotamian lilitu are a class of wind or night demons, not an individual. Isaiah 34:14 uses the word as a desert creature. The individualised first-wife narrative first appears in the Alphabet of Ben Sira (c. 8th–10th c.), a satirical work.",
    laterInterpretation:
      "The Zohar and later Kabbalah elaborate Lilith as a demonic queen and the dark counterpart of the divine feminine. This is a medieval development, centuries later than the biblical material.",
    modernInterpretation:
      "Since the 1970s Lilith has been re-read as a feminist icon and in modern witchcraft as an aspect of the dark feminine. Entirely modern, though it consciously reworks the older layers.",
    references: "Isaiah 34:14; Alphabet of Ben Sira; Patai 1967.",
    confidence: "MEDIUM",
    label: "SCHOLARLY INTERPRETATION",
  },
  {
    slug: "thoth",
    name: "Thoth",
    kind: "deity",
    alternateNames: ["Djehuty", "The Lord of Divine Words"],
    traditionSlug: "hermeticism",
    historicalPeriod: "Egyptian, attested from c. 3000 BCE",
    primarySources: "Pyramid Texts; Egyptian Book of the Dead; temple inscriptions at Hermopolis.",
    secondarySources: "Fowden, The Egyptian Hermes; Hornung, Conceptions of God in Ancient Egypt.",
    symbolism:
      "Writing, measure, the reckoning of time, the tongue of Ra, the scribe who records the weighing of the heart; ibis and baboon.",
    associatedSymbols: ["caduceus", "ankh"],
    associatedPlanets: ["Moon", "Mercury"],
    associatedElements: ["Air"],
    associatedNumbers: [8],
    historicalInterpretation:
      "An Egyptian god of writing and measurement whose cult centre at Hermopolis (Khemenu) made him the natural Egyptian partner for the Greek Hermes in the interpretatio graeca of Ptolemaic Egypt.",
    laterInterpretation:
      "Hermopolis' association with Hermes made the city the imagined origin of the Hermetic books; Renaissance readers therefore believed the Corpus came from the oldest Egyptian theology.",
    modernInterpretation:
      "Modern occult and Kemetic revival practice work with Thoth directly, sometimes conflating him with Hermes Trismegistus. That conflation is an interpretive choice, not an identity.",
    references: "Book of the Dead; Fowden 1986.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "hecate",
    name: "Hecate",
    kind: "deity",
    alternateNames: ["Hekate", "Propylaia", "Trivia", "Kourotrophos"],
    traditionSlug: "witchcraft-trials",
    historicalPeriod: "Greek, from c. 600 BCE",
    primarySources: "Hesiod's Theogony (411–452); the Homeric Hymn to Demeter; PGM (Papyri Graecae Magicae); Theocritus' Idyll 2.",
    secondarySources: "Johnston, Restless Dead (1999); modern collections of the PGM.",
    symbolism:
      "Crossroads, thresholds, the moon, dogs, the dead, torches, the triple form; guardian of the liminal and patroness of the pharmakeia.",
    associatedSymbols: ["triple-gate", "torch", "key"],
    associatedPlanets: ["Moon"],
    associatedElements: ["Earth", "Water"],
    associatedNumbers: [3],
    historicalInterpretation:
      "Hesiod gives her an unusually positive treatment as a goddess of universal influence. The chthonic and crossroads associations develop in Classical and Hellenistic times, and the magical papyri use her names constantly.",
    laterInterpretation:
      "Early modern witch-trial literature made her the patroness of witches, largely through classical allusion; Shakespeare's Macbeth fixed the image for the modern imagination.",
    modernInterpretation:
      "A central figure in modern witchcraft and Hellenic reconstruction, often with the later 'triple goddess' framing of Robert Graves, which is a 20th-century literary construction.",
    references: "Theogony 411–52; PGM; Johnston 1999.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "samael",
    name: "Samael",
    kind: "angel",
    alternateNames: ["Sammael", "the venom of God", "Accuser"],
    traditionSlug: "kabbalah",
    historicalPeriod: "Second Temple period onward; central in medieval Kabbalah",
    primarySources: "2 Enoch; Ascension of Isaiah; Berakhot; Zohar.",
    secondarySources: "Studies of the angelology of the Zohar; Scholem's essays.",
    symbolism:
      "The Severity of God, the angel of death, the prince of Rome, consort of Lilith, and the blinded serpent; often the adversary in the judicial sense.",
    associatedSymbols: ["serpent", "sefirah-geburah"],
    associatedPlanets: ["Saturn", "Mars"],
    associatedElements: ["Fire"],
    associatedNumbers: [5],
    historicalInterpretation:
      "In early Jewish texts Samael appears as an accusing or destroying angel, not as the Christian Satan. The Zohar makes him the demon-king of the left side.",
    laterInterpretation:
      "Christian kabbalists identified Samael with Satan or with the guardian of Edom/Rome, reading Jewish political theology as demonology.",
    modernInterpretation:
      "Modern left-hand-path and qlippothic systems work with Samael as a named power of the qlippoth. That schema is a 19th–20th century systematisation.",
    references: "Zohar; Scholem, Major Trends in Jewish Mysticism (1941).",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "metatron",
    name: "Metatron",
    kind: "angel",
    alternateNames: ["Prince of the Countenance", "Lesser YHWH", "Enoch"],
    traditionSlug: "kabbalah",
    historicalPeriod: "c. 200 CE onward; developed in Hekhalot literature",
    primarySources: "3 Enoch; Sefer Hekhalot; Targum Pseudo-Jonathan; Zohar.",
    secondarySources: "Scholem's studies of Jewish Gnosticism and the Hekhalot texts.",
    symbolism:
      "The highest of the angels, the transformed Enoch, the scribe, the measurer, the covenant-keeper of Israel; the archangel of Kether.",
    associatedSymbols: ["sefirah-kether", "cube-of-metatron"],
    associatedPlanets: ["Saturn (in some tables)"],
    associatedElements: ["Aether"],
    associatedNumbers: [1],
    historicalInterpretation:
      "The name is probably a Greek loan (metatron, 'beside the throne' or 'measurer'). 3 Enoch narrates Enoch's assumption into the angel Metatron; this is late-antique Jewish mysticism.",
    laterInterpretation:
      "Kabbalah places him at Kether or, in some systems, at the head of the world of Yetzirah; Christian kabbalists mapped him onto the Logos.",
    modernInterpretation:
      "Modern practice uses Metatron's Cube as a sacred geometry figure — a contemporary construction built on medieval materials.",
    references: "3 Enoch; Scholem, Jewish Gnosticism, Merkabah Mysticism (1960).",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "raziel",
    name: "Raziel",
    kind: "angel",
    alternateNames: ["Ratziel", "Secret of God", "the herald of the divine"],
    traditionSlug: "kabbalah",
    historicalPeriod: "Medieval (Sefer Raziel HaMalakh, c. 13th c.)",
    primarySources: "Sefer Raziel HaMalakh (compilation); Zohar references.",
    secondarySources: "Studies of the Hebrew angelological compendia.",
    symbolism:
      "The angel of the hidden mysteries; the book given to Adam; the transmitter of the secrets of creation.",
    associatedSymbols: ["book", "sefirah-chokmah"],
    associatedPlanets: ["Neptune (modern attribution)"],
    associatedElements: ["Aether"],
    associatedNumbers: [2],
    historicalInterpretation:
      "The Sefer Raziel HaMalakh is a 13th-century compilation of earlier material, presented as the book given to Adam after the expulsion. Its framing narrative is fictitious.",
    laterInterpretation:
      "Printed in Amsterdam in 1701 and circulated as an amulet book among Ashkenazi communities, becoming a folk protective text.",
    modernInterpretation:
      "Invoked in contemporary practice as an angel of secrets; the amulet-book tradition continues in modern Jewish folk practice.",
    references: "Sefer Raziel HaMalakh, Amsterdam 1701.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "lucifuge-rofocale",
    name: "Lucifuge Rofocale",
    kind: "demon",
    alternateNames: ["Lucifugus", "Prime Minister of Hell"],
    traditionSlug: "solomonic-magic",
    historicalPeriod: "First appears 18th century",
    primarySources: "Grand Grimoire / Dragon Rouge chapbooks (18th–19th c.).",
    secondarySources: "Waite, Book of Ceremonial Magic (1911).",
    symbolism:
      "The inverted counterpart of Lucifer — 'he who flees the light'; the spirit of pacts, treasure and compulsion.",
    associatedSymbols: ["pact", "magic-circle"],
    associatedPlanets: ["Saturn"],
    associatedElements: ["Earth"],
    associatedNumbers: [3],
    historicalInterpretation:
      "Not attested in any medieval source. The name appears to be a constructed inversion of Lucifer, manufactured for the chapbook trade.",
    laterInterpretation:
      "Waite treats the Grand Grimoire as the most corrupt strand of the grimoire family, and its spirit as a literary invention dressed in older ritual forms.",
    modernInterpretation:
      "Popular demonology since the 20th century has given the figure wide currency, often with invented sigils and hierarchies; almost all of this is modern.",
    references: "Dragon Rouge chapbooks; Waite 1911.",
    confidence: "LOW",
    label: "UNCERTAIN",
  },
  {
    slug: "aratron",
    name: "Aratron",
    kind: "spirit",
    alternateNames: ["Arathor", "the Olympian spirit of Saturn"],
    traditionSlug: "ceremonial-magic",
    historicalPeriod: "1575 (Arbatel)",
    primarySources: "Arbatel de magia veterum (Basel, 1575), aphorisms 13–21.",
    secondarySources: "Agrippa, De occulta philosophia III (parallels); Waite 1911.",
    symbolism:
      "Governor of Saturn's province: alchemy, agriculture, lead, mineral things, and the melancholic arts.",
    associatedSymbols: ["sigil"],
    associatedPlanets: ["Saturn"],
    associatedElements: ["Earth"],
    associatedNumbers: [7],
    historicalInterpretation:
      "One of seven 'Olympian' spirits listed by the anonymous Arbatel, called by prayer and upright living rather than compulsion; the tone is theurgic and Protestant.",
    laterInterpretation:
      "Later ceremonial magic folded the Olympic spirits into planetary working alongside the Agrippan intelligences and spirits.",
    modernInterpretation:
      "Contemporary planetary magic uses Aratron as the Saturnine contact; the association with melancholy and structure is emphasised psychologically.",
    references: "Arbatel 1575.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "och",
    name: "Och",
    kind: "spirit",
    alternateNames: ["Oick", "the Olympian spirit of the Sun"],
    traditionSlug: "ceremonial-magic",
    historicalPeriod: "1575 (Arbatel)",
    primarySources: "Arbatel de magia veterum.",
    secondarySources: "Agrippa II.10 for the parallel solar intelligences.",
    symbolism:
      "The solar governor: gold, the medicine of gold, illumination of the understanding, longevity of 600 years.",
    associatedSymbols: ["sigil"],
    associatedPlanets: ["Sol"],
    associatedElements: ["Fire"],
    associatedNumbers: [4],
    historicalInterpretation:
      "Arbatel states Och has 145 legions, gives gold and perfect health, and teaches medicine — the classical solar correspondences in spirit form.",
    laterInterpretation:
      "Absorbed into the planetary hierarchies of 19th-century occultism as one route to solar work.",
    modernInterpretation:
      "Used in contemporary solar workings, often blended with the Agrippan intelligence Nakhiel; the blending is modern practice, not the source.",
    references: "Arbatel 1575.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "aiwass",
    name: "Aiwass",
    kind: "spirit",
    alternateNames: ["Aiwaz", "the minister of Hoor-paar-kraat"],
    traditionSlug: "modern-occultism",
    historicalPeriod: "1904",
    primarySources: "Crowley's own account in The Equinox of the Gods; the Cairo diary (1904).",
    secondarySources: "Crowley's commentaries; biographies by Symonds and Kaczynski.",
    symbolism:
      "The praeterhuman intelligible counterpart, the true will, the voice of the æon; Crowley later called it his Holy Guardian Angel.",
    associatedSymbols: ["stele-of-revealing"],
    associatedPlanets: ["Sol", "Sirius (in Crowley's later tables)"],
    associatedElements: ["Fire"],
    associatedNumbers: [93],
    historicalInterpretation:
      "There is no external witness. The claim rests entirely on Crowley's 1904 diary, in which he reports Rose Crowley's identification of the stele of Ankh-af-na-khonsu in the Cairo Museum and three hours of dictation on 8–10 April.",
    laterInterpretation:
      "Crowley progressively elevated Aiwass from a spirit to a logos of the new æon, and identified him with the Thelemic Hoor-paar-kraat.",
    modernInterpretation:
      "In Thelema today Aiwass is scripture-author and the prototype of the Holy Guardian Angel; outside Thelema the figure is generally read as an instance of automatic writing.",
    references: "Equinox of the Gods; Crowley, Confessions.",
    confidence: "LOW",
    label: "MODERN OCCULT INTERPRETATION",
  },
  {
    slug: "baphomet",
    name: "Baphomet",
    kind: "figure",
    alternateNames: ["the Sabbatic Goat", "the Goat of Mendes", "Bafometz"],
    traditionSlug: "modern-occultism",
    historicalPeriod: "Trial records 1307; Lévi's image 1854",
    primarySources: "Templar trial depositions (1307–1312); Lévi, Dogme et Rituel (1854).",
    secondarySources: "Scholarly studies of the Templar trials; analyses of Lévi's iconography.",
    symbolism:
      "Lévi's hermaphroditic figure of equilibrium: solve et coagula, the white and black moons, the caduceus, the torch between the horns — the reconciliation of opposites.",
    associatedSymbols: ["pentagram-inverted", "caduceus"],
    associatedPlanets: ["Venus", "Moon"],
    associatedElements: ["Earth", "Fire"],
    associatedNumbers: [2],
    historicalInterpretation:
      "In the Templar trials 'Baphomet' is a name extracted under torture, of disputed meaning; scholars do not agree that it designates any real object of Templar worship. It is not an ancient deity.",
    laterInterpretation:
      "Lévi invented the image in 1854 as a deliberate emblem of occult equilibrium, retro-projecting it onto the Templars. The winged anthropomorphic goat is therefore a 19th-century artwork.",
    modernInterpretation:
      "Adopted by the Church of Satan (1966) as the Sigil of Baphomet, and by many modern left-hand-path groups; these uses are entirely 20th century.",
    references: "Lévi 1854; Partner, The Murdered Magicians (1981).",
    confidence: "HIGH",
    label: "MODERN OCCULT INTERPRETATION",
  },
  {
    slug: "paracelsus",
    name: "Paracelsus",
    kind: "figure",
    alternateNames: ["Theophrastus von Hohenheim", "Philippus Aureolus Theophrastus Bombastus"],
    traditionSlug: "alchemy",
    historicalPeriod: "1493 – 1541",
    primarySources: "Archidoxis Magicae (attributed); De natura rerum; Astronomia Magna; surgical writings.",
    secondarySources: "Pagel, Paracelsus (1958); modern critical editions of the Zurich corpus.",
    symbolism:
      "The reforming physician: signature doctrine, the archeus, the elementals, spagyric medicine, and the refusal of authority in favour of observation.",
    associatedSymbols: ["ensoulment-of-matter", "alchemical-vessel"],
    associatedPlanets: ["Mercury"],
    associatedElements: ["Fire"],
    associatedNumbers: [3],
    historicalInterpretation:
      "A real historical physician who rejected Galenic medicine, introduced mineral and chemical therapeutics, and wrote in a deliberately idiosyncratic vernacular German.",
    laterInterpretation:
      "The elementals (gnomes, undines, sylphs, salamanders) attributed to him were systematised partly by his followers and partly by Agrippa's circle; the Archidoxis Magica with its seven planetary sigils is probably not his.",
    modernInterpretation:
      "Modern spagyrics and radionics claim descent from him; the continuity is loose and largely a genealogical claim.",
    references: "Pagel 1958; Zurich edition of the works.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "marsilio-ficino",
    name: "Marsilio Ficino",
    kind: "figure",
    alternateNames: ["Marsilius Ficinus"],
    traditionSlug: "hermeticism",
    historicalPeriod: "1433 – 1499",
    primarySources: "Translation of the Corpus Hermeticum (1463, printed 1471); De vita libri tres (1489); Theologia Platonica.",
    secondarySources: "Hankins' studies of Florentine Platonism; Yates, Giordano Bruno.",
    symbolism:
      "The translator who made Hermes speak Latin, and the astrologer-physician of natural magic, solar talismans and the drawing down of planetary influence.",
    associatedSymbols: ["solar-talisman", "lyre-of-apollo"],
    associatedPlanets: ["Sol"],
    associatedElements: ["Air"],
    associatedNumbers: [3],
    historicalInterpretation:
      "A historical individual: head of the Platonic Academy under Cosimo de' Medici. In 1463 Cosimo ordered him to set Plato aside and translate Hermes first, because Hermes was believed to be the more ancient.",
    laterInterpretation:
      "His De vita coelitus comparanda supplied Renaissance magic with its theory of talismanic capture of planetary influence, and was attacked as superstitious by the Church.",
    modernInterpretation:
      "Modern occultism treats Ficino as the origin point of 'planetary magic'; scholarly work stresses that he was a Christian priest arguing for natural, not demonic, magic.",
    references: "Hankins, Plato in the Italian Renaissance (1990).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "john-dee",
    name: "John Dee",
    kind: "figure",
    alternateNames: ["Dr. Dee", "007 (in his own cipher)"],
    traditionSlug: "enochian-magic",
    historicalPeriod: "1527 – 1609",
    primarySources: "Monas Hieroglyphica (1564); Preface to Euclid (1570); Mysteriorum Libri (1582–89); his diaries.",
    secondarySources: "French's biography; Clulee, John Dee's Natural Philosophy (1988).",
    symbolism:
      "The mathematician-magician: the Monas as a composite glyph of the planets and elements, the shewstone, the black obsidian mirror, the angelic conversations.",
    associatedSymbols: ["monas-hieroglyphica", "sigillum-dei-aemeth", "enoskian-tablet"],
    associatedPlanets: ["Mercury", "Luna"],
    associatedElements: ["Aether"],
    associatedNumbers: [7, 49],
    historicalInterpretation:
      "A historical mathematician, navigator and court consultant to Elizabeth I, who from 1582 recorded angelic actions with the scryer Edward Kelley in meticulous diaries.",
    laterInterpretation:
      "His papers were re-edited by Meric Casaubon (1659) and then by the Golden Dawn, who invented much of the ritual scaffolding now called 'Enochian'.",
    modernInterpretation:
      "Contemporary Enochian magic largely follows the Golden Dawn and later Crowley reconstructions rather than Dee's own practice — an important distinction often lost.",
    references: "Clulee 1988; Sloane MSS 3188–3191.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "edward-kelley",
    name: "Edward Kelley",
    kind: "figure",
    alternateNames: ["Edward Talbot", "Edward Kelly"],
    traditionSlug: "enochian-magic",
    historicalPeriod: "1555 – 1597/8",
    primarySources: "Dee's diaries; the alchemical verse of Kelley's own circle;state papers.",
    secondarySources: "Biographical studies in French, John Dee (1972).",
    symbolism:
      "The scryer: crystal visions, the angelic alphabet, and later the alchemical claims of transmutation at Trebona.",
    associatedSymbols: ["shewstone", "enoskian-tablet"],
    associatedPlanets: ["Luna"],
    associatedElements: ["Water"],
    associatedNumbers: [4],
    historicalInterpretation:
      "A historical figure who adopted the name Talbot when he first met Dee, was said to have had his ears cropped for coining, and acted as Dee's scryer from 1582 to 1589.",
    laterInterpretation:
      "His departure from Dee in 1589, the sharing of wives, and his death in prison at Prague gave rise to a large romantic literature of doubtful value.",
    modernInterpretation:
      "Modern practice credits Kelley as the true receiver of the Enochian material; the extent of his own invention remains unresolved.",
    references: "Dee's diaries; French 1972.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "eliphas-levi-figure",
    name: "Éliphas Lévi",
    kind: "figure",
    alternateNames: ["Alphonse-Louis Constant", "l'Abbé Constant"],
    traditionSlug: "modern-occultism",
    historicalPeriod: "1810 – 1875",
    primarySources: "Dogme et rituel de la haute magie (1854–55); Histoire de la magie (1860); La Clef des grands mystères (1861).",
    secondarySources: "McIntosh, Eliphas Lévi and the French Occult Revival (1972).",
    symbolism:
      "The astral light, the will, the Tetragrammaton, the Baphomet of equilibrium, and the binding of Tarot to the twenty-two Hebrew letters.",
    associatedSymbols: ["baphomet-sigil", "tarot", "pentagram"],
    associatedPlanets: ["Mercury"],
    associatedElements: ["Aether"],
    associatedNumbers: [4, 22],
    historicalInterpretation:
      "A defrocked socialist priest, Alphonse-Louis Constant, writing as Éliphas Lévi; his synthesis is 19th-century romantic Catholicism plus disparate earlier sources.",
    laterInterpretation:
      "The Golden Dawn, Papus and Crowley all built on him; the Tarot-Kabbalah correspondence that modern readers take as ancient is essentially his invention.",
    modernInterpretation:
      "His vocabulary (astral light, the Great Arcanum, the Magus) remains the working language of Western occultism.",
    references: "McIntosh 1972.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "grace-murray",
    name: "The Dancing Oracle of Trois-Frères (daimon of the folds)",
    kind: "figure",
    alternateNames: ["the sorcerer of Trois-Frères", "the horned dancing man"],
    traditionSlug: "witchcraft-trials",
    historicalPeriod: "Upper Palaeolithic (c. 13,000 BCE); interpretation 1900s onward",
    primarySources: "The engraved figure in the cave of Les Trois-Frères (recorded by Bégouën, published 1914).",
    secondarySources: "Margaret Murray, The Witch-Cult in Western Europe (1921) — cited as evidence and now rejected.",
    symbolism:
      "A human figure in animal posture with antlers and a tail; long read as a 'sorcerer' or 'horned god'.",
    associatedSymbols: ["horned-figure"],
    associatedPlanets: [],
    associatedElements: [],
    associatedNumbers: [],
    historicalInterpretation:
      "The image is Palaeolithic and undisputed as art. Its meaning is unknown; 'sorcerer' is a modern label applied by the first recorders.",
    laterInterpretation:
      "Margaret Murray used Palaeolithic and medieval horned figures to argue for a continuous pre-Christian fertility cult surviving as witchcraft. This thesis is rejected by modern historians of witchcraft.",
    modernInterpretation:
      "Contemporary witchcraft sometimes repeats Murray's continuity claim as fact. It should be labelled UNCERTAIN at best.",
    references: "Bégouën 1914; Murray 1921; Hutton, The Triumph of the Moon (1999).",
    confidence: "LOW",
    label: "UNCERTAIN",
  },
  {
    slug: "nuit",
    name: "Nuit",
    kind: "deity",
    alternateNames: ["Nut", "the Star Goddess", "Our Lady of the Stars"],
    traditionSlug: "modern-occultism",
    historicalPeriod: "Egyptian goddess from c. 2500 BCE; Thelemic form 1904",
    primarySources: "Liber AL vel Legis I (1904); Egyptian mythological texts (Nut).",
    secondarySources: "Crowley's commentaries; Egyptological studies of Nut.",
    symbolism:
      "Infinite space and the infinite stars, the sky arched over the earth, 'the blue-lidded daughter of Sunset'; in Thelema, the totality of all possibility.",
    associatedSymbols: ["star", "body-of-nuit"],
    associatedPlanets: ["Stars"],
    associatedElements: ["Aether"],
    associatedNumbers: [0],
    historicalInterpretation:
      "Nut is the Egyptian sky-goddess, depicted arched over Geb, swallowing the sun at night and giving birth to it at dawn. The Thelemic Nuit is a re-reading of this figure, not the Egyptian cult itself.",
    laterInterpretation:
      "Crowley's chapter I of Liber AL presents Nuit as the speaker of a new metaphysics of infinite space and love.",
    modernInterpretation:
      "Central to Thelemic devotion; the equation of the Egyptian and Thelemic figures is a modern interpretive act.",
    references: "Liber AL I; Egyptian Book of the Nut.",
    confidence: "MEDIUM",
    label: "MODERN OCCULT INTERPRETATION",
  },
];

export type SymbolSeed = {
  slug: string;
  name: string;
  glyph: string;
  category: string;
  traditionSlug?: string;
  meaning: string;
  usage: string;
  firstAttested: string;
  confidence: "HIGH" | "MEDIUM" | "LOW";
  label: IntegrityLabel;
};

export const symbolSeeds: SymbolSeed[] = [
  {
    slug: "pentagram",
    name: "Pentagram",
    glyph: "✧",
    category: "geometric",
    traditionSlug: "ceremonial-magic",
    meaning:
      "A five-pointed star: the four elements crowned by spirit, or the microcosm of the human body; in Agrippa and the Goetia the sign by which spirits are commanded.",
    usage: "Drawn at the four quarters of the circle; worn as a lamen; the 'pentagram of Solomon' in the Lemegeton.",
    firstAttested: "Babylonian and Pythagorean use; magical use from late antiquity; central to the grimoires from the 13th c.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "pentagram-inverted",
    name: "Inverted Pentagram",
    glyph: "ⴵ",
    category: "geometric",
    traditionSlug: "modern-occultism",
    meaning:
      "Read by Lévi and later by LaVey as spirit subordinated to matter, or as the Sabbatic Goat inscribed in the star.",
    usage: "Sigil of Baphomet (Church of Satan, 1966); earlier, a charge of devil-worship in witch-trial polemic.",
    firstAttested: "As a deliberately adversarial emblem, 19th century (Lévi 1854).",
    confidence: "HIGH",
    label: "MODERN OCCULT INTERPRETATION",
  },
  {
    slug: "seal-of-solomon",
    name: "Seal of Solomon / Hexagram",
    glyph: "✡",
    category: "geometric",
    traditionSlug: "solomonic-magic",
    meaning:
      "The interlaced triangles: fire and water, above and below, the union of opposites; in Jewish use the Magen David from the medieval period.",
    usage: "On the ring of Solomon in the Testament; on talismans in the grimoires; later the central figure of the Tree of Life in Golden Dawn ritual.",
    firstAttested: "Islamic and Jewish sources from about the 6th–11th c.; 'Shield of David' as a Jewish emblem from medieval Prague.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "magic-circle",
    name: "The Magic Circle",
    glyph: "◎",
    category: "ritual",
    traditionSlug: "ceremonial-magic",
    meaning:
      "The boundary between the operator's consecrated will and the spirits; a defended space defined by divine names rather than by geometry.",
    usage: "Drawn with the consecrated knife or sword on the day and hour of Mercury; inscribed with the names AGLA, TETRAGRAMMATON, and the four archangels.",
    firstAttested: "Byzantine Hygromanteia and medieval Clavicula manuscripts, 13th c. onward.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "triangle-of-art",
    name: "Triangle of the Art",
    glyph: "△",
    category: "ritual",
    traditionSlug: "solomonic-magic",
    meaning:
      "The place of manifestation placed without the circle, usually to the north-east, where the spirit is constrained to appear.",
    usage: "In the Goetia, a triangle of two feet across with the name Michael inscribed, set at a distance from the circle.",
    firstAttested: "Goetia / Sloane MSS, 17th century; conceptual antecedents in earlier Solomonic material.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "sigil",
    name: "Sigil",
    glyph: "⌘",
    category: "sigil",
    traditionSlug: "ceremonial-magic",
    meaning:
      "A compressed signature of a spirit or intention; in the grimoires a seal matching the spirit's name, in modern practice a letter-wheel made from a statement of will.",
    usage: "Seals of the 72 goetic spirits; the Sigillum Dei Aemeth; the Austin Osman Spare method of sigillising desire.",
    firstAttested: "Late-antique magical gems and papyri; systematised in medieval manuscripts; the modern method from Spare (1913) onward.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "sigillum-dei-aemeth",
    name: "Sigillum Dei Aemeth",
    glyph: "✺",
    category: "sigil",
    traditionSlug: "enochian-magic",
    meaning:
      "The 'Seal of the Truth of God': a heptagram and hexagram construction with the names of God and of the angels of the seven planets arranged in rings.",
    usage: "Made in wax, placed beneath the legs of the holy table and the pedestal of the crystal, as the principal defence of Dee and Kelley's actions.",
    firstAttested: "Recorded in Dee's Mysteriorum Libri, 1582; older textual relatives exist in the 13th-century Liber iuratus.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "monas-hieroglyphica",
    name: "Monas Hieroglyphica",
    glyph: "☉",
    category: "sigil",
    traditionSlug: "enochian-magic",
    meaning:
      "Dee's composite glyph: the signs of the seven planets fused into one sign, by which he claimed to demonstrate the unity of the celestial and elemental orders.",
    usage: "The subject of Dee's 1564 theorem-book, written in twenty-four theorems addressed to Maximilian II.",
    firstAttested: "Antwerp, 1564.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "caduceus",
    name: "Caduceus",
    glyph: "⚕",
    category: "emblem",
    traditionSlug: "hermeticism",
    meaning:
      "The wand of Hermes twined by two serpents: the union of opposites, the mercurial mediator, and in alchemy the androgynous Mercurius.",
    usage: "Emblem of Hermes/Mercury; in Lévi's Baphomet as the generative principle; adopted as a medical emblem by confusion with the rod of Asclepius.",
    firstAttested: "Mesopotamian and Greek antiquity (the staff of Hermes).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "ouroboros",
    name: "Ouroboros",
    glyph: " θ",
    category: "emblem",
    traditionSlug: "alchemy",
    meaning:
      "The serpent devouring its tail: eternity, the self-consuming unity of matter, the circular process of the opus.",
    usage: "In alchemical emblem books; on the Chrysopoeia of Cleopatra; as the closing figure of Atalanta Fugiens.",
    firstAttested: "Egyptian and Greek, from c. 10th century BCE in Egypt; the famous inscription in the Chrysopoeia (c. 2nd–3rd c. CE).",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "philosophers-stone",
    name: "The Philosopher's Stone",
    glyph: "🜍",
    category: "alchemical",
    traditionSlug: "alchemy",
    meaning:
      "The lapis philosophorum: the perfected substance that transmutes base metal into gold and cures the human microcosm; read literally, medically, and spiritually in different centuries.",
    usage: "The terminus of the alchemical sequence nigredo → albedo → citrinitas → rubedo.",
    firstAttested: "Arabic alchemical literature from the 8th–9th c. (Zosimos' earlier 'philosophers' stone' passages).",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "tria-prima",
    name: "Tria Prima (Salt, Sulphur, Mercury)",
    glyph: "🜔🜍☿",
    category: "alchemical",
    traditionSlug: "alchemy",
    meaning:
      "Paracelsus' three principles: the body (salt), the soul (sulphur) and the spirit (mercury) present in all things.",
    usage: "Basis of spagyric separation and recombination; applied to medicine as well as to metals.",
    firstAttested: "Paracelsian corpus, 16th century, refining earlier Arabic sulphur-mercury theory.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "prima-materia",
    name: "Prima Materia",
    glyph: "🜛",
    category: "alchemical",
    traditionSlug: "alchemy",
    meaning:
      "The first matter of the work, deliberately named by hundreds of disguises — lead, dew, dragon, filth, the One Thing of the Emerald Tablet.",
    usage: "Sought, not made; the starting point of the opus, understood by the reader as identical with the undifferentiated self.",
    firstAttested: "Greek and Arabic alchemy; catalogued in the Latin disguises of the 14th–17th c.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "emerald-tablet",
    name: "The Emerald Tablet",
    glyph: "▬",
    category: "textual",
    traditionSlug: "hermeticism",
    meaning:
      "The twelve-sentence epitome of correspondence and the One Thing; the most cited text in Western esotericism.",
    usage: "Quoted by alchemists from the 12th c. Latin translation onward, and read as the key to both laboratory and contemplative work.",
    firstAttested: "Arabic Sirr al-khalīqa recensions, c. 8th–9th c.; Latin from the 12th c.",
    confidence: "HIGH",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "tree-of-life",
    name: "The Tree of Life (Etz Chaim)",
    glyph: "ⵣ",
    category: "diagram",
    traditionSlug: "kabbalah",
    meaning:
      "The diagram of ten Sefirot and twenty-two paths, mapping the emanation of the divine into creation and the return path of the soul.",
    usage: "Meditative ascent in Kabbalah; in the Golden Dawn as the coordinate system of ritual, pathworking and grade structure.",
    firstAttested: "Cordovero's Pardes Rimonim and Luria's Etz Chaim (16th c.); the diagram form is medieval, the earlier texts list without drawing.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "sefirah-geburah",
    name: "Geburah (Severity)",
    glyph: "₅",
    category: "diagram",
    traditionSlug: "kabbalah",
    meaning:
      "The fifth Sefirah: judgement, limitation, the left hand, the fear of God; associated with Mars, iron and the divine name Elohim Gibor.",
    usage: "In ritual, the sphere of trial and cutting away; in the Zohar, the source of rigorous judgement balanced by Chesed.",
    firstAttested: "Sefer Yetzirah's ten Sefirot; the named scheme from Bahir and Zohar.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "cube-of-metatron",
    name: "Metatron's Cube",
    glyph: "❖",
    category: "geometric",
    traditionSlug: "kabbalah",
    meaning:
      "A figure of thirteen circles from which the five Platonic solids are drawn; named for Metatron in modern sacred-geometry literature.",
    usage: "Contemporary sacred geometry and protection designs.",
    firstAttested: "The geometry derives from the Flower of Life reliefs at Abydos and the Osireion; the name 'Metatron's Cube' is 20th century.",
    confidence: "LOW",
    label: "MODERN OCCULT INTERPRETATION",
  },
  {
    slug: "tarot",
    name: "The Tarot Trumps",
    glyph: "🃏",
    category: "emblem",
    traditionSlug: "modern-occultism",
    meaning:
      "Twenty-two emblematic cards, bound to the twenty-two Hebrew letters and the paths of the Tree of Life by Éliphas Lévi.",
    usage: "Divination, meditation, and the mapping of the soul's ascent — the Golden Dawn's attributions underlie the Rider-Waite and Thoth decks.",
    firstAttested: "Italian card games, 15th century; the esoteric use begins with Court de Gébelin (1781) and Lévi (1854).",
    confidence: "HIGH",
    label: "MODERN OCCULT INTERPRETATION",
  },
  {
    slug: "brass-vessel",
    name: "The Brass Vessel",
    glyph: "⚱",
    category: "ritual",
    traditionSlug: "solomonic-magic",
    meaning:
      "The vessel in which Solomon is said to have imprisoned the seventy-two spirits, cast into the Babylonian lake and broken open by treasure-seekers.",
    usage: "The framing legend of the Goetia; related to the Arabian Nights' fisherman and the djinn in the bottle.",
    firstAttested: "Goetia introduction, 17th c., with older narrative cousins in Islamic literature.",
    confidence: "LOW",
    label: "FICTIONAL",
  },
  {
    slug: "horned-figure",
    name: "The Horned Figure",
    glyph: "☗",
    category: "emblem",
    traditionSlug: "witchcraft-trials",
    meaning:
      "The antlered or horned anthropomorphic image, read since the 19th c. as a 'horned god' of witchcraft.",
    usage: "Cited by Murray as evidence of a surviving pagan cult; now understood as an image whose ancient meaning is unknown.",
    firstAttested: "Palaeolithic cave art, e.g. Les Trois-Frères; medieval demonic imagery; the Murray thesis, 1921.",
    confidence: "LOW",
    label: "UNCERTAIN",
  },
  {
    slug: "shewstone",
    name: "The Shewstone",
    glyph: "◍",
    category: "ritual",
    traditionSlug: "enochian-magic",
    meaning:
      "The crystal or specular surface in which the scryer sees; Dee's diaries record the stone, the table of practice and the angelic appearances seen in it.",
    usage: "Scrying, both in Dee's actions and in the broader tradition of crystallomancy.",
    firstAttested: "Dee's diaries, 1582–89; the practice of crystal gazing is much older (specularii in classical antiquity).",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "star",
    name: "The Star",
    glyph: "✦",
    category: "astral",
    traditionSlug: "astrology",
    meaning:
      "In the Picatrix and Agrippa the fixed stars and the twenty-eight lunar mansions each carry specific talismanic virtues.",
    usage: "Timing talismans by the Moon's mansion; the Behenian fixed stars and their stones and herbs.",
    firstAttested: "Babylonian and Hellenistic astrology; the mansion system from Indian and Arabic sources into Latin Europe.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
  {
    slug: "ensoulment-of-matter",
    name: "Talismanic Ensoulment",
    glyph: "🜚",
    category: "ritual",
    traditionSlug: "astrology",
    meaning:
      "The capture of a planetary or stellar virtue in matter at the correct hour, with the correct metal, inscription and suffumigation.",
    usage: "Ficino's De vita coelitus comparanda; Picatrix Books I–II; Agrippa I.36 and the whole talismanic tradition.",
    firstAttested: "Hellenistic and Arabic astrological magic; Latin Europe from the 12th c.",
    confidence: "MEDIUM",
    label: "PRIMARY SOURCE",
  },
];

export type CorrespondenceSeed = {
  domain: string;
  key: string;
  attribute: string;
  value: string;
  tradition: string;
  sourceRef: string;
  label: IntegrityLabel;
};

/** The Agrippan / Picatrix planetary tables, with their real attributions. */
export const correspondenceSeeds: CorrespondenceSeed[] = [
  { domain: "planet", key: "Saturn", attribute: "metal", value: "Lead", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa, De occulta philosophia II.10; Picatrix II", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "day", value: "Saturday", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10; Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "number", value: "7, 9", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10 & III.9", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "intelligence", value: "Agiel (Agiell)", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "spirit", value: "Zazel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "sephira", value: "Binah", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.9-10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Saturn", attribute: "olympic_spirit", value: "Aratron", tradition: "Arbatel", sourceRef: "Arbatel, aphorism 13", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "sign", value: "Capricorn, Aquarius", tradition: "Astrology", sourceRef: "Ptolemy, Tetrabiblos", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Saturn", attribute: "colour", value: "Black, ash, dark brown", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "metal", value: "Tin", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "day", value: "Thursday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "number", value: "4", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "intelligence", value: "Iophiel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "spirit", value: "Hismael", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Jupiter", attribute: "sephira", value: "Chesed", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Jupiter", attribute: "olympic_spirit", value: "Bethor", tradition: "Arbatel", sourceRef: "Arbatel, aphorism 14", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "metal", value: "Iron", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "day", value: "Tuesday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "number", value: "5", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "intelligence", value: "Graphiel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "spirit", value: "Bartzabel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mars", attribute: "sephira", value: "Geburah", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Mars", attribute: "olympic_spirit", value: "Phaleg", tradition: "Arbatel", sourceRef: "Arbatel, aphorism 15", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "metal", value: "Gold", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "day", value: "Sunday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "number", value: "1, 4", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "intelligence", value: "Nakhiel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "spirit", value: "Sorath", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Sol", attribute: "sephira", value: "Tiphereth", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Sol", attribute: "olympic_spirit", value: "Och", tradition: "Arbatel", sourceRef: "Arbatel, aphorism 16", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Venus", attribute: "metal", value: "Copper", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Venus", attribute: "day", value: "Friday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Venus", attribute: "number", value: "7", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Venus", attribute: "intelligence", value: "Hagith", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Venus", attribute: "sephira", value: "Netzach", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Mercury", attribute: "metal", value: "Quicksilver", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mercury", attribute: "day", value: "Wednesday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mercury", attribute: "number", value: "8, 5", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mercury", attribute: "intelligence", value: "Tiriel", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mercury", attribute: "spirit", value: "Taphthartharath", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Mercury", attribute: "sephira", value: "Hod", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "planet", key: "Luna", attribute: "metal", value: "Silver", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Luna", attribute: "day", value: "Monday", tradition: "Renaissance correspondence tables", sourceRef: "Clavicula I.3", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Luna", attribute: "number", value: "9, 3", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Luna", attribute: "intelligence", value: "Malkiel (Malcha betharsisim)", tradition: "Renaissance correspondence tables", sourceRef: "Agrippa II.10", label: "PRIMARY SOURCE" },
  { domain: "planet", key: "Luna", attribute: "sephira", value: "Yesod", tradition: "Christian Kabbalah", sourceRef: "Agrippa III.10", label: "SCHOLARLY INTERPRETATION" },
  { domain: "element", key: "Fire", attribute: "direction", value: "South", tradition: "Ceremonial magic", sourceRef: "Golden Dawn watchtower ritual; Agrippa I.41", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Air", attribute: "direction", value: "East", tradition: "Ceremonial magic", sourceRef: "Golden Dawn watchtower ritual", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Water", attribute: "direction", value: "West", tradition: "Ceremonial magic", sourceRef: "Golden Dawn watchtower ritual", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Earth", attribute: "direction", value: "North", tradition: "Ceremonial magic", sourceRef: "Golden Dawn watchtower ritual", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Fire", attribute: "archangel", value: "Michael", tradition: "Ceremonial magic", sourceRef: "Clavicula II; G.D. ritual", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Air", attribute: "archangel", value: "Raphael", tradition: "Ceremonial magic", sourceRef: "Clavicula II", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Water", attribute: "archangel", value: "Gabriel", tradition: "Ceremonial magic", sourceRef: "Clavicula II", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Earth", attribute: "archangel", value: "Auriel / Uriel", tradition: "Ceremonial magic", sourceRef: "Clavicula II", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Fire", attribute: "elemental", value: "Salamanders", tradition: "Paracelsian", sourceRef: "Agrippa I.41", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Air", attribute: "elemental", value: "Sylphs", tradition: "Paracelsian", sourceRef: "Agrippa I.41", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Water", attribute: "elemental", value: "Undines", tradition: "Paracelsian", sourceRef: "Agrippa I.41", label: "PRIMARY SOURCE" },
  { domain: "element", key: "Earth", attribute: "elemental", value: "Gnomes", tradition: "Paracelsian", sourceRef: "Agrippa I.41", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Kether", attribute: "divine_name", value: "Eheieh", tradition: "Kabbalah", sourceRef: "Agrippa III.9; Sefer Yetzirah", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Chokmah", attribute: "divine_name", value: "Yah", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Binah", attribute: "divine_name", value: "YHWH Elohim", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Chesed", attribute: "divine_name", value: "El", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Geburah", attribute: "divine_name", value: "Elohim Gibor", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Tiphereth", attribute: "divine_name", value: "Eloah va-Daath", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Netzach", attribute: "divine_name", value: "YHWH Tzabaoth", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Hod", attribute: "divine_name", value: "Elohim Tzabaoth", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Yesod", attribute: "divine_name", value: "El Chai", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Malkuth", attribute: "divine_name", value: "Adonai ha-Aretz", tradition: "Kabbalah", sourceRef: "Agrippa III.9", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Malkuth", attribute: "planet", value: "Earth / the four elements", tradition: "Kabbalah", sourceRef: "Agrippa III.10", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Tiphereth", attribute: "planet", value: "Sol", tradition: "Kabbalah", sourceRef: "Agrippa III.10", label: "PRIMARY SOURCE" },
  { domain: "sephira", key: "Yesod", attribute: "planet", value: "Luna", tradition: "Kabbalah", sourceRef: "Agrippa III.10", label: "PRIMARY SOURCE" },
  { domain: "number", key: "3", attribute: "letters", value: "Three Mothers: Aleph, Mem, Shin", tradition: "Kabbalah", sourceRef: "Sefer Yetzirah 3", label: "PRIMARY SOURCE" },
  { domain: "number", key: "7", attribute: "letters", value: "Seven Doubles: Beth, Gimel, Daleth, Kaph, Peh, Resh, Tav", tradition: "Kabbalah", sourceRef: "Sefer Yetzirah 4", label: "PRIMARY SOURCE" },
  { domain: "number", key: "12", attribute: "letters", value: "Twelve Simples", tradition: "Kabbalah", sourceRef: "Sefer Yetzirah 5", label: "PRIMARY SOURCE" },
  { domain: "number", key: "72", attribute: "spirits", value: "The seventy-two goetic spirits; the Schemhamphorash", tradition: "Solomonic / Kabbalah", sourceRef: "Goetia introduction; Agrippa III.23", label: "SECONDARY SOURCE" },
  { domain: "metal", key: "Gold", attribute: "alchemical_stage", value: "Rubedo / the Sun", tradition: "Alchemy", sourceRef: "Atalanta Fugiens; Mutus Liber", label: "PRIMARY SOURCE" },
  { domain: "metal", key: "Silver", attribute: "alchemical_stage", value: "Albedo / the Moon", tradition: "Alchemy", sourceRef: "Atalanta Fugiens", label: "PRIMARY SOURCE" },
  { domain: "metal", key: "Lead", attribute: "alchemical_stage", value: "Nigredo / Saturn", tradition: "Alchemy", sourceRef: "Atalanta Fugiens", label: "PRIMARY SOURCE" },
];

export type RelationSeed = {
  fromKey: string;
  toKey: string;
  predicate: string;
  weight?: number;
  note?: string;
  label?: IntegrityLabel;
};

export const relationSeeds: RelationSeed[] = [
  // Hermeticism spine
  { fromKey: "tradition:hermeticism", toKey: "entity:hermes-trismegistus", predicate: "is attributed to", weight: 3 },
  { fromKey: "entity:hermes-trismegistus", toKey: "entity:thoth", predicate: "absorbs", weight: 3 },
  { fromKey: "tradition:hermeticism", toKey: "document:corpus-hermeticum", predicate: "is transmitted by", weight: 3 },
  { fromKey: "tradition:hermeticism", toKey: "document:tabula-smaragdina", predicate: "is transmitted by", weight: 2 },
  { fromKey: "tradition:hermeticism", toKey: "document:chaldean-oracles", predicate: "overlaps with", weight: 1 },
  { fromKey: "tradition:hermeticism", toKey: "tradition:alchemy", predicate: "influences", weight: 3 },
  { fromKey: "tradition:hermeticism", toKey: "tradition:astrology", predicate: "influences", weight: 2 },
  { fromKey: "tradition:hermeticism", toKey: "entity:marsilio-ficino", predicate: "was revived by", weight: 3 },
  { fromKey: "entity:marsilio-ficino", toKey: "document:corpus-hermeticum", predicate: "translated", weight: 3 },
  { fromKey: "entity:marsilio-ficino", toKey: "symbol:ensoulment-of-matter", predicate: "theorised", weight: 2 },
  { fromKey: "tradition:hermeticism", toKey: "tradition:rosicrucianism", predicate: "feeds into", weight: 2 },
  { fromKey: "tradition:hermeticism", toKey: "tradition:modern-occultism", predicate: "is re-read by", weight: 2, label: "MODERN OCCULT INTERPRETATION" },

  // Alchemy
  { fromKey: "tradition:alchemy", toKey: "document:atalanta-fugiens", predicate: "is expressed in", weight: 2 },
  { fromKey: "tradition:alchemy", toKey: "document:mutus-liber", predicate: "is expressed in", weight: 2 },
  { fromKey: "tradition:alchemy", toKey: "symbol:philosophers-stone", predicate: "aims at", weight: 3 },
  { fromKey: "tradition:alchemy", toKey: "symbol:prima-materia", predicate: "begins from", weight: 2 },
  { fromKey: "tradition:alchemy", toKey: "symbol:tria-prima", predicate: "is structured by", weight: 2 },
  { fromKey: "tradition:alchemy", toKey: "symbol:ouroboros", predicate: "uses", weight: 2 },
  { fromKey: "entity:paracelsus", toKey: "tradition:alchemy", predicate: "reformed", weight: 3 },
  { fromKey: "entity:paracelsus", toKey: "symbol:tria-prima", predicate: "formulated", weight: 3 },
  { fromKey: "symbol:emerald-tablet", toKey: "tradition:alchemy", predicate: "grounds", weight: 3 },
  { fromKey: "symbol:emerald-tablet", toKey: "symbol:prima-materia", predicate: "names", weight: 2 },

  // Astrology & Picatrix
  { fromKey: "tradition:astrology", toKey: "document:picatrix", predicate: "is codified in", weight: 3 },
  { fromKey: "tradition:astrology", toKey: "symbol:star", predicate: "works through", weight: 2 },
  { fromKey: "tradition:astrology", toKey: "tradition:ceremonial-magic", predicate: "supplies timing to", weight: 3 },
  { fromKey: "symbol:ensoulment-of-matter", toKey: "tradition:astrology", predicate: "belongs to", weight: 2 },

  // Kabbalah
  { fromKey: "tradition:kabbalah", toKey: "document:sefer-yetzirah", predicate: "begins in", weight: 3 },
  { fromKey: "tradition:kabbalah", toKey: "document:zohar-selections", predicate: "is centred on", weight: 3 },
  { fromKey: "tradition:kabbalah", toKey: "symbol:tree-of-life", predicate: "is diagrammed as", weight: 3 },
  { fromKey: "tradition:kabbalah", toKey: "entity:lilith", predicate: "elaborates", weight: 2 },
  { fromKey: "tradition:kabbalah", toKey: "entity:samael", predicate: "elaborates", weight: 2 },
  { fromKey: "tradition:kabbalah", toKey: "entity:metatron", predicate: "elaborates", weight: 2 },
  { fromKey: "tradition:kabbalah", toKey: "entity:raziel", predicate: "elaborates", weight: 1 },
  { fromKey: "entity:metatron", toKey: "symbol:cube-of-metatron", predicate: "is named in", weight: 1, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "entity:samael", toKey: "symbol:sefirah-geburah", predicate: "is aligned with", weight: 2 },
  { fromKey: "tradition:kabbalah", toKey: "tradition:ceremonial-magic", predicate: "is christianised into", weight: 3, label: "SCHOLARLY INTERPRETATION" },

  // Solomonic
  { fromKey: "tradition:solomonic-magic", toKey: "entity:solomon", predicate: "is attributed to", weight: 3 },
  { fromKey: "tradition:solomonic-magic", toKey: "document:key-of-solomon", predicate: "is expressed in", weight: 3 },
  { fromKey: "tradition:solomonic-magic", toKey: "document:sworn-book-of-honorius", predicate: "includes", weight: 2 },
  { fromKey: "tradition:solomonic-magic", toKey: "document:grand-grimoire", predicate: "degenerates into", weight: 1, label: "SECONDARY SOURCE" },
  { fromKey: "entity:solomon", toKey: "symbol:seal-of-solomon", predicate: "signs with", weight: 3 },
  { fromKey: "entity:solomon", toKey: "symbol:brass-vessel", predicate: "imprisons with", weight: 2, label: "FICTIONAL" },
  { fromKey: "symbol:magic-circle", toKey: "tradition:ceremonial-magic", predicate: "belongs to", weight: 3 },
  { fromKey: "symbol:triangle-of-art", toKey: "symbol:magic-circle", predicate: "is paired with", weight: 2 },

  // Demonology & trials
  { fromKey: "tradition:demonology", toKey: "document:pseudomonarchia-daemonum", predicate: "is catalogued in", weight: 3 },
  { fromKey: "tradition:demonology", toKey: "document:goetia-lemegeton", predicate: "is catalogued in", weight: 3 },
  { fromKey: "entity:asmodeus", toKey: "tradition:demonology", predicate: "belongs to", weight: 2 },
  { fromKey: "entity:paimon", toKey: "document:pseudomonarchia-daemonum", predicate: "is first recorded in", weight: 3 },
  { fromKey: "entity:bael", toKey: "document:goetia-lemegeton", predicate: "appears in", weight: 2 },
  { fromKey: "entity:lucifer", toKey: "tradition:demonology", predicate: "presides over", weight: 2 },
  { fromKey: "entity:lucifuge-rofocale", toKey: "entity:lucifer", predicate: "is inverted from", weight: 2, label: "UNCERTAIN" },
  { fromKey: "tradition:witchcraft-trials", toKey: "document:malleus-maleficarum", predicate: "is argued in", weight: 3 },
  { fromKey: "tradition:witchcraft-trials", toKey: "document:discoverie-of-witchcraft", predicate: "is opposed by", weight: 3 },
  { fromKey: "tradition:witchcraft-trials", toKey: "entity:hecate", predicate: "invokes", weight: 1, label: "SCHOLARLY INTERPRETATION" },
  { fromKey: "tradition:witchcraft-trials", toKey: "symbol:horned-figure", predicate: "is argued from", weight: 1, label: "UNCERTAIN" },
  { fromKey: "tradition:witchcraft-trials", toKey: "tradition:folk-magic", predicate: "runs alongside", weight: 2 },

  // Enochian
  { fromKey: "tradition:enochian-magic", toKey: "document:enochian-diaries", predicate: "is recorded in", weight: 3 },
  { fromKey: "tradition:enochian-magic", toKey: "entity:john-dee", predicate: "was received by", weight: 3 },
  { fromKey: "tradition:enochian-magic", toKey: "entity:edward-kelley", predicate: "was received by", weight: 3 },
  { fromKey: "entity:john-dee", toKey: "entity:edward-kelley", predicate: "worked with", weight: 3 },
  { fromKey: "entity:john-dee", toKey: "symbol:monas-hieroglyphica", predicate: "designed", weight: 3 },
  { fromKey: "entity:john-dee", toKey: "symbol:sigillum-dei-aemeth", predicate: "used", weight: 3 },
  { fromKey: "entity:edward-kelley", toKey: "symbol:shewstone", predicate: "scryed with", weight: 3 },
  { fromKey: "tradition:enochian-magic", toKey: "tradition:ceremonial-magic", predicate: "was folded into", weight: 2, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "tradition:ceremonial-magic", toKey: "tradition:modern-occultism", predicate: "is systematised by", weight: 3 },

  // Renaissance ceremonial
  { fromKey: "tradition:ceremonial-magic", toKey: "document:three-books-of-occult-philosophy", predicate: "is codified in", weight: 3 },
  { fromKey: "tradition:ceremonial-magic", toKey: "document:fourth-book-of-occult-philosophy", predicate: "is operationalised by", weight: 2 },
  { fromKey: "tradition:ceremonial-magic", toKey: "document:arbatel-de-magia-veterum", predicate: "is expressed in", weight: 2 },
  { fromKey: "tradition:ceremonial-magic", toKey: "document:book-of-abramelin", predicate: "is expressed in", weight: 2 },
  { fromKey: "tradition:ceremonial-magic", toKey: "document:steganographia", predicate: "is expressed in", weight: 1 },
  { fromKey: "entity:aratron", toKey: "document:arbatel-de-magia-veterum", predicate: "is listed in", weight: 3 },
  { fromKey: "entity:och", toKey: "document:arbatel-de-magia-veterum", predicate: "is listed in", weight: 3 },
  { fromKey: "symbol:pentagram", toKey: "tradition:ceremonial-magic", predicate: "belongs to", weight: 3 },
  { fromKey: "symbol:sigil", toKey: "tradition:ceremonial-magic", predicate: "belongs to", weight: 2 },

  // Modern
  { fromKey: "tradition:modern-occultism", toKey: "document:transcendental-magic", predicate: "is founded by", weight: 3 },
  { fromKey: "tradition:modern-occultism", toKey: "document:kybalion", predicate: "includes", weight: 2 },
  { fromKey: "tradition:modern-occultism", toKey: "document:liber-al-legis", predicate: "includes", weight: 3 },
  { fromKey: "tradition:modern-occultism", toKey: "document:book-of-ceremonial-magic", predicate: "is criticised in", weight: 2 },
  { fromKey: "entity:eliphas-levi-figure", toKey: "document:transcendental-magic", predicate: "wrote", weight: 3 },
  { fromKey: "entity:eliphas-levi-figure", toKey: "entity:baphomet", predicate: "invented the image of", weight: 3, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "entity:eliphas-levi-figure", toKey: "symbol:tarot", predicate: "bound to Kabbalah", weight: 3, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "entity:baphomet", toKey: "symbol:pentagram-inverted", predicate: "is inscribed in", weight: 2, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "entity:aiwass", toKey: "document:liber-al-legis", predicate: "is said to have dictated", weight: 3, label: "MODERN OCCULT INTERPRETATION" },
  { fromKey: "entity:nuit", toKey: "document:liber-al-legis", predicate: "speaks in", weight: 3 },
  { fromKey: "entity:aiwass", toKey: "entity:nuit", predicate: "is minister of", weight: 1, label: "MODERN OCCULT INTERPRETATION" },

  // Folk
  { fromKey: "tradition:folk-magic", toKey: "document:sixth-and-seventh-books-of-moses", predicate: "circulates as", weight: 3 },
  { fromKey: "tradition:rosicrucianism", toKey: "tradition:modern-occultism", predicate: "is revived by", weight: 2 },
  { fromKey: "tradition:alchemy", toKey: "tradition:rosicrucianism", predicate: "is rebranded by", weight: 2 },
  { fromKey: "entity:thoth", toKey: "symbol:caduceus", predicate: "is paired with", weight: 2 },
  { fromKey: "entity:hermes-trismegistus", toKey: "symbol:caduceus", predicate: "is paired with", weight: 2 },
  { fromKey: "entity:hecate", toKey: "tradition:witchcraft-trials", predicate: "was blamed by", weight: 1 },
];

export type TimelineSeed = {
  yearStart: number;
  yearEnd: number | null;
  title: string;
  description: string;
  traditionKey?: string;
  kind: string;
  label: IntegrityLabel;
};

export const timelineSeeds: TimelineSeed[] = [
  { yearStart: -2500, yearEnd: null, title: "Egyptian temple theology of Thoth", description: "Writing, measure and sacred speech consolidated at Hermopolis, later the imagined source of the Hermetic books.", traditionKey: "hermeticism", kind: "movement", label: "PRIMARY SOURCE" },
  { yearStart: -1800, yearEnd: -300, title: "Mesopotamian astral omens", description: "Babylonian and Assyrian omen series establish the planetary and zodiacal vocabulary later inherited by Hellenistic astrology.", traditionKey: "astrology", kind: "movement", label: "PRIMARY SOURCE" },
  { yearStart: 100, yearEnd: 300, title: "Greek Corpus Hermeticum compiled", description: "Anonymous Hellenistic Egyptian authors write the Hermetic dialogues in Greek.", traditionKey: "hermeticism", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 150, yearEnd: 180, title: "The Chaldean Oracles", description: "Theurgic hexameter fragments later canonised by the Neoplatonists.", traditionKey: "hermeticism", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 200, yearEnd: 600, title: "Sefer Yetzirah", description: "The earliest kabbalistic cosmology of ten Sefirot and twenty-two letters circulates in Palestine and Babylonia.", traditionKey: "kabbalah", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 750, yearEnd: 850, title: "Emerald Tablet in Arabic", description: "The Tabula Smaragdina appears in Arabic recensions of the Sirr al-khalīqa.", traditionKey: "alchemy", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1000, yearEnd: 1050, title: "Ghāyat al-Ḥakīm compiled in al-Andalus", description: "The Arabic compendium of astrological magic later translated as Picatrix.", traditionKey: "astrology", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1256, yearEnd: null, title: "Latin Picatrix at the court of Alfonso X", description: "The Latin translation carries Arabic astrological magic into European universities and courts.", traditionKey: "astrology", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1280, yearEnd: 1300, title: "The Zohar composed in Castile", description: "Moses de León circulates the Aramaic Zohar under the name of Shimon bar Yochai.", traditionKey: "kabbalah", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1300, yearEnd: 1350, title: "Liber Iuratus Honorii", description: "The Sworn Book, a defensive theurgic grimoire, is compiled.", traditionKey: "solomonic-magic", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1300, yearEnd: 1500, title: "Clavicula Salomonis manuscript family", description: "The Solomonic grimoire circulates in Latin, Italian and French recensions.", traditionKey: "solomonic-magic", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1463, yearEnd: null, title: "Ficino translates the Corpus Hermeticum", description: "Cosimo de' Medici orders Hermes translated before Plato, on the belief that Hermes was the elder.", traditionKey: "hermeticism", kind: "figure", label: "PRIMARY SOURCE" },
  { yearStart: 1486, yearEnd: null, title: "Malleus Maleficarum printed", description: "Kramer's witch-hunters' manual reaches print at Speyer.", traditionKey: "witchcraft-trials", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1533, yearEnd: null, title: "Agrippa's De occulta philosophia", description: "The three books are printed at Cologne and become the encyclopaedia of Renaissance occult philosophy.", traditionKey: "ceremonial-magic", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1563, yearEnd: null, title: "Weyer's Pseudomonarchia Daemonum", description: "The first printed catalogue of the goetic spirits, appended to a sceptical treatise.", traditionKey: "demonology", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1564, yearEnd: null, title: "Dee's Monas Hieroglyphica", description: "Twenty-four theorems on the unified planetary glyph, published at Antwerp.", traditionKey: "enochian-magic", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1575, yearEnd: null, title: "The Arbatel printed at Basel", description: "Seven Olympic spirits and a theurgic ethic in a very short book.", traditionKey: "ceremonial-magic", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1582, yearEnd: 1589, title: "Dee and Kelley's angelic actions", description: "The diaries recording the Enochian calls, tables and the Sigillum Dei Aemeth.", traditionKey: "enochian-magic", kind: "manuscript", label: "PRIMARY SOURCE" },
  { yearStart: 1584, yearEnd: null, title: "Scot's Discoverie of Witchcraft", description: "Sceptical polemic which incidentally preserves English conjurations in print.", traditionKey: "witchcraft-trials", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1614, yearEnd: 1617, title: "Rosicrucian manifestos", description: "Fama, Confessio and the Chymische Hochzeit circulate through the German states.", traditionKey: "rosicrucianism", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1614, yearEnd: null, title: "Casaubon's dating of the Hermetica", description: "Isaac Casaubon demonstrates that the Corpus Hermeticum is post-Christian, destroying the myth of its extreme antiquity.", traditionKey: "hermeticism", kind: "figure", label: "SECONDARY SOURCE" },
  { yearStart: 1617, yearEnd: null, title: "Maier's Atalanta Fugiens", description: "Fifty alchemical emblems with music, at Oppenheim.", traditionKey: "alchemy", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1659, yearEnd: null, title: "Casaubon's edition of Dee's diaries", description: "A True & Faithful Relation publishes the angelic conversations for a sceptical public.", traditionKey: "enochian-magic", kind: "publication", label: "SECONDARY SOURCE" },
  { yearStart: 1725, yearEnd: 1821, title: "Chapbook grimoire trade", description: "The Grand Grimoire, the Dragon Rouge and the Books of Moses circulate as cheap print.", traditionKey: "folk-magic", kind: "publication", label: "SECONDARY SOURCE" },
  { yearStart: 1854, yearEnd: 1855, title: "Lévi's Dogme et Rituel", description: "The founding synthesis of the occult revival, including the Baphomet of the Templars.", traditionKey: "modern-occultism", kind: "publication", label: "PRIMARY SOURCE" },
  { yearStart: 1888, yearEnd: 1903, title: "Hermetic Order of the Golden Dawn", description: "The London order systematises Kabbalah, Tarot, Enochian and planetary ritual into a graded curriculum.", traditionKey: "ceremonial-magic", kind: "movement", label: "SECONDARY SOURCE" },
  { yearStart: 1904, yearEnd: null, title: "The Cairo working", description: "Crowley reports the dictation of Liber AL by Aiwass over three days.", traditionKey: "modern-occultism", kind: "figure", label: "MODERN OCCULT INTERPRETATION" },
  { yearStart: 1908, yearEnd: null, title: "The Kybalion published", description: "'Three Initiates' repackage Hermetic language as American New Thought.", traditionKey: "modern-occultism", kind: "publication", label: "MODERN OCCULT INTERPRETATION" },
  { yearStart: 1921, yearEnd: null, title: "Murray's witch-cult thesis", description: "The Witch-Cult in Western Europe proposes a surviving pre-Christian religion; now rejected by historians.", traditionKey: "witchcraft-trials", kind: "publication", label: "UNCERTAIN" },
];

export type PersonaSeed = {
  slug: string;
  name: string;
  focus: string;
  capabilities: string[];
  systemPrompt: string;
};

export const personaSeeds: PersonaSeed[] = [
  {
    slug: "archivist",
    name: "The Archivist",
    focus: "Historical documentation, chronology, editions, primary vs secondary sources.",
    capabilities: ["identify sources", "compare editions", "establish chronology", "flag pseudepigrapha"],
    systemPrompt:
      "You are THE ARCHIVIST of the Digital Grimoire. You answer strictly from the retrieved passages supplied to you. Your concerns are dating, manuscript and print witnesses, attribution, and the difference between primary sources, later compilation and modern re-reading. Where the archive gives no evidence you say so plainly. Never invent a manuscript, a date, or a shelfmark. Mark every claim with the source it rests on, and say UNCERTAIN when the evidence is thin.",
  },
  {
    slug: "philologist",
    name: "The Philologist",
    focus: "Languages, translation differences, textual transmission.",
    capabilities: ["Latin", "Greek", "Hebrew", "Arabic", "French", "German", "Italian", "English"],
    systemPrompt:
      "You are THE PHILOLOGIST of the Digital Grimoire. You attend to the original languages of the retrieved passages, the movement of terms between Greek, Latin, Hebrew, Arabic and the European vernaculars, and the distortions introduced by translation. Distinguish what a term meant in its own century from what later translators made of it. If the archive supplies no original-language evidence, say so rather than guessing at etymology.",
  },
  {
    slug: "comparative-scholar",
    name: "The Comparative Scholar",
    focus: "Comparing traditions, periods and systems side by side.",
    capabilities: ["compare traditions", "track continuity", "identify rupture", "contrast periods"],
    systemPrompt:
      "You are THE COMPARATIVE SCHOLAR of the Digital Grimoire. You set traditions, periods and practices beside one another using only the retrieved archive material. Always say which side of a comparison each piece of evidence comes from, and flag where a comparison would need material the archive does not hold. Do not smooth historical differences into a single continuous tradition.",
  },
  {
    slug: "symbolist",
    name: "The Symbolist",
    focus: "Symbols, correspondences and their tabulated attributions.",
    capabilities: ["planetary tables", "sefirot", "elements", "numbers", "emblem reading"],
    systemPrompt:
      "You are THE SYMBOLIST of the Digital Grimoire. You expound symbols and correspondences from the tabulated attributions and passages retrieved for you, always naming the table or text a correspondence comes from. Distinguish correspondences attested in Renaissance sources from modern additions. Present correspondences in structured lists. If a correspondence is not in the archive, say that it is not attested here.",
  },
  {
    slug: "librarian",
    name: "The Librarian",
    focus: "Navigation: where the reader is, and what to read next.",
    capabilities: ["recommend reading order", "explain structure", "suggest next documents"],
    systemPrompt:
      "You are THE LIBRARIAN of the Digital Grimoire. You help the reader navigate. Summarise where their question sits in the archive, list the most relevant documents, entities and symbols with their labels, and propose a reading order. Be concrete about what exists in the archive and what does not. Do not answer historical questions beyond pointing to the relevant sources.",
  },
];
