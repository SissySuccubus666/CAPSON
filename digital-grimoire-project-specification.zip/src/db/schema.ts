import {
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * SOURCE INTEGRITY LABELS
 * Every claim, entry, passage and AI citation in the Digital Grimoire carries one
 * of these labels so that historical evidence is never silently mixed with later
 * occult interpretation or user invention.
 */
export const INTEGRITY_LABELS = [
  "PRIMARY SOURCE",
  "SECONDARY SOURCE",
  "SCHOLARLY INTERPRETATION",
  "MODERN OCCULT INTERPRETATION",
  "USER CREATED",
  "FICTIONAL",
  "UNCERTAIN",
] as const;

export type IntegrityLabel = (typeof INTEGRITY_LABELS)[number];

export const CONFIDENCE_LEVELS = ["HIGH", "MEDIUM", "LOW"] as const;
export type ConfidenceLevel = (typeof CONFIDENCE_LEVELS)[number];

/* ------------------------------------------------------------------ */
/* Traditions                                                          */
/* ------------------------------------------------------------------ */
export const traditions = pgTable(
  "traditions",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    kind: text("kind").notNull().default("tradition"), // tradition | movement | system
    region: text("region"),
    periodStart: integer("period_start"),
    periodEnd: integer("period_end"),
    summary: text("summary").notNull().default(""),
    label: text("label").notNull().default("SCHOLARLY INTERPRETATION"),
  },
  (t) => [uniqueIndex("traditions_slug_idx").on(t.slug)],
);

/* ------------------------------------------------------------------ */
/* Authors / translators / scholars                                    */
/* ------------------------------------------------------------------ */
export const authors = pgTable(
  "authors",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    /* e.g. "c. 1491 – c. 1555" */
    flourished: text("flourished"),
    region: text("region"),
    role: text("role").notNull().default("author"), // author | translator | scholar | compiler | disputed
    note: text("note").notNull().default(""),
    label: text("label").notNull().default("SCHOLARLY INTERPRETATION"),
  },
  (t) => [uniqueIndex("authors_slug_idx").on(t.slug)],
);

/* ------------------------------------------------------------------ */
/* Bibliographic sources                                               */
/* ------------------------------------------------------------------ */
export const sources = pgTable(
  "sources",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    author: text("author"),
    year: text("year"),
    place: text("place"),
    sourceType: text("source_type").notNull().default("SECONDARY SOURCE"),
    url: text("url"),
    copyrightStatus: text("copyright_status").notNull().default("Public domain"),
    note: text("note").notNull().default(""),
  },
  (t) => [uniqueIndex("sources_slug_idx").on(t.slug)],
);

/* ------------------------------------------------------------------ */
/* Documents — the digital library                                     */
/* ------------------------------------------------------------------ */
export const documents = pgTable(
  "documents",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    originalTitle: text("original_title"),
    authorId: integer("author_id"),
    attribution: text("attribution").notNull().default(""),
    dateCreated: text("date_created").notNull().default(""),
    yearStart: integer("year_start"),
    yearEnd: integer("year_end"),
    region: text("region"),
    language: text("language"),
    traditionId: integer("tradition_id"),
    translator: text("translator"),
    edition: text("edition"),
    sourceId: integer("source_id"),
    copyrightStatus: text("copyright_status").notNull().default("Public domain"),
    docType: text("doc_type").notNull().default("grimoire"),
    historicalPeriod: text("historical_period"),
    format: text("format").notNull().default("txt"),
    summary: text("summary").notNull().default(""),
    label: text("label").notNull().default("PRIMARY SOURCE"),
  },
  (t) => [
    uniqueIndex("documents_slug_idx").on(t.slug),
    index("documents_tradition_idx").on(t.traditionId),
  ],
);

/* ------------------------------------------------------------------ */
/* Passages — retrievable chunks used by the RAG pipeline              */
/* ------------------------------------------------------------------ */
export const passages = pgTable(
  "passages",
  {
    id: serial("id").primaryKey(),
    documentId: integer("document_id").notNull(),
    ordinal: integer("ordinal").notNull().default(1),
    locator: text("locator").notNull().default(""),
    heading: text("heading").notNull().default(""),
    text: text("text").notNull(),
    label: text("label").notNull().default("PRIMARY SOURCE"),
    keywords: text("keywords").array().notNull().default([]),
  },
  (t) => [index("passages_document_idx").on(t.documentId)],
);

/* ------------------------------------------------------------------ */
/* Entities — the occult entity database                               */
/* ------------------------------------------------------------------ */
export const entities = pgTable(
  "entities",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    kind: text("kind").notNull().default("figure"),
    alternateNames: text("alternate_names").array().notNull().default([]),
    traditionId: integer("tradition_id"),
    historicalPeriod: text("historical_period"),
    primarySources: text("primary_sources").notNull().default(""),
    secondarySources: text("secondary_sources").notNull().default(""),
    symbolism: text("symbolism").notNull().default(""),
    associatedSymbols: text("associated_symbols").array().notNull().default([]),
    associatedPlanets: text("associated_planets").array().notNull().default([]),
    associatedElements: text("associated_elements").array().notNull().default([]),
    associatedNumbers: integer("associated_numbers").array().notNull().default([]),
    historicalInterpretation: text("historical_interpretation").notNull().default(""),
    laterInterpretation: text("later_interpretation").notNull().default(""),
    modernInterpretation: text("modern_interpretation").notNull().default(""),
    references: text("references").notNull().default(""),
    confidence: text("confidence").notNull().default("MEDIUM"),
    label: text("label").notNull().default("PRIMARY SOURCE"),
  },
  (t) => [uniqueIndex("entities_slug_idx").on(t.slug)],
);

/* ------------------------------------------------------------------ */
/* Symbols                                                             */
/* ------------------------------------------------------------------ */
export const symbols = pgTable(
  "symbols",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    glyph: text("glyph").notNull().default(""),
    category: text("category").notNull().default("sigil"),
    traditionId: integer("tradition_id"),
    meaning: text("meaning").notNull().default(""),
    usage: text("usage").notNull().default(""),
    firstAttested: text("first_attested").notNull().default(""),
    confidence: text("confidence").notNull().default("MEDIUM"),
    label: text("label").notNull().default("PRIMARY SOURCE"),
  },
  (t) => [uniqueIndex("symbols_slug_idx").on(t.slug)],
);

/* ------------------------------------------------------------------ */
/* Correspondences                                                     */
/* ------------------------------------------------------------------ */
export const correspondences = pgTable("correspondences", {
  id: serial("id").primaryKey(),
  domain: text("domain").notNull(), // planet | sephira | element | zodiac | number | metal
  key: text("key").notNull(),
  attribute: text("attribute").notNull(), // metal | day | number | intelligence | spirit | colour ...
  value: text("value").notNull(),
  tradition: text("tradition"),
  sourceRef: text("source_ref").notNull().default(""),
  label: text("label").notNull().default("SECONDARY SOURCE"),
});

/* ------------------------------------------------------------------ */
/* Relations — the knowledge graph edges                               */
/* ------------------------------------------------------------------ */
export const relations = pgTable(
  "relations",
  {
    id: serial("id").primaryKey(),
    fromKey: text("from_key").notNull(),
    toKey: text("to_key").notNull(),
    predicate: text("predicate").notNull(),
    weight: integer("weight").notNull().default(1),
    note: text("note").notNull().default(""),
    label: text("label").notNull().default("SCHOLARLY INTERPRETATION"),
  },
  (t) => [index("relations_from_idx").on(t.fromKey), index("relations_to_idx").on(t.toKey)],
);

/* ------------------------------------------------------------------ */
/* Timeline                                                            */
/* ------------------------------------------------------------------ */
export const timelineEvents = pgTable("timeline_events", {
  id: serial("id").primaryKey(),
  yearStart: integer("year_start").notNull(),
  yearEnd: integer("year_end"),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  traditionKey: text("tradition_key"),
  kind: text("kind").notNull().default("manuscript"), // manuscript | publication | figure | movement
  label: text("label").notNull().default("SECONDARY SOURCE"),
});

/* ------------------------------------------------------------------ */
/* User notes                                                          */
/* ------------------------------------------------------------------ */
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  documentSlug: text("document_slug"),
  entitySlug: text("entity_slug"),
  title: text("title").notNull(),
  body: text("body").notNull(),
  label: text("label").notNull().default("USER CREATED"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Custom grimoires (.grim workspaces)                                 */
/* ------------------------------------------------------------------ */
export const customGrimoires = pgTable(
  "custom_grimoires",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    author: text("author").notNull().default("User"),
    tradition: text("tradition").notNull().default(""),
    description: text("description").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("custom_grimoires_slug_idx").on(t.slug)],
);

export const grimoireEntries = pgTable(
  "grimoire_entries",
  {
    id: serial("id").primaryKey(),
    grimoireId: integer("grimoire_id").notNull(),
    entryType: text("entry_type").notNull(), // entity | symbol | correspondence | text | note | illustration | reference
    name: text("name").notNull(),
    body: text("body").notNull().default(""),
    meta: jsonb("meta").$type<Record<string, string | number | null>>(),
    label: text("label").notNull().default("USER CREATED"),
    ordinal: integer("ordinal").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("grimoire_entries_grimoire_idx").on(t.grimoireId)],
);

/* ------------------------------------------------------------------ */
/* AI personas + sessions                                              */
/* ------------------------------------------------------------------ */
export const personas = pgTable(
  "personas",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    focus: text("focus").notNull(),
    systemPrompt: text("system_prompt").notNull(),
    capabilities: text("capabilities").array().notNull().default([]),
    builtin: integer("builtin").notNull().default(1),
  },
  (t) => [uniqueIndex("personas_slug_idx").on(t.slug)],
);

export const aiSessions = pgTable("ai_sessions", {
  id: serial("id").primaryKey(),
  personaSlug: text("persona_slug").notNull().default("archivist"),
  question: text("question").notNull(),
  answer: text("answer").notNull().default(""),
  engine: text("engine").notNull().default("retrieval-only"),
  model: text("model"),
  confidence: text("confidence").notNull().default("LOW"),
  citations: jsonb("citations").$type<Citation[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Citation = {
  document: string;
  slug: string;
  locator: string;
  author: string;
  date: string;
  tradition: string;
  label: string;
  snippet: string;
  score: number;
};

/* ------------------------------------------------------------------ */
/* Internal key/value metadata (seed guard, config)                    */
/* ------------------------------------------------------------------ */
export const meta = pgTable("meta", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Tradition = typeof traditions.$inferSelect;
export type Author = typeof authors.$inferSelect;
export type Source = typeof sources.$inferSelect;
export type Document = typeof documents.$inferSelect;
export type Passage = typeof passages.$inferSelect;
export type Entity = typeof entities.$inferSelect;
export type Symbol = typeof symbols.$inferSelect;
export type Correspondence = typeof correspondences.$inferSelect;
export type Relation = typeof relations.$inferSelect;
export type TimelineEvent = typeof timelineEvents.$inferSelect;
export type Note = typeof notes.$inferSelect;
export type CustomGrimoire = typeof customGrimoires.$inferSelect;
export type GrimoireEntry = typeof grimoireEntries.$inferSelect;
export type Persona = typeof personas.$inferSelect;
export type AiSession = typeof aiSessions.$inferSelect;
