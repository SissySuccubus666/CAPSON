import { GraphExplorer } from "@/components/graph-explorer";
import { PageHeader } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function GraphPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const raw = Array.isArray(params.focus) ? params.focus[0] : params.focus;
  const focus = raw ?? null;

  return (
    <div>
      <PageHeader
        eyebrow="version 0.4 — the web"
        title="Knowledge Graph"
        lead="Entities, symbols, traditions and documents joined by typed predicates. Follow the edges from Hermeticism to Ficino to the Corpus Hermeticum, or from Baphomet back to the 1854 plate that invented it."
      />
      <GraphExplorer initialFocus={focus} />
    </div>
  );
}
