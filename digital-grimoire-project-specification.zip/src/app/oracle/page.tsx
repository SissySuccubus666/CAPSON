import { OracleConsole } from "@/components/oracle-console";
import { PageHeader } from "@/components/ui";
import { listPersonas } from "@/lib/ai";

export const dynamic = "force-dynamic";

export default async function OraclePage() {
  const personas = await listPersonas();
  return (
    <div>
      <PageHeader
        eyebrow="version 0.3 — the oracle"
        title="The Local AI Guide"
        lead="Question → database search → retrieved passages → context → local model → answer with source references. The model is never assumed to know the corpus: it is handed the passages and told not to invent. When no local model is reachable the guide degrades honestly into a retrieval report."
      />
      <OracleConsole
        personas={personas.map((p) => ({
          slug: p.slug,
          name: p.name,
          focus: p.focus,
          capabilities: p.capabilities,
        }))}
      />
    </div>
  );
}
