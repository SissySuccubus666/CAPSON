import { LabelBadge, PageHeader } from "@/components/ui";
import { getTimeline } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function TimelinePage() {
  const events = await getTimeline();
  const eras = new Map<string, typeof events>();
  events.forEach((event) => {
    const era =
      event.yearStart < 0
        ? "Antiquity (before 1 CE)"
        : event.yearStart < 1500
          ? "Antiquity to Renaissance (1 – 1500)"
          : event.yearStart < 1800
            ? "Early Modern (1500 – 1800)"
            : "Modern (1800 – )";
    const list = eras.get(era) ?? [];
    list.push(event);
    eras.set(era, list);
  });

  return (
    <div>
      <PageHeader
        eyebrow="version 0.4 — the web"
        title="Timeline of the Literature"
        lead="Manuscripts, printings, figures and movements, ordered by the year the evidence actually begins. Later re-readings are dated to when they were written, not to the period they describe."
      />

      <div className="space-y-10">
        {[...eras.entries()].map(([era, rows]) => (
          <section key={era}>
            <h2 className="smallcaps mb-4 text-lg text-brass-300">{era}</h2>
            <ol className="panel divide-y divide-brass-500/10">
              {rows.map((event) => (
                <li key={event.id} className="grid gap-2 p-4 sm:grid-cols-[130px_minmax(0,1fr)]">
                  <div>
                    <p className="mono text-sm text-brass-400">
                      {event.yearStart < 0 ? `${Math.abs(event.yearStart)} BCE` : event.yearStart}
                      {event.yearEnd ? ` – ${event.yearEnd}` : ""}
                    </p>
                    <p className="mono mt-1 text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">{event.kind}</p>
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-[16px]">{event.title}</h3>
                      <LabelBadge label={event.label} />
                    </div>
                    <p className="mt-1 text-sm leading-relaxed text-parchment-200/70">{event.description}</p>
                    {event.traditionKey ? (
                      <p className="mono mt-2 text-[10px] uppercase tracking-[0.18em] text-brass-500/70">
                        {event.traditionKey.replace(/-/g, " ")}
                      </p>
                    ) : null}
                  </div>
                </li>
              ))}
            </ol>
          </section>
        ))}
      </div>
    </div>
  );
}
