import { PageHeader } from "@/components/ui";

export const metadata = { title: "CLI — The Digital Grimoire" };

const COMMANDS: { cmd: string; out: string }[] = [
  {
    cmd: "grimoire search hermeticism",
    out: `47 documents\n12 entities\n8 symbols\n6 traditions\n23 references`,
  },
  {
    cmd: 'grimoire entity Hermes',
    out: `ENTITY  Hermes Trismegistus\nLABEL   PRIMARY SOURCE\nCONF    HIGH\nSEE     /entities/hermes-trismegistus`,
  },
  {
    cmd: 'grimoire source "Corpus Hermeticum"',
    out: `corpus-hermeticum · treatise · Greek · c. 100-300 CE\ntranslator: Ficino (1463); English after Mead (1906)\npassages: 3`,
  },
  {
    cmd: 'grimoire ask "What is the historical relationship between Hermeticism and alchemy?"',
    out: `[archivist] 6 passages retrieved · confidence MEDIUM\n[1] Corpus Hermeticum I.15 …\n[2] Tabula Smaragdina …`,
  },
  {
    cmd: "grimoire graph Hermeticism",
    out: `18 nodes · 22 edges (two-hop)\ntradition:hermeticism → entity:hermes-trismegistus\ntradition:hermeticism → tradition:alchemy`,
  },
  {
    cmd: "grimoire create my-grimoire.grim",
    out: `wrote my-grimoire.grim (template, 0 entries)`,
  },
  {
    cmd: "grimoire import document.pdf",
    out: `extracted 42 passages · metadata form opened · label: PRIMARY SOURCE`,
  },
];

const DIRS = `~/.local/share/digital-grimoire/
├── database/          grimoire.db (SQLite in the native build)
├── documents/         historical/ hermetic/ alchemy/ mythology/ modern/
├── grimoires/         personal/ imported/
├── embeddings/        local sentence-transformer caches
└── exports/           *.grim

~/.config/digital-grimoire/   config.toml
~/.cache/digital-grimoire/    index + derived caches`;

export default function CliPage() {
  return (
    <div>
      <PageHeader
        eyebrow="linux-first"
        title="Terminal Interface"
        lead="The same archive is exposed over the HTTP API that powers this interface, so a shell client is a thin wrapper. The reference CLI lives in bin/grimoire.mjs and speaks to a local server — no cloud, no account."
      />

      <section className="panel mb-8 p-5">
        <h2 className="smallcaps mb-3 text-base text-brass-300">Setup</h2>
        <pre className="mono overflow-x-auto rounded-sm border border-brass-500/20 bg-ink-900/70 p-4 text-[12px] leading-relaxed text-parchment-200/85">{`# Debian / Ubuntu / Mint
sudo apt install nodejs npm postgresql

# Fedora
sudo dnf install nodejs postgresql-server

# Arch
sudo pacman -S nodejs postgresql

npm install && npm run build && npm start &

# optional local model
curl -fsSL https://ollama.com/install.sh | sh
ollama pull llama3.2
export OLLAMA_URL=http://127.0.0.1:11434
export OLLAMA_MODEL=llama3.2

# the shell client
chmod +x bin/grimoire.mjs
./bin/grimoire.mjs search hermeticism`}</pre>
      </section>

      <section className="mb-8">
        <h2 className="smallcaps mb-3 text-lg text-brass-300">Commands</h2>
        <div className="space-y-3">
          {COMMANDS.map((row) => (
            <div key={row.cmd} className="panel p-4">
              <p className="mono text-brass-300">$ {row.cmd}</p>
              <pre className="mono mt-2 whitespace-pre-wrap text-[12px] leading-relaxed text-parchment-200/70">
                {row.out}
              </pre>
            </div>
          ))}
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="panel p-5">
          <h2 className="smallcaps mb-3 text-base text-brass-300">HTTP API (what the CLI calls)</h2>
          <ul className="mono space-y-1 text-[11px] leading-relaxed text-parchment-200/70">
            <li>GET /api/health</li>
            <li>GET /api/search?q=Hermes&amp;tradition=hermeticism</li>
            <li>GET /api/documents · GET /api/documents?slug=picatrix</li>
            <li>GET /api/entities · GET /api/entities?slug=paimon</li>
            <li>GET /api/correspondences?domain=planet&amp;key=Saturn</li>
            <li>GET /api/graph · GET /api/graph?focus=entity:lilith</li>
            <li>GET /api/timeline</li>
            <li>POST /api/ask &#123; question, persona &#125;</li>
            <li>GET|POST /api/notes</li>
            <li>GET|POST /api/grimoires · GET|PATCH|DELETE /api/grimoires/:slug</li>
            <li>POST /api/grimoires/:slug/entries · GET /api/grimoires/:slug/export</li>
            <li>POST /api/grim (validate | import) · GET /api/grim (template)</li>
          </ul>
        </div>

        <div className="panel p-5">
          <h2 className="smallcaps mb-3 text-base text-brass-300">Data directories</h2>
          <pre className="mono overflow-x-auto whitespace-pre text-[11px] leading-relaxed text-parchment-200/70">
            {DIRS}
          </pre>
          <p className="mt-3 text-xs leading-relaxed text-parchment-200/55">
            In this hosted build the corpus runs on PostgreSQL; the native local build targets SQLite at the same paths
            and the same schema. Nothing requires an internet connection once the corpus is present.
          </p>
        </div>
      </section>
    </div>
  );
}
