import Link from "next/link";
import { notFound } from "next/navigation";

import { NoteForm } from "@/components/note-form";
import { ConfidenceBadge, Field, LabelBadge, PageHeader } from "@/components/ui";
import { getDocument } from "@/lib/queries";
import { labelSpec } from "@/lib/labels";

export const dynamic = "force-dynamic";

export default async function DocumentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await getDocument(slug);
  if (!result) notFound();
  const { document: doc, passages, notes, edges } = result;

  const neighbours = edges.map((edge) => {
    const isFrom = edge.fromKey === `document:${slug}`;
    const key = isFrom ? edge.toKey : edge.fromKey;
    const [kind, neighbourSlug] = key.split(":");
    return { key, kind, neighbourSlug, predicate: isFrom ? edge.predicate : `← ${edge.predicate}`, label: edge.label };
  });

  return (
    <div>
      <PageHeader eyebrow={doc.docType} title={doc.title} lead={doc.summary}>
        <div className="flex flex-wrap items-center gap-2">
          <LabelBadge label={doc.label} title />
          <span className="mono text-[11px] uppercase tracking-[0.2em] text-parchment-200/45">{doc.historicalPeriod}</span>
          {doc.traditionSlug ? (
            <Link
              href={`/library?tradition=${doc.traditionSlug}`}
              className="mono rounded-sm border border-brass-500/25 px-2 py-0.5 text-[10px] uppercase tracking-wider text-brass-300 no-underline"
            >
              {doc.tradition}
            </Link>
          ) : null}
        </div>
      </PageHeader>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <h2 className="smallcaps mb-4 text-lg text-brass-300">Retrieved passages</h2>
          <div className="space-y-4">
            {passages.map((passage) => (
              <article key={passage.id} className="panel-parchment p-5">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <p className="mono text-[11px] uppercase tracking-[0.18em] text-brass-500/80">
                    {passage.locator}
                    {passage.heading ? ` — ${passage.heading}` : ""}
                  </p>
                  <LabelBadge label={passage.label} />
                </div>
                <p className="text-[15px] leading-[1.75] text-parchment-100/90">{passage.text}</p>
                {passage.keywords.length > 0 ? (
                  <p className="mono mt-3 text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">
                    index terms: {passage.keywords.join(" · ")}
                  </p>
                ) : null}
              </article>
            ))}
            {passages.length === 0 ? (
              <p className="panel p-5 text-sm text-parchment-200/60">
                No passages ingested for this record yet. Use the CLI (<span className="mono">grimoire import</span>) to
                add a PDF, TXT, EPUB, HTML or Markdown file.
              </p>
            ) : null}
          </div>

          <div className="mt-10">
            <h2 className="smallcaps mb-4 text-lg text-brass-300">Your notes</h2>
            <div className="space-y-3">
              {notes.map((note) => (
                <article key={note.id} className="panel p-4">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <h3 className="text-[15px]">{note.title}</h3>
                    <LabelBadge label={note.label} />
                  </div>
                  <p className="whitespace-pre-wrap text-sm leading-relaxed text-parchment-200/75">{note.body}</p>
                  <p className="mono mt-2 text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">
                    {new Date(note.createdAt).toISOString().slice(0, 16).replace("T", " ")}
                  </p>
                </article>
              ))}
              {notes.length === 0 ? (
                <p className="panel p-4 text-sm text-parchment-200/55">No notes on this document yet.</p>
              ) : null}
            </div>
            <div className="mt-4">
              <NoteForm documentSlug={slug} />
            </div>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="panel p-4">
            <h3 className="smallcaps mb-3 text-sm text-brass-300">Metadata</h3>
            <dl>
              <Field label="Original title" value={doc.originalTitle} />
              <Field label="Attribution" value={doc.attribution} />
              <Field label="Author record" value={doc.authorName ? `${doc.authorName}${doc.authorFlourished ? ` (${doc.authorFlourished})` : ""}` : null} />
              <Field label="Date created" value={doc.dateCreated} />
              <Field label="Region" value={doc.region} />
              <Field label="Language" value={doc.language} />
              <Field label="Translator" value={doc.translator} />
              <Field label="Edition" value={doc.edition} />
              <Field label="Historical period" value={doc.historicalPeriod} />
              <Field label="Copyright" value={doc.copyrightStatus} />
              <Field label="Source record" value={doc.sourceTitle} />
            </dl>
            {doc.sourceUrl ? (
              <a
                href={doc.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="link-brass mono mt-3 inline-block text-[11px] uppercase tracking-[0.2em]"
              >
                open source record ↗
              </a>
            ) : null}
          </div>

          <div className="panel p-4">
            <h3 className="smallcaps mb-3 text-sm text-brass-300">In the graph</h3>
            {neighbours.length > 0 ? (
              <ul className="space-y-2">
                {neighbours.map((n) => (
                  <li key={n.key} className="text-sm">
                    <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
                      {n.predicate}
                    </span>
                    <br />
                    {n.kind === "entity" ? (
                      <Link href={`/entities/${n.neighbourSlug}`} className="link-brass">
                        {n.neighbourSlug.replace(/-/g, " ")}
                      </Link>
                    ) : n.kind === "tradition" ? (
                      <Link href={`/library?tradition=${n.neighbourSlug}`} className="link-brass">
                        {n.neighbourSlug.replace(/-/g, " ")}
                      </Link>
                    ) : (
                      <span className="text-parchment-200/70">{n.neighbourSlug.replace(/-/g, " ")}</span>
                    )}
                    <span className="ml-2 align-middle">
                      <LabelBadge label={n.label} />
                    </span>
                  </li>
                ))}
            </ul>
            ) : (
              <p className="text-sm text-parchment-200/55">No graph edges recorded.</p>
            )}
            <Link
              href={`/graph?focus=document:${slug}`}
              className="link-brass mono mt-3 inline-block text-[11px] uppercase tracking-[0.2em]"
            >
              view in graph →
            </Link>
          </div>

          <div className="panel p-4">
            <h3 className="smallcaps mb-2 text-sm text-brass-300">Reading this record</h3>
            <p className="text-xs leading-relaxed text-parchment-200/60">{labelSpec(doc.label).description}</p>
            <div className="mt-3 flex items-center gap-2">
              <ConfidenceBadge level={doc.label === "PRIMARY SOURCE" ? "HIGH" : doc.label === "SECONDARY SOURCE" ? "MEDIUM" : "LOW"} />
              <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">
                derived from label
              </span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
