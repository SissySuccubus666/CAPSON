import Link from "next/link";

import { LabelBadge, PageHeader } from "@/components/ui";
import { getLibraryFacets, listDocuments } from "@/lib/queries";

export const dynamic = "force-dynamic";

type Search = Promise<Record<string, string | string[] | undefined>>;

function first(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) return value[0];
  return value || undefined;
}

export default async function LibraryPage({ searchParams }: { searchParams: Search }) {
  const params = await searchParams;
  const filters = {
    q: first(params.q),
    tradition: first(params.tradition),
    language: first(params.language),
    docType: first(params.docType),
    label: first(params.label),
    period: first(params.period),
  };
  const [docs, facets] = await Promise.all([listDocuments(filters), getLibraryFacets()]);
  const activeFilters = Object.entries(filters).filter(([, v]) => v);

  return (
    <div>
      <PageHeader
        eyebrow="version 0.1 — the archive"
        title="The Digital Library"
        lead="Public-domain and legally reproducible material only. Each document records its attribution, date, language, translator, edition and copyright status separately, so a 1911 English translation is never mistaken for a 14th-century Latin manuscript."
      />

      <form className="panel mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-7" method="get">
        <input
          name="q"
          defaultValue={filters.q ?? ""}
          placeholder="title, attribution, summary…"
          className="lg:col-span-2"
          aria-label="search library"
        />
        <select name="tradition" defaultValue={filters.tradition ?? ""} aria-label="tradition">
          <option value="">tradition — all</option>
          {facets.traditions.map((t) => (
            <option key={t.slug} value={t.slug}>
              {t.name}
            </option>
          ))}
        </select>
        <select name="language" defaultValue={filters.language ?? ""} aria-label="language">
          <option value="">language — all</option>
          {facets.languages.map((l) => (
            <option key={l.value ?? "unknown"} value={l.value ?? ""}>
              {l.value ?? "unrecorded"} ({l.n})
            </option>
          ))}
        </select>
        <select name="docType" defaultValue={filters.docType ?? ""} aria-label="document type">
          <option value="">type — all</option>
          {facets.docTypes.map((t) => (
            <option key={t.value} value={t.value}>
              {t.value} ({t.n})
            </option>
          ))}
        </select>
        <select name="period" defaultValue={filters.period ?? ""} aria-label="period">
          <option value="">period — all</option>
          {facets.periods.map((p) => (
            <option key={p.value ?? "unknown"} value={p.value ?? ""}>
              {p.value ?? "unrecorded"} ({p.n})
            </option>
          ))}
        </select>
        <select name="label" defaultValue={filters.label ?? ""} aria-label="integrity label">
          <option value="">label — all</option>
          <option value="PRIMARY SOURCE">PRIMARY SOURCE</option>
          <option value="SECONDARY SOURCE">SECONDARY SOURCE</option>
          <option value="MODERN OCCULT INTERPRETATION">MODERN OCCULT INTERPRETATION</option>
        </select>
        <div className="flex gap-2 sm:col-span-2 lg:col-span-7">
          <button
            type="submit"
            className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200"
          >
            filter
          </button>
          <Link
            href="/library"
            className="rounded-sm border border-brass-500/25 px-4 py-1.5 text-sm text-parchment-200/70 no-underline"
          >
            reset
          </Link>
          <span className="mono ml-auto self-center text-[11px] uppercase tracking-[0.2em] text-parchment-200/40">
            {docs.length} documents {activeFilters.length ? `· ${activeFilters.length} filters` : ""}
          </span>
        </div>
      </form>

      <div className="grid gap-3">
        {docs.map((doc) => (
          <article key={doc.slug} className="panel p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <Link href={`/library/${doc.slug}`} className="link-brass text-xl">
                  {doc.title}
                </Link>
                {doc.originalTitle ? (
                  <p className="mt-1 text-sm italic text-parchment-200/55">{doc.originalTitle}</p>
                ) : null}
              </div>
              <div className="flex items-center gap-2">
                <LabelBadge label={doc.label} />
                <span className="mono rounded-sm border border-brass-500/20 px-1.5 py-0.5 text-[10px] uppercase tracking-wider text-parchment-200/60">
                  {doc.docType}
                </span>
              </div>
            </div>

            <p className="mono mt-3 text-[11px] uppercase tracking-[0.15em] text-brass-500/70">
              {doc.dateCreated} · {doc.language} · {doc.region} · {doc.tradition ?? "unassigned"}
            </p>
            <p className="mt-2 text-sm leading-relaxed text-parchment-200/70">{doc.summary}</p>
            <p className="mt-3 text-xs leading-relaxed text-parchment-200/50">
              <span className="text-brass-500/80">Attribution:</span> {doc.attribution}
              {doc.translator ? <><span className="text-brass-500/80"> · Translator:</span> {doc.translator}</> : null}
              <span className="text-brass-500/80"> · Rights:</span> {doc.copyrightStatus}
            </p>
          </article>
        ))}
        {docs.length === 0 ? (
          <p className="panel p-6 text-sm text-parchment-200/60">
            Nothing matches those filters. The archive is deliberately small and honest about what it does not hold.
          </p>
        ) : null}
      </div>
    </div>
  );
}
