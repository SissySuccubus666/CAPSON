import Link from "next/link";

import { Field, LabelBadge, PageHeader, Stat } from "@/components/ui";
import { getStats, getTimeline, listDocuments, listTraditions } from "@/lib/queries";
import { LABELS } from "@/lib/labels";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [stats, docs, timeline, traditions] = await Promise.all([
    getStats(),
    listDocuments(),
    getTimeline(),
    listTraditions(),
  ]);

  const featured = docs.slice(0, 6);
  const upcoming = timeline.slice(0, 5);

  return (
    <div>
      <section className="panel sigil-bg mb-10 overflow-hidden p-8 sm:p-12">
        <p className="mono text-[11px] uppercase tracking-[0.35em] text-brass-500/80">
          🜏 archive · ai guide · knowledge graph
        </p>
        <h1 className="mt-4 max-w-4xl text-4xl leading-[1.1] sm:text-5xl">
          A programmable digital library of esoteric knowledge
        </h1>
        <p className="mt-5 max-w-3xl text-[15px] leading-relaxed text-parchment-200/75">
          Move from historical texts → entities → symbols → traditions → relationships → interpretations → your own
          grimoires. The AI is a librarian that must cite the archive; it is never treated as an authority. Every
          record is labelled so that a Hellenistic dialogue, a Victorian translation and a 1970s re-reading are never
          mistaken for one another.
        </p>
        <div className="mt-7 flex flex-wrap gap-3">
          <Link
            href="/search"
            className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-2 text-sm text-brass-200 no-underline transition hover:bg-brass-500/25"
          >
            Search the archive
          </Link>
          <Link
            href="/oracle"
            className="rounded-sm border border-brass-500/30 px-4 py-2 text-sm text-parchment-100 no-underline transition hover:border-brass-500/60"
          >
            Consult the Oracle
          </Link>
          <Link
            href="/graph"
            className="rounded-sm border border-brass-500/30 px-4 py-2 text-sm text-parchment-100 no-underline transition hover:border-brass-500/60"
          >
            Walk the graph
          </Link>
        </div>
      </section>

      <div className="mb-12 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
        <Stat value={stats.documents} label="documents" href="/library" />
        <Stat value={stats.entities} label="entities" href="/entities" />
        <Stat value={stats.symbols} label="symbols" href="/symbols" />
        <Stat value={stats.correspondences} label="correspondences" href="/symbols" />
        <Stat value={stats.traditions} label="traditions" href="/library" />
        <Stat value={stats.relations} label="graph edges" href="/graph" />
        <Stat value={stats.timeline} label="timeline events" href="/timeline" />
        <Stat value={stats.grimoires} label="your grimoires" href="/workshop" />
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <section className="lg:col-span-2">
          <h2 className="smallcaps mb-4 text-lg text-brass-300">From the archive</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {featured.map((doc) => (
              <Link key={doc.slug} href={`/library/${doc.slug}`} className="panel block p-4 no-underline transition hover:border-brass-500/40">
                <div className="mb-2 flex items-start justify-between gap-3">
                  <h3 className="text-[17px] leading-snug">{doc.title}</h3>
                  <LabelBadge label={doc.label} />
                </div>
                <p className="mono text-[10px] uppercase tracking-[0.18em] text-brass-500/70">
                  {doc.dateCreated} · {doc.language} · {doc.tradition ?? "unassigned"}
                </p>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-parchment-200/65">{doc.summary}</p>
              </Link>
            ))}
          </div>
        </section>

        <aside className="space-y-8">
          <div>
            <h2 className="smallcaps mb-4 text-lg text-brass-300">Source integrity</h2>
            <div className="panel p-4">
              <ul className="space-y-3">
                {Object.values(LABELS).map((spec) => (
                  <li key={spec.key}>
                    <div className="mb-1 flex items-center gap-2">
                      <LabelBadge label={spec.key} title />
                    </div>
                    <p className="text-xs leading-relaxed text-parchment-200/60">{spec.description}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h2 className="smallcaps mb-4 text-lg text-brass-300">Chronology</h2>
            <div className="panel divide-y divide-brass-500/10">
              {upcoming.map((event) => (
                <div key={event.id} className="p-3">
                  <p className="mono text-[11px] text-brass-500/80">
                    {event.yearStart < 0 ? `${Math.abs(event.yearStart)} BCE` : event.yearStart}
                  </p>
                  <p className="text-sm text-parchment-100">{event.title}</p>
                  <p className="mt-1 text-xs leading-relaxed text-parchment-200/55">{event.description}</p>
                </div>
              ))}
            </div>
            <Link href="/timeline" className="link-brass mono mt-3 inline-block text-[11px] uppercase tracking-[0.2em]">
              full timeline →
            </Link>
          </div>

          <div>
            <h2 className="smallcaps mb-4 text-lg text-brass-300">Traditions held</h2>
            <div className="panel p-4">
              <dl>
                {traditions.slice(0, 5).map((tradition) => (
                  <Field key={tradition.id} label={tradition.name} value={tradition.summary} />
                ))}
              </dl>
              <Link href="/library" className="link-brass mono mt-3 inline-block text-[11px] uppercase tracking-[0.2em]">
                browse all traditions →
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
