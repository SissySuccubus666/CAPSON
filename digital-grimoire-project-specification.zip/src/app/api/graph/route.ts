import { getGraph } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const focus = url.searchParams.get("focus") ?? undefined;
  const graph = await getGraph(focus ?? undefined);
  return Response.json(graph);
}
