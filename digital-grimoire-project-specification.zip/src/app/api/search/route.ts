import { searchAll } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = url.searchParams.get("q") ?? "";
  const results = await searchAll(q, {
    tradition: url.searchParams.get("tradition") ?? undefined,
    language: url.searchParams.get("language") ?? undefined,
    docType: url.searchParams.get("docType") ?? undefined,
    label: url.searchParams.get("label") ?? undefined,
    period: url.searchParams.get("period") ?? undefined,
  });
  return Response.json(results);
}
