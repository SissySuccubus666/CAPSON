import { getTimeline } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  const events = await getTimeline();
  return Response.json({ count: events.length, events });
}
