import { getDocument, listDocuments } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const slug = url.searchParams.get("slug");
  if (slug) {
    const result = await getDocument(slug);
    if (!result) return Response.json({ error: "document not found" }, { status: 404 });
    return Response.json(result);
  }
  const docs = await listDocuments({
    q: url.searchParams.get("q") ?? undefined,
    tradition: url.searchParams.get("tradition") ?? undefined,
    language: url.searchParams.get("language") ?? undefined,
    docType: url.searchParams.get("docType") ?? undefined,
    label: url.searchParams.get("label") ?? undefined,
    period: url.searchParams.get("period") ?? undefined,
  });
  return Response.json({ count: docs.length, documents: docs });
}
