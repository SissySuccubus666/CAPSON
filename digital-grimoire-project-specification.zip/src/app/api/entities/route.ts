import { getEntity, listEntities } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const slug = url.searchParams.get("slug");
  if (slug) {
    const result = await getEntity(slug);
    if (!result) return Response.json({ error: "entity not found" }, { status: 404 });
    return Response.json(result);
  }
  const rows = await listEntities({
    q: url.searchParams.get("q") ?? undefined,
    kind: url.searchParams.get("kind") ?? undefined,
    tradition: url.searchParams.get("tradition") ?? undefined,
  });
  return Response.json({ count: rows.length, entities: rows });
}
