import { listCorrespondences } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const rows = await listCorrespondences({
    domain: url.searchParams.get("domain") ?? undefined,
    key: url.searchParams.get("key") ?? undefined,
  });
  return Response.json({ count: rows.length, correspondences: rows });
}
