import { eq } from "drizzle-orm";

import { db } from "@/db";
import { customGrimoires, grimoireEntries } from "@/db/schema";
import { slugify, validateGrim } from "@/lib/grim";

export const dynamic = "force-dynamic";

/** Validate a .grim document without importing it. */
export async function POST(request: Request) {
  const body = (await request.json()) as { raw?: string; mode?: "validate" | "import" };
  const raw = body.raw ?? "";
  if (!raw.trim()) return Response.json({ error: "raw is required" }, { status: 400 });

  const validation = validateGrim(raw);
  if (body.mode !== "import") {
    return Response.json(validation);
  }
  if (!validation.ok || !validation.file) {
    return Response.json({ ...validation, imported: false }, { status: 422 });
  }

  const file = validation.file;
  const base = slugify(file.grimoire.name);
  const existing = await db.select({ slug: customGrimoires.slug }).from(customGrimoires);
  const taken = new Set(existing.map((e) => e.slug));
  let slug = base;
  let counter = 2;
  while (taken.has(slug)) {
    slug = `${base}-${counter}`;
    counter += 1;
  }

  const [grimoire] = await db
    .insert(customGrimoires)
    .values({
      slug,
      name: file.grimoire.name,
      author: file.grimoire.author ?? "User",
      tradition: file.grimoire.tradition ?? "Imported",
      description: `${file.grimoire.description ?? ""}\n\nImported from .grim on ${new Date().toISOString().slice(0, 10)}.`.trim(),
    })
    .returning();

  if (file.entries.length > 0) {
    await db.insert(grimoireEntries).values(
      file.entries.map((entry, index) => ({
        grimoireId: grimoire.id,
        entryType: entry.type,
        name: entry.name,
        body: entry.body ?? "",
        label: entry.label ?? "USER CREATED",
        meta: entry.meta ?? {},
        ordinal: index + 1,
      })),
    );
  }

  return Response.json({ ...validation, imported: true, grimoire }, { status: 201 });
}

/** A blank .grim template for the Workshop. */
export async function GET() {
  const template = `grimoire:
  name: "The Black Archive"
  author: "User"
  tradition: "Experimental"
  description: "What this grimoire is for."

entries:
  - type: entity
    name: "Example Entity"
    body: "What the sources actually say."
    label: "USER CREATED"
    meta:
      tradition: "Unclassified"
  - type: symbol
    name: "Example Symbol"
    label: "USER CREATED"
  - type: correspondence
    name: "Mercury / 8"
    label: "SECONDARY SOURCE"
    meta:
      planet: "Mercury"
      number: 8
  - type: text
    name: "Working text"
    body: "A passage you want to keep beside the entries."
    label: "PRIMARY SOURCE"
  - type: note
    name: "Working note"
    label: "USER CREATED"
  - type: reference
    name: "Example Source"
    label: "SECONDARY SOURCE"
    meta:
      author: "Example Author"
      date: "1900"

sources:
  - title: "Example Source"
    author: "Example Author"
    date: "1900"
    label: "SECONDARY SOURCE"
`;
  return new Response(template, { headers: { "content-type": "text/yaml; charset=utf-8" } });
}

export async function DELETE(request: Request) {
  const slug = new URL(request.url).searchParams.get("slug");
  if (!slug) return Response.json({ error: "slug is required" }, { status: 400 });
  const [row] = await db.select().from(customGrimoires).where(eq(customGrimoires.slug, slug)).limit(1);
  if (!row) return Response.json({ error: "grimoire not found" }, { status: 404 });
  await db.delete(grimoireEntries).where(eq(grimoireEntries.grimoireId, row.id));
  await db.delete(customGrimoires).where(eq(customGrimoires.id, row.id));
  return Response.json({ deleted: slug });
}
