import { db } from "@/db";
import { customGrimoires, grimoireEntries } from "@/db/schema";
import { slugify } from "@/lib/grim";
import { listGrimoires } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ grimoires: await listGrimoires() });
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    name?: string;
    author?: string;
    tradition?: string;
    description?: string;
  };
  if (!body.name?.trim()) {
    return Response.json({ error: "name is required" }, { status: 400 });
  }
  const base = slugify(body.name);
  const existing = await db.select({ slug: customGrimoires.slug }).from(customGrimoires);
  const taken = new Set(existing.map((e) => e.slug));
  let slug = base;
  let counter = 2;
  while (taken.has(slug)) {
    slug = `${base}-${counter}`;
    counter += 1;
  }

  const [grimoire] = await db
    .insert(customGrimoires)
    .values({
      slug,
      name: body.name.trim(),
      author: body.author?.trim() || "User",
      tradition: body.tradition?.trim() || "Unclassified",
      description: body.description?.trim() || "",
    })
    .returning();

  // Seed the new grimoire with a first entry so the builder is never empty.
  await db.insert(grimoireEntries).values({
    grimoireId: grimoire.id,
    entryType: "note",
    name: "Opening note",
    body: `Created in the Workshop. Record here what this grimoire is for, and label every entry you add.`,
    label: "USER CREATED",
    ordinal: 1,
  });

  return Response.json({ grimoire }, { status: 201 });
}
