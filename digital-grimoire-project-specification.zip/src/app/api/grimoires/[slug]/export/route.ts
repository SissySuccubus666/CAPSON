import { serialiseGrim, slugify } from "@/lib/grim";
import { getGrimoire } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await getGrimoire(slug);
  if (!result) return Response.json({ error: "grimoire not found" }, { status: 404 });

  const { grimoire, entries } = result;
  const grim = serialiseGrim({
    grimoire: {
      name: grimoire.name,
      author: grimoire.author,
      tradition: grimoire.tradition,
      description: grimoire.description,
    },
    entries: entries.map((entry) => ({
      type: entry.entryType as "entity",
      name: entry.name,
      body: entry.body,
      label: entry.label,
      meta: entry.meta ?? {},
    })),
    sources: entries
      .filter((entry) => entry.entryType === "reference")
      .map((entry) => ({
        title: entry.name,
        author: entry.meta?.author ? String(entry.meta.author) : undefined,
        date: entry.meta?.date ? String(entry.meta.date) : undefined,
        locator: entry.meta?.locator ? String(entry.meta.locator) : undefined,
        label: entry.label,
      })),
  });

  return new Response(grim, {
    headers: {
      "content-type": "text/yaml; charset=utf-8",
      "content-disposition": `attachment; filename="${slugify(grimoire.name)}.grim"`,
    },
  });
}
