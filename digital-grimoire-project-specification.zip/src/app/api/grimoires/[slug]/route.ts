import { eq } from "drizzle-orm";

import { db } from "@/db";
import { customGrimoires, grimoireEntries } from "@/db/schema";
import { getGrimoire } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await getGrimoire(slug);
  if (!result) return Response.json({ error: "grimoire not found" }, { status: 404 });
  return Response.json(result);
}

export async function PATCH(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const body = (await request.json()) as {
    name?: string;
    description?: string;
    tradition?: string;
    author?: string;
  };
  const [row] = await db
    .update(customGrimoires)
    .set({
      ...(body.name ? { name: body.name } : {}),
      ...(body.description !== undefined ? { description: body.description } : {}),
      ...(body.tradition !== undefined ? { tradition: body.tradition } : {}),
      ...(body.author !== undefined ? { author: body.author } : {}),
      updatedAt: new Date(),
    })
    .where(eq(customGrimoires.slug, slug))
    .returning();
  if (!row) return Response.json({ error: "grimoire not found" }, { status: 404 });
  return Response.json({ grimoire: row });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [row] = await db.select().from(customGrimoires).where(eq(customGrimoires.slug, slug)).limit(1);
  if (!row) return Response.json({ error: "grimoire not found" }, { status: 404 });
  await db.delete(grimoireEntries).where(eq(grimoireEntries.grimoireId, row.id));
  await db.delete(customGrimoires).where(eq(customGrimoires.id, row.id));
  return Response.json({ deleted: slug });
}
