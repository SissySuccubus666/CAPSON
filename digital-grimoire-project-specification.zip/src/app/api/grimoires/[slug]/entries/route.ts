import { and, eq, sql } from "drizzle-orm";

import { db } from "@/db";
import { customGrimoires, grimoireEntries } from "@/db/schema";
import { GRIM_ENTRY_TYPES, type GrimEntryType } from "@/lib/grim";

export const dynamic = "force-dynamic";

async function resolveGrimoire(slug: string) {
  const [row] = await db.select().from(customGrimoires).where(eq(customGrimoires.slug, slug)).limit(1);
  return row ?? null;
}

export async function POST(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const grimoire = await resolveGrimoire(slug);
  if (!grimoire) return Response.json({ error: "grimoire not found" }, { status: 404 });

  const body = (await request.json()) as {
    entryType?: string;
    name?: string;
    body?: string;
    label?: string;
    meta?: Record<string, string | number | null>;
  };
  const entryType = body.entryType as GrimEntryType | undefined;
  if (!entryType || !GRIM_ENTRY_TYPES.includes(entryType)) {
    return Response.json(
      { error: `entryType must be one of ${GRIM_ENTRY_TYPES.join(", ")}` },
      { status: 400 },
    );
  }
  if (!body.name?.trim()) {
    return Response.json({ error: "name is required" }, { status: 400 });
  }

  const [{ nextOrdinal }] = await db
    .select({ nextOrdinal: sql<number>`coalesce(max(${grimoireEntries.ordinal}), 0)::int + 1` })
    .from(grimoireEntries)
    .where(eq(grimoireEntries.grimoireId, grimoire.id));

  const [entry] = await db
    .insert(grimoireEntries)
    .values({
      grimoireId: grimoire.id,
      entryType,
      name: body.name.trim(),
      body: body.body?.trim() ?? "",
      label: body.label ?? "USER CREATED",
      meta: body.meta ?? {},
      ordinal: nextOrdinal,
    })
    .returning();

  await db
    .update(customGrimoires)
    .set({ updatedAt: new Date() })
    .where(eq(customGrimoires.id, grimoire.id));

  return Response.json({ entry }, { status: 201 });
}

export async function DELETE(request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const grimoire = await resolveGrimoire(slug);
  if (!grimoire) return Response.json({ error: "grimoire not found" }, { status: 404 });
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!Number.isFinite(id)) return Response.json({ error: "id is required" }, { status: 400 });
  await db
    .delete(grimoireEntries)
    .where(and(eq(grimoireEntries.grimoireId, grimoire.id), eq(grimoireEntries.id, id)));
  return Response.json({ deleted: id });
}
