import { db } from "@/db";
import { aiSessions } from "@/db/schema";
import { ask, ollamaAvailable, OLLAMA_MODEL, OLLAMA_URL } from "@/lib/ai";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    ollama: {
      url: OLLAMA_URL,
      model: OLLAMA_MODEL,
      reachable: await ollamaAvailable(),
    },
  });
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    question?: string;
    persona?: string;
    tradition?: string;
    record?: boolean;
  };
  const question = body.question?.trim();
  if (!question) {
    return Response.json({ error: "question is required" }, { status: 400 });
  }
  const persona = body.persona ?? "archivist";
  const result = await ask(question, persona, { tradition: body.tradition });

  await db.insert(aiSessions).values({
    personaSlug: result.persona,
    question: result.question,
    answer: result.answer,
    engine: result.engine,
    model: result.model,
    confidence: result.confidence,
    citations: result.citations,
  });

  return Response.json(result);
}
