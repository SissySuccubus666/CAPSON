import { createNote, listNotes } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ notes: await listNotes() });
}

export async function POST(request: Request) {
  const body = (await request.json()) as {
    title?: string;
    body?: string;
    documentSlug?: string | null;
    entitySlug?: string | null;
    label?: string;
  };
  if (!body.title?.trim() || !body.body?.trim()) {
    return Response.json({ error: "title and body are required" }, { status: 400 });
  }
  const note = await createNote({
    title: body.title.trim(),
    body: body.body.trim(),
    documentSlug: body.documentSlug ?? null,
    entitySlug: body.entitySlug ?? null,
    label: body.label ?? "USER CREATED",
  });
  return Response.json({ note }, { status: 201 });
}
