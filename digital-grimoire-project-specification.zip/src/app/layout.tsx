import type { Metadata } from "next";
import type { ReactNode } from "react";

import { SiteNav } from "@/components/site-nav";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Digital Grimoire — occult knowledge & AI research platform",
  description:
    "A local-first, source-aware archive of grimoires, entities, symbols and correspondences, with a knowledge graph and a retrieval-guided AI librarian.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">
        <div className="min-h-screen">
          <SiteNav />
          <main className="mx-auto w-full max-w-7xl px-5 pb-24 pt-8 sm:px-8">{children}</main>
          <footer className="border-t border-brass-500/15 px-5 py-8 sm:px-8">
            <div className="mx-auto flex max-w-7xl flex-col gap-2 text-xs text-parchment-200/50 sm:flex-row sm:items-center sm:justify-between">
              <p className="mono">
                🜏 THE DIGITAL GRIMOIRE · local-first · Linux-first · source-aware
              </p>
              <p className="mono">
                every claim carries a label: PRIMARY · SECONDARY · SCHOLARLY · MODERN OCCULT · USER · FICTIONAL ·
                UNCERTAIN
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
