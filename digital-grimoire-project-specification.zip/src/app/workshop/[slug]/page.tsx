import Link from "next/link";
import { notFound } from "next/navigation";

import { GrimoireBuilder } from "@/components/grimoire-builder";
import { PageHeader } from "@/components/ui";
import { getGrimoire } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function GrimoirePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await getGrimoire(slug);
  if (!result) notFound();
  const { grimoire, entries } = result;

  return (
    <div>
      <PageHeader eyebrow={`workshop · ${grimoire.tradition}`} title={grimoire.name} lead={grimoire.description}>
        <Link href="/workshop" className="link-brass mono text-[11px] uppercase tracking-[0.2em]">
          ← all grimoires
        </Link>
      </PageHeader>
      <GrimoireBuilder
        grimoire={{
          id: grimoire.id,
          slug: grimoire.slug,
          name: grimoire.name,
          author: grimoire.author,
          tradition: grimoire.tradition,
          description: grimoire.description,
        }}
        entries={entries.map((entry) => ({
          id: entry.id,
          entryType: entry.entryType,
          name: entry.name,
          body: entry.body,
          label: entry.label,
          meta: entry.meta ?? null,
          ordinal: entry.ordinal,
        }))}
      />
    </div>
  );
}
