import { WorkshopConsole } from "@/components/workshop-console";
import { PageHeader } from "@/components/ui";
import { listGrimoires } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function WorkshopPage() {
  const grimoires = await listGrimoires();
  return (
    <div>
      <PageHeader
        eyebrow="version 0.5 — the workshop"
        title="Custom Grimoire Builder"
        lead="Build your own codex from entities, symbols, correspondences, texts, notes, illustrations and references. Export it as a .grim file, validate someone else's .grim file, and import it back. Everything you write is labelled USER CREATED unless you say otherwise."
      />
      <WorkshopConsole grimoires={grimoires.map((g) => ({ slug: g.slug, name: g.name, entryCount: g.entryCount }))} />
    </div>
  );
}
