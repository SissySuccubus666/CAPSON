import { SearchPanel } from "@/components/search-panel";
import { PageHeader } from "@/components/ui";
import { getLibraryFacets } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function SearchPage() {
  const facets = await getLibraryFacets();
  return (
    <div>
      <PageHeader
        eyebrow="version 0.2 — the librarian"
        title="Search the archive"
        lead="One query across documents, passages, entities, symbols, traditions and correspondence tables. The ranker is a transparent lexical BM25 run locally against the database — no external service, no tracking, works offline."
      />
      <SearchPanel
        traditions={facets.traditions.map((t) => ({ value: t.slug, label: t.name }))}
        languages={facets.languages.map((l) => ({ value: l.value ?? "", label: l.value ?? "unrecorded" }))}
      />
    </div>
  );
}
