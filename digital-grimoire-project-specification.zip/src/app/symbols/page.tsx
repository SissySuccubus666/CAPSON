import Link from "next/link";

import { ConfidenceBadge, LabelBadge, PageHeader } from "@/components/ui";
import { listCorrespondences, listSymbols } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function SymbolsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const pick = (key: string) => {
    const value = params[key];
    return Array.isArray(value) ? value[0] : (value || undefined);
  };
  const [symbols, correspondences] = await Promise.all([
    listSymbols({ q: pick("q"), category: pick("category") }),
    listCorrespondences({ domain: pick("domain") }),
  ]);

  const domains = ["planet", "sephira", "element", "number", "metal"];
  const grouped = new Map<string, typeof correspondences>();
  correspondences.forEach((row) => {
    const list = grouped.get(row.key) ?? [];
    list.push(row);
    grouped.set(row.key, list);
  });

  return (
    <div>
      <PageHeader
        eyebrow="symbolism & correspondences"
        title="Symbols and Correspondence Tables"
        lead="The tables reproduce attributions actually printed in the sources named beside them — Agrippa's De occulta philosophia II.10, the Arbatel's Olympic spirits, Sefer Yetzirah, the Clavicula's planetary hours. Where an attribution is modern it is labelled modern."
      />

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <section>
          <form className="panel mb-4 grid gap-3 p-4 sm:grid-cols-3" method="get">
            <input name="q" defaultValue={pick("q") ?? ""} placeholder="symbol, meaning, usage…" aria-label="search symbols" />
            <select name="category" defaultValue={pick("category") ?? ""} aria-label="category">
              <option value="">category — all</option>
              {["geometric", "ritual", "sigil", "emblem", "alchemical", "diagram", "textual", "astral"].map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
            <button type="submit" className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200">
              filter
            </button>
          </form>

          <div className="space-y-3">
            {symbols.map((symbol) => (
              <article key={symbol.slug} className="panel p-4">
                <div className="flex items-start gap-3">
                  <span className="grid size-10 shrink-0 place-items-center rounded-sm border border-brass-500/30 text-lg text-brass-300">
                    {symbol.glyph}
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-[17px]">{symbol.name}</h3>
                      <LabelBadge label={symbol.label} />
                      <ConfidenceBadge level={symbol.confidence} />
                    </div>
                    <p className="mono mt-1 text-[10px] uppercase tracking-[0.18em] text-brass-500/70">
                      {symbol.category} · {symbol.tradition ?? "unassigned"} · first attested {symbol.firstAttested}
                    </p>
                    <p className="mt-2 text-sm leading-relaxed text-parchment-200/75">{symbol.meaning}</p>
                    <p className="mt-2 text-xs leading-relaxed text-parchment-200/55">
                      <span className="text-brass-500/80">Use:</span> {symbol.usage}
                    </p>
                  </div>
                </div>
              </article>
            ))}
            {symbols.length === 0 ? (
              <p className="panel p-4 text-sm text-parchment-200/55">No symbols match.</p>
            ) : null}
          </div>
        </section>

        <section>
          <form className="panel mb-4 flex flex-wrap gap-2 p-4" method="get">
            <span className="mono self-center text-[10px] uppercase tracking-[0.2em] text-parchment-200/40">domain:</span>
            <Link
              href="/symbols"
              className={`mono rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-wider no-underline ${
                pick("domain") ? "border-brass-500/20 text-parchment-200/60" : "border-brass-500/50 bg-brass-500/15 text-brass-200"
              }`}
            >
              all
            </Link>
            {domains.map((d) => (
              <Link
                key={d}
                href={`/symbols?domain=${d}`}
                className={`mono rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-wider no-underline ${
                  pick("domain") === d
                    ? "border-brass-500/50 bg-brass-500/15 text-brass-200"
                    : "border-brass-500/20 text-parchment-200/60"
                }`}
              >
                {d}
              </Link>
            ))}
          </form>

          <div className="space-y-4">
            {[...grouped.entries()].map(([key, rows]) => (
              <div key={key} className="panel p-4">
                <h3 className="text-[15px] text-parchment-100">{key}</h3>
                <table className="mt-2 w-full text-left text-sm">
                  <tbody>
                    {rows.map((row) => (
                      <tr key={row.id} className="border-t border-brass-500/10">
                        <td className="py-1.5 pr-2 align-top text-parchment-200/60">{row.attribute}</td>
                        <td className="py-1.5 pr-2 align-top text-parchment-100">{row.value}</td>
                        <td className="mono py-1.5 align-top text-[10px] uppercase tracking-wider text-parchment-200/40">
                          {row.sourceRef}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
            {correspondences.length === 0 ? (
              <p className="panel p-4 text-sm text-parchment-200/55">No correspondence rows for this domain.</p>
            ) : null}
          </div>
        </section>
      </div>
    </div>
  );
}
