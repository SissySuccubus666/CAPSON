import Link from "next/link";
import { notFound } from "next/navigation";

import { NoteForm } from "@/components/note-form";
import { ConfidenceBadge, Field, LabelBadge, PageHeader } from "@/components/ui";
import { getEntity } from "@/lib/queries";
import { CONFIDENCE_NOTE, labelSpec } from "@/lib/labels";

export const dynamic = "force-dynamic";

export default async function EntityPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await getEntity(slug);
  if (!result) notFound();
  const { entity, tradition, edges, correspondences } = result;

  const neighbours = edges.map((edge) => {
    const isFrom = edge.fromKey === `entity:${slug}`;
    const key = isFrom ? edge.toKey : edge.fromKey;
    const [kind, neighbourSlug] = key.split(":");
    return {
      key,
      kind,
      neighbourSlug,
      predicate: isFrom ? edge.predicate : `← ${edge.predicate}`,
      label: edge.label,
    };
  });

  const chips = (values: (string | number)[]) =>
    values.length > 0 ? (
      <div className="flex flex-wrap gap-2">
        {values.map((v) => (
          <span
            key={String(v)}
            className="mono rounded-sm border border-brass-500/25 px-2 py-0.5 text-[10px] uppercase tracking-wider text-parchment-200/70"
          >
            {v}
          </span>
        ))}
      </div>
    ) : null;

  return (
    <div>
      <PageHeader eyebrow={entity.kind} title={entity.name} lead={entity.symbolism}>
        <div className="flex flex-wrap items-center gap-2">
          <LabelBadge label={entity.label} title />
          <ConfidenceBadge level={entity.confidence} />
          {tradition ? (
            <Link href={`/entities?tradition=${tradition.slug}`} className="mono text-[11px] uppercase tracking-[0.2em] text-brass-300 no-underline">
              {tradition.name}
            </Link>
          ) : null}
          <span className="mono text-[11px] uppercase tracking-[0.2em] text-parchment-200/40">
            {entity.historicalPeriod}
          </span>
        </div>
      </PageHeader>

      {entity.confidence === "LOW" ? (
        <div className="panel mb-8 border-rose-500/40 p-4">
          <p className="mono text-[11px] uppercase tracking-[0.2em] text-rose-300">confidence: low</p>
          <p className="mt-2 text-sm leading-relaxed text-parchment-200/75">{CONFIDENCE_NOTE.LOW}</p>
        </div>
      ) : null}

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_330px]">
        <div className="space-y-6">
          <section className="panel-parchment p-5">
            <h2 className="smallcaps mb-2 text-base text-brass-300">Historical interpretation</h2>
            <p className="text-[15px] leading-[1.75] text-parchment-100/90">{entity.historicalInterpretation}</p>
          </section>
          <section className="panel p-5">
            <h2 className="smallcaps mb-2 text-base text-brass-300">Later interpretation</h2>
            <p className="text-[15px] leading-[1.75] text-parchment-200/80">{entity.laterInterpretation}</p>
          </section>
          <section className="panel p-5">
            <h2 className="smallcaps mb-2 text-base text-brass-300">Modern interpretation</h2>
            <p className="text-[15px] leading-[1.75] text-parchment-200/80">{entity.modernInterpretation}</p>
          </section>

          <section className="panel p-5">
            <h2 className="smallcaps mb-3 text-base text-brass-300">Sources</h2>
            <dl>
              <Field label="Primary sources" value={entity.primarySources} />
              <Field label="Secondary sources" value={entity.secondarySources} />
              <Field label="References" value={entity.references} />
            </dl>
          </section>

          <section>
            <h2 className="smallcaps mb-3 text-base text-brass-300">Notes</h2>
            <NoteForm entitySlug={slug} />
          </section>
        </div>

        <aside className="space-y-6">
          <div className="panel p-4">
            <h3 className="smallcaps mb-3 text-sm text-brass-300">Record</h3>
            <dl>
              <Field label="Alternate names" value={entity.alternateNames.join("; ")} />
              <Field label="Kind" value={entity.kind} />
              <Field label="Period" value={entity.historicalPeriod} />
              <Field label="Label" value={labelSpec(entity.label).description} />
            </dl>
            <div className="mt-4 space-y-3">
              {chips(entity.associatedSymbols)}
              {chips(entity.associatedPlanets)}
              {chips(entity.associatedElements)}
              {chips(entity.associatedNumbers.map((n) => `number ${n}`))}
            </div>
          </div>

          {correspondences.length > 0 ? (
            <div className="panel p-4">
              <h3 className="smallcaps mb-3 text-sm text-brass-300">Correspondence rows</h3>
              <ul className="space-y-2 text-sm">
                {correspondences.map((c) => (
                  <li key={c.id} className="flex justify-between gap-2 border-b border-brass-500/10 pb-1">
                    <span className="text-parchment-200/60">{c.attribute}</span>
                    <span className="text-parchment-100">{c.value}</span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="panel p-4">
            <h3 className="smallcaps mb-3 text-sm text-brass-300">Relationships</h3>
            <ul className="space-y-2">
              {neighbours.map((n) => (
                <li key={n.key} className="text-sm">
                  <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/40">{n.predicate}</span>{" "}
                  {n.kind === "entity" ? (
                    <Link href={`/entities/${n.neighbourSlug}`} className="link-brass">
                      {n.neighbourSlug.replace(/-/g, " ")}
                    </Link>
                  ) : n.kind === "document" ? (
                    <Link href={`/library/${n.neighbourSlug}`} className="link-brass">
                      {n.neighbourSlug.replace(/-/g, " ")}
                    </Link>
                  ) : n.kind === "tradition" ? (
                    <Link href={`/library?tradition=${n.neighbourSlug}`} className="link-brass">
                      {n.neighbourSlug.replace(/-/g, " ")}
                    </Link>
                  ) : (
                    <Link href={`/symbols?q=${n.neighbourSlug}`} className="link-brass">
                      {n.neighbourSlug.replace(/-/g, " ")}
                    </Link>
                  )}
                </li>
              ))}
              {neighbours.length === 0 ? <li className="text-sm text-parchment-200/50">none recorded</li> : null}
            </ul>
            <Link href={`/graph?focus=entity:${slug}`} className="link-brass mono mt-3 inline-block text-[11px] uppercase tracking-[0.2em]">
              view in graph →
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
