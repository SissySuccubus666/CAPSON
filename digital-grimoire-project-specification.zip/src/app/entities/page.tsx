import Link from "next/link";

import { ConfidenceBadge, LabelBadge, PageHeader } from "@/components/ui";
import { listEntities, listTraditions } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function EntitiesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const pick = (key: string) => {
    const value = params[key];
    return Array.isArray(value) ? value[0] : (value || undefined);
  };
  const filters = { q: pick("q"), kind: pick("kind"), tradition: pick("tradition") };
  const [rows, traditions] = await Promise.all([listEntities(filters), listTraditions()]);
  const kinds = [...new Set(rows.map((r) => r.kind))].sort();

  return (
    <div>
      <PageHeader
        eyebrow="version 0.4 — the web"
        title="Occult Entity Database"
        lead="Each entity keeps three separate interpretation fields — historical, later and modern — plus primary and secondary source lists and an explicit confidence rating. Historical attribution and modern attribution are never merged."
      />

      <form className="panel mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4" method="get">
        <input name="q" defaultValue={filters.q ?? ""} placeholder="name, alias, symbolism…" aria-label="search entities" />
        <select name="kind" defaultValue={filters.kind ?? ""} aria-label="kind">
          <option value="">kind — all</option>
          {["deity", "demon", "angel", "spirit", "figure"].map((k) => (
            <option key={k} value={k}>
              {k}
            </option>
          ))}
        </select>
        <select name="tradition" defaultValue={filters.tradition ?? ""} aria-label="tradition">
          <option value="">tradition — all</option>
          {traditions.map((t) => (
            <option key={t.slug} value={t.slug}>
              {t.name}
            </option>
          ))}
        </select>
        <div className="flex items-center gap-2">
          <button type="submit" className="rounded-sm border border-brass-500/50 bg-brass-500/15 px-4 py-1.5 text-sm text-brass-200">
            filter
          </button>
          <Link href="/entities" className="mono text-[11px] uppercase tracking-[0.2em] text-parchment-200/50 no-underline">
            reset
          </Link>
          <span className="mono ml-auto text-[11px] uppercase tracking-[0.2em] text-parchment-200/40">
            {rows.length} / kinds: {kinds.join(", ")}
          </span>
        </div>
      </form>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {rows.map((entity) => (
          <article key={entity.slug} className="panel p-4">
            <div className="mb-2 flex items-start justify-between gap-2">
              <Link href={`/entities/${entity.slug}`} className="link-brass text-lg leading-snug">
                {entity.name}
              </Link>
              <ConfidenceBadge level={entity.confidence} />
            </div>
            <p className="mono text-[10px] uppercase tracking-[0.18em] text-brass-500/70">
              {entity.kind} · {entity.tradition ?? "unassigned"}
            </p>
            <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-parchment-200/65">{entity.symbolism}</p>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <LabelBadge label={entity.label} />
              <span className="mono text-[10px] uppercase tracking-[0.15em] text-parchment-200/35">
                {entity.historicalPeriod}
              </span>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
